# Mapping Métier/CDA/FHIR - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Entête document**](enteteDocument.md)
* **Mapping Métier/CDA/FHIR**

## Mapping Métier/CDA/FHIR

Liste des ConceptMap détaillant le mapping entre les éléments du modèle métier, du CDA et de FHIR.

### Mapping entre les éléments de l’entête : Modèle métier / CDA / FHIR

Error processing SQL: [SQLITE_ERROR] SQL error or missing database (near "THEN": syntax error)

