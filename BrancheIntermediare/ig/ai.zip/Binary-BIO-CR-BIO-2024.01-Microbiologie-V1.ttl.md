# BIO-CR-BIO_2024.01_Microbiologie_V1 - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BIO-CR-BIO_2024.01_Microbiologie_V1**

## : BIO-CR-BIO_2024.01_Microbiologie_V1 - TTL Representation

[Raw ttl](Binary-BIO-CR-BIO-2024.01-Microbiologie-V1.ttl) | [Download](Binary-BIO-CR-BIO-2024.01-Microbiologie-V1.ttl)

