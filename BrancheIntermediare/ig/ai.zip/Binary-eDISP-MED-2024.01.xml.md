# null - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## : null - XML Representation

[Raw xml](Binary-eDISP-MED-2024.01.xml) | [Download](Binary-eDISP-MED-2024.01.xml)

