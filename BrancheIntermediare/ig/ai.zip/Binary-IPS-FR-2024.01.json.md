# IPS-FR - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IPS-FR**

## : IPS-FR - JSON Representation

[Raw json](Binary-IPS-FR-2024.01.json) | [Download](Binary-IPS-FR-2024.01.json)

