# CDA - dataEnterer - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - dataEnterer**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-data-enterer-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-data-enterer-mappings.md) 
*  [XML](StructureDefinition-fr-core-data-enterer.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-data-enterer.profile.json.md) 

## Logical Model: CDA - dataEnterer 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-data-enterer | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrDataEnterer |

 
L’élément de l’en-tête du CDA dataEnterer contient les informations relatives à l’opérateur de saisie de tout ou partie du contenu du document. 

**Usages:**

* Use this Logical Model Profile: [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-data-enterer)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [DataEnterer](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-DataEnterer.html) 

#### Terminology Bindings

This structure is derived from [DataEnterer](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-DataEnterer.html) 

**Résumé**

Mandatory: 1 element
 Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-entity)](StructureDefinition-fr-core-assigned-entity.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [DataEnterer](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-DataEnterer.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [DataEnterer](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-DataEnterer.html) 

**Résumé**

Mandatory: 1 element
 Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-entity)](StructureDefinition-fr-core-assigned-entity.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-data-enterer.csv), [Excel](StructureDefinition-fr-core-data-enterer.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-custodian.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-data-enterer-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

