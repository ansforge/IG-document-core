# Mapping Métier/CDA/FHIR : "Responsable du document" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Responsable du document"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingResponsableCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingResponsableCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Responsable du document" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingResponsableCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Responsable du document" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "responsable" et l’élément CDA "legalAuthenticator"
* Mapping 2 : entre l’élément CDA "legalAuthenticator" et l’élément FHIR "Composition.attester"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Responsable du document](StructureDefinition-Responsable.md) to [CDA - legalAuthenticator](StructureDefinition-fr-core-legal-authenticator.md)

* **Source Code**: Responsable
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: legalAuthenticator
  * **Commentaire**: 
* **Source Code**: Responsable.dateHeureAttestationPriseResponsabilite
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: legalAuthenticator.time
  * **Commentaire**: 
* **Source Code**: Responsable.responsable
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: legalAuthenticator.assignedEntity
  * **Commentaire**: L'élément responsable est de type PersonneStructure.

-------

**Group 2**Mapping from [CDA - legalAuthenticator](StructureDefinition-fr-core-legal-authenticator.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: legalAuthenticator
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester
  * **Commentaire**: attester.where(mode='legal')
* **Source Code**: legalAuthenticator.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.time
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole
  * **Commentaire**: attester.party.resolve().ofType(PractitionerRole)
* **Source Code**: legalAuthenticator.assignedEntity.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.Practitioner.identifier
  * **Commentaire**: attester.party.resolve().ofType(PractitionerRole).practitioner.resolve()
* **Source Code**: legalAuthenticator.assignedEntity.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.qualification.code
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.address
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.telecom
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.name
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.name.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.name.family
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.name.given
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.name.prefix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.Practitioner.name.prefix
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.name.suffix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Practitioner.name.suffix
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization
  * **Commentaire**: attester.party.resolve().ofType(PractitionerRole).organization.resolve()
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization.identifier
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization.name
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization.telecom
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization.address
  * **Commentaire**: 
* **Source Code**: legalAuthenticator.assignedEntity.representedOrganization.standardIndustryClassCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester.party.PractitionerRole.Organization.type
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPriseEnchargeCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingResponsableCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

