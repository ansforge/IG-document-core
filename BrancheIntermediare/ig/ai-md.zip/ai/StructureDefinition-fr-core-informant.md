# CDA - informant - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - informant**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-informant-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-informant-mappings.md) 
*  [XML](StructureDefinition-fr-core-informant.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-informant.profile.json.md) 

## Logical Model: CDA - informant 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-informant | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrInformant |

 
L’élément de l’en-tête du CDA informant permet d’identifier un informateur, une personne de confiance, une personne à prévenir en cas d’urgence, un aidant ou une personne aidée. 

**Usages:**

* Use this Logical Model Profile: [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-informant)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Informant](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Informant.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Informant](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Informant.html) 

**Résumé**

Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-entity)](StructureDefinition-fr-core-assigned-entity.md)
* [CDA - relatedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-related-entity)](StructureDefinition-fr-core-related-entity.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Informant](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Informant.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Informant](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Informant.html) 

**Résumé**

Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-entity)](StructureDefinition-fr-core-assigned-entity.md)
* [CDA - relatedEntity(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-related-entity)](StructureDefinition-fr-core-related-entity.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-informant.csv), [Excel](StructureDefinition-fr-core-informant.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-health-care-facility.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-informant-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

