# Mapping Métier/CDA/FHIR : "Destinataire prévu" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Destinataire prévu"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingDestinatairePrevuCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingDestinatairePrevuCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Destinataire prévu" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingDestinatairePrevuCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Destinataire prévu" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "destinataire" et l’élément CDA "informationRecipient"
* Mapping 2 : entre l’élément CDA "informationRecipient" et l’extension FHIR "InformationRecipientExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Destinataire prévu du document](StructureDefinition-DestinatairePrevu.md) to [CDA - informationRecipient](StructureDefinition-fr-core-information-recipient.md)

* **Source Code**: DestinatairePrevu
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: informationRecipient
  * **Commentaire**: 
* **Source Code**: DestinatairePrevu.destinataire
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: informationRecipient.intendedRecipient
  * **Commentaire**: L'élément destinataire est de type PersonneStructure.

-------

**Group 2**Mapping from [CDA - informationRecipient](StructureDefinition-fr-core-information-recipient.md) to [Information Recipient Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-information-recipient-extension.html)

* **Source Code**: informationRecipient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:InformationRecipientExtension
* **Source Code**: informationRecipient.intendedRecipient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:InformationRecipientExtension.extension:party.PractitionerRole
* **Source Code**: informationRecipient.intendedRecipient.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.identifier
* **Source Code**: informationRecipient.intendedRecipient.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.address
* **Source Code**: informationRecipient.intendedRecipient.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.telecom
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.name
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.name.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.name.family
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.name.given
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.name.prefix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.name.prefix
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.name.suffix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Practitioner.name.suffix
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.receivedOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Organization
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.receivedOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Organization.identifier
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.receivedOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Organization.name
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.receivedOrganization.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Organization.telecom
* **Source Code**: informationRecipient.intendedRecipient.informationRecipient.receivedOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:party.PractitionerRole.Organization.address

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingConsentementCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingDestinatairePrevuCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

