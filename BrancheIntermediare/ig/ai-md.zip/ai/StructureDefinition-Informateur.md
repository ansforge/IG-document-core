# Modèle métier - Informateur - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Informateur**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Informateur-definitions.md) 
*  [Mappings](StructureDefinition-Informateur-mappings.md) 
*  [XML](StructureDefinition-Informateur.profile.xml.md) 
*  [JSON](StructureDefinition-Informateur.profile.json.md) 

## Logical Model: Modèle métier - Informateur 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Informateur | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Informateur |

 
Informateur (personne ayant fourni des informations utiles à la production du document : professionnel, structure, patient/usager, autre), personne de confiance, personne à prévenir en cas d’urgence, aidant, aidé. 

**Usages:**

* Use this Logical Model: [Modèle logique métier de l'en-tête](StructureDefinition-EnteteDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/Informateur)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-Informateur.csv), [Excel](StructureDefinition-Informateur.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DocumentDeReference.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-Informateur-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

