# Mapping Métier/CDA/FHIR : "Personne / Structure (Auteur)" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Personne / Structure (Auteur)"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingPersonneStructureAuteurFHIR.xml.md) 
*  [JSON](ConceptMap-mappingPersonneStructureAuteurFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Personne / Structure (Auteur)" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingPersonneStructureAuteurFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:Mapping Métier/CDA/FHIR : "Personne / Structure (Auteur)" |

 
Ce ConceptMap de l’élément PersonneStructureAuteur présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "PersonneStructureAuteur" et l’élément CDA "assignedAuthor"
* Mapping 2 : entre l’élément CDA "assignedAuthor" et le profil FHIR "FrPractitionerRoleDocument"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Personne et/ou Structure (Auteur)](StructureDefinition-PersonneStructureAuteur.md) to [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md)

* **Source Code**: PersonneStructureAuteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor
* **Source Code**: PersonneStructureAuteur.personne.identifiantPersonne
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.id
* **Source Code**: PersonneStructureAuteur.personne.professionRole
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.code
* **Source Code**: PersonneStructureAuteur.personne.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.addr
* **Source Code**: PersonneStructureAuteur.personne.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.telecom
* **Source Code**: PersonneStructureAuteur.personne.IdentitePersonne
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedPerson
* **Source Code**: PersonneStructureAuteur.personne.IdentitePersonne.nomPersonne
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedPerson.name.family
* **Source Code**: PersonneStructureAuteur.personne.IdentitePersonne.prenomPersonne
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedPerson.name.given
* **Source Code**: PersonneStructureAuteur.personne.IdentitePersonne.civilite
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedPerson.name.prefix
* **Source Code**: PersonneStructureAuteur.personne.IdentitePersonne.titre
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedPerson.name.suffix
* **Source Code**: PersonneStructureAuteur.structure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization
* **Source Code**: PersonneStructureAuteur.structure.identifiantStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.id
* **Source Code**: PersonneStructureAuteur.structure.nomStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.name
* **Source Code**: PersonneStructureAuteur.structure.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.addr
* **Source Code**: PersonneStructureAuteur.structure.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.telecom
* **Source Code**: PersonneStructureAuteur.structure.secteurActivite
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.standardIndustryClassCode

-------

**Group 2**Mapping from [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md) to [Fr PractitionerRole Document](StructureDefinition-fr-practitionerRole-document.md)

* **Source Code**: assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner
  * **Commentaire**: PractitionerRole.practitioner.resolve().ofType(Practitioner)
* **Source Code**: assignedAuthor.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.identifier
  * **Commentaire**: 
* **Source Code**: assignedAuthor.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.qualification.code
  * **Commentaire**: 
* **Source Code**: assignedAuthor.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.address
  * **Commentaire**: 
* **Source Code**: assignedAuthor.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.telecom
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedPerson.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.name
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedPerson.name.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.name.family
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedPerson.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.name.given
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedPerson.name.prefix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.name.prefix
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedPerson.name.suffix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Practitioner.name.suffix
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization
  * **Commentaire**: PractitionerRole.organization.resolve().ofType(Organization)
* **Source Code**: assignedAuthor.representedOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization.identifier
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization.name
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization.address
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization.telecom
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.standardIndustryClassCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PractitionerRole.Organization.type
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPersonneStructureAssignedEntityFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingPersonneStructureAuteurFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

