# CDA - clinicalDocument - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - clinicalDocument**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-clinical-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-clinical-document-mappings.md) 
*  [Examples](StructureDefinition-fr-core-clinical-document-examples.md) 
*  [XML](StructureDefinition-fr-core-clinical-document.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-clinical-document.profile.json.md) 

## Logical Model: CDA - clinicalDocument 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-clinical-document | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:FrClinicalDocument |

 
L’élément de l’en-tête CDA ‘ClinicalDocument’ est l’élément racine d’un document médical. 

**Usages:**

* This Logical Model Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-clinical-document)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocument](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-ClinicalDocument.html) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocument](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-ClinicalDocument.html) 

**Résumé**

Mandatory: 9 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [CDA - recordTarget(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-record-target)](StructureDefinition-fr-core-record-target.md)
* [CDA - author(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author)](StructureDefinition-fr-core-author.md)
* [CDA - dataEnterer(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-data-enterer)](StructureDefinition-fr-core-data-enterer.md)
* [CDA - informant(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-informant)](StructureDefinition-fr-core-informant.md)
* [CDA - custodian(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-custodian)](StructureDefinition-fr-core-custodian.md)
* [CDA - informationRecipient(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-information-recipient)](StructureDefinition-fr-core-information-recipient.md)
* [CDA - legalAuthenticator(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-legal-authenticator)](StructureDefinition-fr-core-legal-authenticator.md)
* [CDA - authenticator(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authenticator)](StructureDefinition-fr-core-authenticator.md)
* [CDA - participant(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-participant)](StructureDefinition-fr-core-participant.md)
* [CDA - inFulfillmentOf(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-inFulfillment-of)](StructureDefinition-fr-core-inFulfillment-of.md)
* [CDA - documentationOf(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-documentation-of)](StructureDefinition-fr-core-documentation-of.md)
* [CDA - relatedDocument(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-related-document)](StructureDefinition-fr-core-related-document.md)
* [CDA - authorization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authorization)](StructureDefinition-fr-core-authorization.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ClinicalDocument](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-ClinicalDocument.html) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocument](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-ClinicalDocument.html) 

**Résumé**

Mandatory: 9 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [CDA - recordTarget(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-record-target)](StructureDefinition-fr-core-record-target.md)
* [CDA - author(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author)](StructureDefinition-fr-core-author.md)
* [CDA - dataEnterer(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-data-enterer)](StructureDefinition-fr-core-data-enterer.md)
* [CDA - informant(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-informant)](StructureDefinition-fr-core-informant.md)
* [CDA - custodian(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-custodian)](StructureDefinition-fr-core-custodian.md)
* [CDA - informationRecipient(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-information-recipient)](StructureDefinition-fr-core-information-recipient.md)
* [CDA - legalAuthenticator(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-legal-authenticator)](StructureDefinition-fr-core-legal-authenticator.md)
* [CDA - authenticator(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authenticator)](StructureDefinition-fr-core-authenticator.md)
* [CDA - participant(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-participant)](StructureDefinition-fr-core-participant.md)
* [CDA - inFulfillmentOf(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-inFulfillment-of)](StructureDefinition-fr-core-inFulfillment-of.md)
* [CDA - documentationOf(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-documentation-of)](StructureDefinition-fr-core-documentation-of.md)
* [CDA - relatedDocument(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-related-document)](StructureDefinition-fr-core-related-document.md)
* [CDA - authorization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authorization)](StructureDefinition-fr-core-authorization.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-clinical-document.csv), [Excel](StructureDefinition-fr-core-clinical-document.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-authorization.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-clinical-document-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

