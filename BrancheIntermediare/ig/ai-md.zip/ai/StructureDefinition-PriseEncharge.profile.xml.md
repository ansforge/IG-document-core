# Modèle métier - Association du document à une prise en charge - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Association du document à une prise en charge**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-PriseEncharge.md) 
*  [Detailed Descriptions](StructureDefinition-PriseEncharge-definitions.md) 
*  [Mappings](StructureDefinition-PriseEncharge-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-PriseEncharge.profile.json.md) 

## Logical Model: PriseEncharge - XML Profile

| |
| :--- |
| Draft as of 2025-10-03 |

XML representation of the PriseEncharge logical model.

[Raw xml](StructureDefinition-PriseEncharge.xml) | [Download](StructureDefinition-PriseEncharge.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-PriseEncharge-testing.md) | [top](#top) |  [next>](StructureDefinition-PriseEncharge.profile.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

