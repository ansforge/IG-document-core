# CDA - encompassingEncounter - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - encompassingEncounter**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-fr-core-encompassing-encounter.md) 
*  [Detailed Descriptions](StructureDefinition-fr-core-encompassing-encounter-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-encompassing-encounter-mappings.md) 
*  [XML](StructureDefinition-fr-core-encompassing-encounter.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-encompassing-encounter.profile.json.md) 

## Logical Model: FrEncompassingEncounter - TTL Profile

| |
| :--- |
| Draft as of 2025-10-02 |

TTL representation of the fr-core-encompassing-encounter logical model.

[Raw ttl](StructureDefinition-fr-core-encompassing-encounter.ttl) | [Download](StructureDefinition-fr-core-encompassing-encounter.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-encompassing-encounter.profile.json.md) | [top](#top) |  [next>](StructureDefinition-fr-core-encounter-participant.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

