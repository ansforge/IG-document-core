# Mapping Métier/CDA/FHIR : "Prescription" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Prescription"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingPrescriptionCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingPrescriptionCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Prescription" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingPrescriptionCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Prescription" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "prescription" et l’élément CDA "inFulfillmentOf"
* Mapping 2 : entre l’élément CDA "inFulfillmentOf" et l’extension FHIR "OrderExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Association du document à une prescription](StructureDefinition-Prescription.md) to [CDA - inFulfillmentOf](StructureDefinition-fr-core-inFulfillment-of.md)

* **Source Code**: Prescription
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: inFulfillmentOf
* **Source Code**: Prescription.identifiantPrescription
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: inFulfillmentOf.order.id
* **Source Code**: Prescription.accessionNumber
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: inFulfillmentOf.order.ps3-20:accessionNumber

-------

**Group 2**Mapping from [CDA - inFulfillmentOf](StructureDefinition-fr-core-inFulfillment-of.md) to [Order Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-OrderExtension.html)

* **Source Code**: inFulfillmentOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:OrderExtension
* **Source Code**: inFulfillmentOf.order.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:OrderExtension.ValueReference.ServiceRequest.identifier
* **Source Code**: inFulfillmentOf.order.ps3-20:accessionNumber
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:OrderExtension.ValueReference.ServiceRequest.identifier

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingPrescriptionCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

