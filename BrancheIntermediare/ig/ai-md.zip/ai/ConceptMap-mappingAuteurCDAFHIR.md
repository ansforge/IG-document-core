# Mapping Métier/CDA/FHIR : "Auteur" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Auteur"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingAuteurCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingAuteurCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Auteur" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingAuteurCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Auteur" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "auteur" et l’élément CDA "author"
* Mapping 2 : entre l’élément CDA "author" et l’élément FHIR "Composition.author"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Auteur du document (humain ou système)](StructureDefinition-Auteur.md) to [CDA - author](StructureDefinition-fr-core-author.md)

* **Source Code**: Auteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author
  * **Commentaire**: 
* **Source Code**: Auteur.roleFonctionnel
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.functionCode
  * **Commentaire**: 
* **Source Code**: Auteur.horodatageParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.time
  * **Commentaire**: 
* **Source Code**: Auteur.PersonneStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.assignedAuthor
  * **Commentaire**: L'élément PersonneStructure est de type PersonneStructure.
* **Source Code**: Auteur.SystemeStructureAuteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.assignedAuthor
  * **Commentaire**: L'élément SystemeStructureAuteur est de type Systeme

-------

**Group 2**Mapping from [CDA - author](StructureDefinition-fr-core-author.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: author
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author
  * **Commentaire**: 
* **Source Code**: author.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.extension:time
  * **Commentaire**: 
* **Source Code**: author.functionCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.PractitionerRole.code
  * **Commentaire**: Auteur du document est un professionnel et author.ofType(PractitionerRole)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Practitioner
  * **Commentaire**: Composition.author.resolve().ofType(Practitioner)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Patient
  * **Commentaire**: Composition.author.resolve().ofType(Patient)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Device
  * **Commentaire**: Composition.author.resolve().ofType(Device)

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingmodelemetierCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingAuteurCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

