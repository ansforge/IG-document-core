# Mapping Métier/CDA/FHIR : "Patient/Usager" - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Patient/Usager"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](ConceptMap-mappingPatientCDAFHIR.md) 
*  [XML](ConceptMap-mappingPatientCDAFHIR.xml.md) 
*  [JSON](#) 

## : Mapping Métier/CDA/FHIR : "Patient/Usager" - JSON Representation

| |
| :--- |
| Draft as of 2025-10-03 |

[Raw json](ConceptMap-mappingPatientCDAFHIR.json) | [Download](ConceptMap-mappingPatientCDAFHIR.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPatientCDAFHIR.xml.md) | [top](#top) |  [next>](ConceptMap-mappingPatientCDAFHIR.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

