# Modèle métier - Opérateur de saisie - Mappings - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Opérateur de saisie**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-OperateurSaisie.md) 
*  [Detailed Descriptions](StructureDefinition-OperateurSaisie-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-OperateurSaisie.profile.xml.md) 
*  [JSON](StructureDefinition-OperateurSaisie.profile.json.md) 

## Logical Model: OperateurSaisie - Mappings

| |
| :--- |
| Draft as of 2025-10-02 |

Mappings for the OperateurSaisie logical model.

No Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-OperateurSaisie-definitions.md) | [top](#top) |  [next>](StructureDefinition-OperateurSaisie-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

