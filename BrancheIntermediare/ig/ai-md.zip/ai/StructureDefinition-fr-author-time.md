# Fr Author Time Extension - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fr Author Time Extension**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-author-time-definitions.md) 
*  [Mappings](StructureDefinition-fr-author-time-mappings.md) 
*  [XML](StructureDefinition-fr-author-time.profile.xml.md) 
*  [JSON](StructureDefinition-fr-author-time.profile.json.md) 

## Extension: Fr Author Time Extension 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-author-time | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrAuthorTimeExtension |

Extension permettant d’ajouter un horodatage (TS) à l’élément author d’une Composition.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Fr Composition Document](StructureDefinition-fr-composition-document.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-author-time)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type dateTime: Extension permettant d'ajouter un horodatage (TS) à l'élément author d'une Composition.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type dateTime: Extension permettant d'ajouter un horodatage (TS) à l'élément author d'une Composition.

 

Other representations of profile: [CSV](StructureDefinition-fr-author-time.csv), [Excel](StructureDefinition-fr-author-time.xlsx), [Schematron](StructureDefinition-fr-author-time.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-human-name-document.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-author-time-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

