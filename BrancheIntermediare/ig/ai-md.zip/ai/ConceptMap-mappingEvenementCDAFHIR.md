# Mapping Métier/CDA/FHIR : "Evènement documenté" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Evènement documenté"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingEvenementCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingEvenementCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Evènement documenté" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingEvenementCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Evènement documenté" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 :entre le modèle métier "evenement" et l’élément CDA "documentationOf"
* Mapping 2 : entre l’élément CDA "documentationOf" et l’élément FHIR "Composition.event"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Évènement documenté](StructureDefinition-Evenement.md) to [CDA - documentationOf](StructureDefinition-fr-core-documentation-of.md)

* **Source Code**: Evenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf
* **Source Code**: Evenement.identifiantEvenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.id
* **Source Code**: Evenement.codeEvenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.code
* **Source Code**: Evenement.dateHeureEvenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.effectiveTime
* **Source Code**: Evenement.executantEvenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.performer@typeCode="PRF"
* **Source Code**: Evenement.executantEvenement.roleFonctionnel
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.performer.functionCode
* **Source Code**: Evenement.executantEvenement.dateHeureParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.performer.time
* **Source Code**: Evenement.executantEvenement.executant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: documentationOf.serviceEvent.performer.assignedEntity

-------

**Group 2**Mapping from [CDA - documentationOf](StructureDefinition-fr-core-documentation-of.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: documentationOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event
  * **Commentaire**: 
* **Source Code**: documentationOf.serviceEvent.id
  * **relation**: (not mapped)
  * **Target Code**: Cette donnée est fournie dans un autre élément : Composition.relatesTo
* **Source Code**: documentationOf.serviceEvent.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event.code
  * **Commentaire**: 
* **Source Code**: documentationOf.serviceEvent.effectiveTime
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event.period
  * **Commentaire**: 
* **Source Code**: documentationOf.serviceEvent.performer@typeCode="PRF"
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event.extension:perfomer.PractitionerRole
  * **Commentaire**: Composition.event.extension:perfomer.ValueReference.resolve().ofType(FrPractitionerRoleDocument)
* **Source Code**: documentationOf.serviceEvent.performer.functionCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event.extension:perfomer.PractitionerRole.code
  * **Commentaire**: 
* **Source Code**: documentationOf.serviceEvent.performer.time
  * **relation**: (not mapped)
  * **Target Code**: Mapped in Composition.event.period
* **Source Code**: documentationOf.serviceEvent.performer.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event.extension:perfomer.PractitionerRole.Practitioner
  * **Commentaire**: Composition.event.extension:perfomer.ValueReference.resolve().ofType(FrPractitionerRoleDocument).Practitioner.resolve()

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingDocumentDeReferenceCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingEvenementCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

