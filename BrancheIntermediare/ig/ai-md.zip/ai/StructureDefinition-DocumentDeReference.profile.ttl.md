# Modèle métier - Document de référence - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Document de référence**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-DocumentDeReference.md) 
*  [Detailed Descriptions](StructureDefinition-DocumentDeReference-definitions.md) 
*  [Mappings](StructureDefinition-DocumentDeReference-mappings.md) 
*  [XML](StructureDefinition-DocumentDeReference.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentDeReference.profile.json.md) 

## Logical Model: DocumentDeReference - TTL Profile

| |
| :--- |
| Draft as of 2025-10-03 |

TTL representation of the DocumentDeReference logical model.

[Raw ttl](StructureDefinition-DocumentDeReference.ttl) | [Download](StructureDefinition-DocumentDeReference.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DocumentDeReference.profile.json.md) | [top](#top) |  [next>](StructureDefinition-Informateur.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

