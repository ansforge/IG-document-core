# Mapping Métier/CDA/FHIR : "Participant" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Participant"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingParticipantCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingParticipantCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Participant" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingParticipantCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:Mapping Métier/CDA/FHIR : "Participant" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "participant" et l’élément CDA "participant"
* Mapping 2 : entre l’élément CDA "participant" et l’extension FHIR "ParticipantExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Autres personnes / structures impliquées](StructureDefinition-Participant.md) to [CDA - participant](StructureDefinition-fr-core-participant.md)

* **Source Code**: Participant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: participant
  * **Commentaire**: 
* **Source Code**: Participant.typeParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: participant@typeCode
  * **Commentaire**: 
* **Source Code**: Participant.roleFonctionnel
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: participant.functionCode
  * **Commentaire**: 
* **Source Code**: Participant.dateDebutEtOuFinParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: participant.time
  * **Commentaire**: 
* **Source Code**: Participant.participant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: participant.associatedEntity
  * **Commentaire**: L'élément participant est de type PersonneStructure

-------

**Group 2**Mapping from [CDA - participant](StructureDefinition-fr-core-participant.md) to [Participant Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-ParticipantExtension.html)

* **Source Code**: participant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension
  * **Commentaire**: 
* **Source Code**: participant@typeCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.extention:type
  * **Commentaire**: 
* **Source Code**: participant.functionCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.extention:function.coding
  * **Commentaire**: 
* **Source Code**: participant.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.extention:time
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(PractitionerRole)
* **Source Code**: participant.associatedEntity@classCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.qualification.code
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.identifier
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(PractitionerRole).practitioner.resolve()
* **Source Code**: participant.associatedEntity.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.qualification.code
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.address
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.telecom
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.name
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.name.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.name.family
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.name.given
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.name.prefix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.name.prefix
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.name.suffix
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Practitioner.name.suffix
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.scopingOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Organization
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(PractitionerRole).organization.resolve()
* **Source Code**: participant.associatedEntity.scopingOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Organization.identifier
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.scopingOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Organization.name
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.scopingOrganization.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Organization.telecom
  * **Commentaire**: 
* **Source Code**: participant.associatedEntity.scopingOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ParticipantExtension.party.PractitionerRole.Organization.address
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingOperateurSaisieCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingParticipantCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

