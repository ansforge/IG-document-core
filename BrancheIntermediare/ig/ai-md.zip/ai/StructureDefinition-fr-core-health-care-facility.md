# CDA - healthCareFacility - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - healthCareFacility**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-health-care-facility-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-health-care-facility-mappings.md) 
*  [XML](StructureDefinition-fr-core-health-care-facility.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-health-care-facility.profile.json.md) 

## Logical Model: CDA - healthCareFacility 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-health-care-facility | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrHealthCareFacility |

 
L’élément de l’en-tête du CDA healthCareFacility permet de représenter la structure de prise en charge (cabinet du médecin, hôpital ou clinique, etc.). 

**Usages:**

* Use this Logical Model Profile: [CDA - encompassingEncounter](StructureDefinition-fr-core-encompassing-encounter.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-health-care-facility)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [HealthCareFacility](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-HealthCareFacility.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [HealthCareFacility](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-HealthCareFacility.html) 

**Résumé**

Mandatory: 4 elements(3 nested mandatory elements)
 Prohibited: 14 elements

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [HealthCareFacility](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-HealthCareFacility.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [HealthCareFacility](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-HealthCareFacility.html) 

**Résumé**

Mandatory: 4 elements(3 nested mandatory elements)
 Prohibited: 14 elements

 

Other representations of profile: [CSV](StructureDefinition-fr-core-health-care-facility.csv), [Excel](StructureDefinition-fr-core-health-care-facility.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-encounter-participant.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-health-care-facility-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

