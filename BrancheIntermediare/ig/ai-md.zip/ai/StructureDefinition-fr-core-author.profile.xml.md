# CDA - author - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - author**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-fr-core-author.md) 
*  [Detailed Descriptions](StructureDefinition-fr-core-author-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-author-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-fr-core-author.profile.json.md) 

## Logical Model: FrAuthor - XML Profile

| |
| :--- |
| Draft as of 2025-10-03 |

XML representation of the fr-core-author logical model.

[Raw xml](StructureDefinition-fr-core-author.xml) | [Download](StructureDefinition-fr-core-author.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-author-testing.md) | [top](#top) |  [next>](StructureDefinition-fr-core-author.profile.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

