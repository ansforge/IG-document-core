# Mapping Métier/CDA/FHIR : "Personne / Structure (RelatedEntity)" - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Personne / Structure (RelatedEntity)"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.md) 
*  [XML](#) 
*  [JSON](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.json.md) 

## : Mapping Métier/CDA/FHIR : "Personne / Structure (RelatedEntity)" - XML Representation

| |
| :--- |
| Draft as of 2025-10-02 |

[Raw xml](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.xml) | [Download](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPersonneStructureRelatedEntityFHIR-testing.md) | [top](#top) |  [next>](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

