# CDA - associatedEntity - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - associatedEntity**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-associated-entity-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-associated-entity-mappings.md) 
*  [XML](StructureDefinition-fr-core-associated-entity.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-associated-entity.profile.json.md) 

## Logical Model: CDA - associatedEntity 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-associated-entity | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:FrAssociatedEntity |

 
L’élément de l’en-tête du CDA associatedEntity permet de représenter les caractéristiques du professionnel et/ou de l’établissement participant. 

**Usages:**

* Use this Logical Model Profile: [CDA - participant](StructureDefinition-fr-core-participant.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-associated-entity)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [AssociatedEntity](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssociatedEntity.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [AssociatedEntity](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssociatedEntity.html) 

**Résumé**

Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedPerson(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-person)](StructureDefinition-fr-core-person.md)
* [CDA - representedOrganization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-represented-organization)](StructureDefinition-fr-core-represented-organization.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [AssociatedEntity](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssociatedEntity.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [AssociatedEntity](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssociatedEntity.html) 

**Résumé**

Prohibited: 5 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedPerson(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-person)](StructureDefinition-fr-core-person.md)
* [CDA - representedOrganization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-represented-organization)](StructureDefinition-fr-core-represented-organization.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-associated-entity.csv), [Excel](StructureDefinition-fr-core-associated-entity.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-person.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-associated-entity-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

