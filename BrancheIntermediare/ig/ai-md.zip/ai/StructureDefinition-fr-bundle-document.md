# Fr Bundle Document - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fr Bundle Document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-bundle-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-bundle-document-mappings.md) 
*  [XML](StructureDefinition-fr-bundle-document.profile.xml.md) 
*  [JSON](StructureDefinition-fr-bundle-document.profile.json.md) 

## Resource Profile: Fr Bundle Document 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-bundle-document | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrBundleDocument |

 
Ce profil permet d’assembler les éléments de l’en-tête et du corps d’un document. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-bundle-document)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Résumé**

Mandatory: 9 elements(1 nested mandatory element)
 Must-Support: 2 elements

**Structures**

This structure refers to these other structures:

* [Fr Composition Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document)](StructureDefinition-fr-composition-document.md)
* [Fr Patient INS Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-ins-document)](StructureDefinition-fr-patient-ins-document.md)
* [Fr Patient Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-document)](StructureDefinition-fr-patient-document.md)
* [Fr PractitionerRole Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitionerRole-document)](StructureDefinition-fr-practitionerRole-document.md)
* [Fr Practitioner Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitioner-document)](StructureDefinition-fr-practitioner-document.md)
* [Fr Organization Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-organization-document)](StructureDefinition-fr-organization-document.md)
* [Fr Device Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-device-document)](StructureDefinition-fr-device-document.md)
* [Fr Encounter Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-encounter-document)](StructureDefinition-fr-encounter-document.md)
* [Fr Location Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-location-document)](StructureDefinition-fr-location-document.md)
* [Fr RelatedPerson Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-related-person-document)](StructureDefinition-fr-related-person-document.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Résumé**

Mandatory: 9 elements(1 nested mandatory element)
 Must-Support: 2 elements

**Structures**

This structure refers to these other structures:

* [Fr Composition Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document)](StructureDefinition-fr-composition-document.md)
* [Fr Patient INS Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-ins-document)](StructureDefinition-fr-patient-ins-document.md)
* [Fr Patient Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-document)](StructureDefinition-fr-patient-document.md)
* [Fr PractitionerRole Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitionerRole-document)](StructureDefinition-fr-practitionerRole-document.md)
* [Fr Practitioner Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitioner-document)](StructureDefinition-fr-practitioner-document.md)
* [Fr Organization Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-organization-document)](StructureDefinition-fr-organization-document.md)
* [Fr Device Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-device-document)](StructureDefinition-fr-device-document.md)
* [Fr Encounter Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-encounter-document)](StructureDefinition-fr-encounter-document.md)
* [Fr Location Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-location-document)](StructureDefinition-fr-location-document.md)
* [Fr RelatedPerson Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-related-person-document)](StructureDefinition-fr-related-person-document.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-fr-bundle-document.csv), [Excel](StructureDefinition-fr-bundle-document.xlsx), [Schematron](StructureDefinition-fr-bundle-document.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-service-event.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-bundle-document-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

