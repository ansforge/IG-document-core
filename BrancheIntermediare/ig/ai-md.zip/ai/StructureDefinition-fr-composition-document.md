# Fr Composition Document - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fr Composition Document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-composition-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-composition-document-mappings.md) 
*  [XML](StructureDefinition-fr-composition-document.profile.xml.md) 
*  [JSON](StructureDefinition-fr-composition-document.profile.json.md) 

## Resource Profile: Fr Composition Document 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:FrCompositionDocument |

 
Ce profil est utilisé pour représenter un document médical. 

**Usages:**

* Use this Profile: [Fr Bundle Document](StructureDefinition-fr-bundle-document.md)
* Refer to this Profile: [Fr Composition Document](StructureDefinition-fr-composition-document.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-composition-document)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocumentComposition](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-clinical-document-composition.html) 

#### Terminology Bindings (Differential)

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocumentComposition](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-clinical-document-composition.html) 

**Résumé**

Mandatory: 19 elements(5 nested mandatory elements)
 Must-Support: 4 elements

**Structures**

This structure refers to these other structures:

* [Fr PractitionerRole Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitionerRole-document)](StructureDefinition-fr-practitionerRole-document.md)
* [Fr RelatedPerson Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-related-person-document)](StructureDefinition-fr-related-person-document.md)
* [Fr Patient INS Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-ins-document)](StructureDefinition-fr-patient-ins-document.md)
* [Fr Patient Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-document)](StructureDefinition-fr-patient-document.md)
* [Fr Encounter Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-encounter-document)](StructureDefinition-fr-encounter-document.md)
* [Fr Device Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-device-document)](StructureDefinition-fr-device-document.md)
* [Fr Organization Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-organization-document)](StructureDefinition-fr-organization-document.md)
* [Fr Composition Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document)](StructureDefinition-fr-composition-document.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-author-time](StructureDefinition-fr-author-time.md)
* [https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-performer-event](StructureDefinition-fr-performer-event.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.meta.profile
* The element 1 is sliced based on the value of Composition.event
* The element 1 is sliced based on the value of Composition.section

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ClinicalDocumentComposition](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-clinical-document-composition.html) 

#### Terminology Bindings (Differential)

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ClinicalDocumentComposition](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-clinical-document-composition.html) 

**Résumé**

Mandatory: 19 elements(5 nested mandatory elements)
 Must-Support: 4 elements

**Structures**

This structure refers to these other structures:

* [Fr PractitionerRole Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-practitionerRole-document)](StructureDefinition-fr-practitionerRole-document.md)
* [Fr RelatedPerson Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-related-person-document)](StructureDefinition-fr-related-person-document.md)
* [Fr Patient INS Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-ins-document)](StructureDefinition-fr-patient-ins-document.md)
* [Fr Patient Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-document)](StructureDefinition-fr-patient-document.md)
* [Fr Encounter Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-encounter-document)](StructureDefinition-fr-encounter-document.md)
* [Fr Device Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-device-document)](StructureDefinition-fr-device-document.md)
* [Fr Organization Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-organization-document)](StructureDefinition-fr-organization-document.md)
* [Fr Composition Document(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document)](StructureDefinition-fr-composition-document.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-author-time](StructureDefinition-fr-author-time.md)
* [https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-performer-event](StructureDefinition-fr-performer-event.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.meta.profile
* The element 1 is sliced based on the value of Composition.event
* The element 1 is sliced based on the value of Composition.section

 

Other representations of profile: [CSV](StructureDefinition-fr-composition-document.csv), [Excel](StructureDefinition-fr-composition-document.xlsx), [Schematron](StructureDefinition-fr-composition-document.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-bundle-document.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-composition-document-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

