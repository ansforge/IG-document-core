# Modèle métier - Destinataire prévu du document - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Destinataire prévu du document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-DestinatairePrevu.md) 
*  [Detailed Descriptions](StructureDefinition-DestinatairePrevu-definitions.md) 
*  [Mappings](StructureDefinition-DestinatairePrevu-mappings.md) 
*  [XML](StructureDefinition-DestinatairePrevu.profile.xml.md) 
*  [JSON](#) 

## Logical Model: DestinatairePrevu - JSON Profile

| |
| :--- |
| Draft as of 2025-10-02 |

JSON representation of the DestinatairePrevu logical model.

[Raw json](StructureDefinition-DestinatairePrevu.json) | [Download](StructureDefinition-DestinatairePrevu.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DestinatairePrevu.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-DestinatairePrevu.profile.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

