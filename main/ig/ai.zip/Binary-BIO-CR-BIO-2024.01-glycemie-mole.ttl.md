# null - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## : null - TTL Representation

[Raw ttl](Binary-BIO-CR-BIO-2024.01-glycemie-mole.ttl) | [Download](Binary-BIO-CR-BIO-2024.01-glycemie-mole.ttl)

