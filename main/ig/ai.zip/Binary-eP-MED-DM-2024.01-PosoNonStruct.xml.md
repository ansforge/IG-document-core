# null - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## : null - XML Representation

[Raw xml](Binary-eP-MED-DM-2024.01-PosoNonStruct.xml) | [Download](Binary-eP-MED-DM-2024.01-PosoNonStruct.xml)

