# LDL-SES_2022.01 - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LDL-SES_2022.01**

## : LDL-SES_2022.01 - TTL Representation

[Raw ttl](Binary-LDL-SES-2022.01.ttl) | [Download](Binary-LDL-SES-2022.01.ttl)

