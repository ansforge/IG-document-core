# BIO-CR-BIO_2024.01_Glycemie_mole - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BIO-CR-BIO_2024.01_Glycemie_mole**

## : BIO-CR-BIO_2024.01_Glycemie_mole - JSON Representation

[Raw json](Binary-BIO-CR-BIO-2024.01-glycemie-mole.json) | [Download](Binary-BIO-CR-BIO-2024.01-glycemie-mole.json)

