#  - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## Binary: 

```

<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="../FeuilleDeStyle/CDA-FO.xsl"?>
<?oxygen SCHSchema="../schematrons/profils/IHE.sch"?>
<?oxygen SCHSchema="../schematrons/profils/structurationMinimale/ASIP-STRUCT-MIN-StrucMin.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_ModelesDeContenusCDA.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_Modeles_ANS.sch"?>
<?oxygen SCHSchema="../schematrons/profils/terminologies/schematron/terminologie.sch"?>
<?oxygen SCHSchema="../schematrons/CI-SIS_BIO-CR-BIO_2024.01.sch"?>
<!-- 
	**********************************************************************************************************
    Document : Compte-rendu d’examens de biologie médicale (BIO-CR-BIO_2024.01_Microbiologie_V1)      
    Auteur : ANS
    **********************************************************************************************************
    format HL7 - CDA Release 2 niveau 3
    **********************************************************************************************************
    Historique :
    13/10/2023 : version 2023.01
    17/10/2023 : Modification du code de la Section FR-Document-PDF-copie
    20/08/2024 : version 20/08/2024
    20/08/2025 : correction reference copie du document
    **********************************************************************************************************
-->
<!--
    ********************************************************
    En-tête du document
    ********************************************************
-->
<ClinicalDocument xmlns="urn:hl7-org:v3" xmlns:lab="urn:oid:1.3.6.1.4.1.19376.1.3.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
  xsi:schemaLocation="urn:hl7-org:v3 ../infrastructure/cda/CDA_extended.xsd">
  <realmCode code="FR" />
  <typeId root="2.16.840.1.113883.1.3" extension="POCD_HD000040" />
  <!-- Déclarations de conformité HL7 France -->
  <templateId root="2.16.840.1.113883.2.8.2.1" />
  <!-- Déclarations de conformité CI-SIS -->
  <templateId root="1.2.250.1.213.1.1.1.1" />
  <!-- Déclarations de conformité IHE PALM -->
  <templateId root="1.3.6.1.4.1.19376.1.3.3"/>
  <!-- Déclarations de conformité au modèle CR-BIO du CI-SIS -->
  <templateId root="1.2.250.1.213.1.1.1.55" extension="2024.01"/>
  <!-- Identifiant du document -->
  <id root="1.2.250.1.213.1.1.1.55.2024.8.1"/>
  <!-- Type de document -->
  <code code="11502-2" displayName="CR d'examens biologiques" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
  <!-- Titre du document -->
  <title>Compte rendu d'examens biologiques</title>
  <!-- Date et heure de création du document -->
  <effectiveTime value="20240104160527+0100" />
  <!-- Niveau de confidentialité du document -->
  <confidentialityCode code="N" displayName="Normal" codeSystem="2.16.840.1.113883.5.25" />
  <!-- Langue du document -->
  <languageCode code="fr-FR" />
  <!-- identifiant commun à toutes les versions successives du comtpe rendu -->
  <setId root="1.2.250.1.213.1.1.1.55.2024.8"/>
  <!-- numéro de la version courante (entier positif), ici la première version -->
  <versionNumber value="1" />
  <!-- Patient -->
  <recordTarget>
    <patientRole>
      <!-- INS-NIR de test : 1.2.250.1.213.1.4.10 -->
      <id extension="279035121518989" root="1.2.250.1.213.1.4.10"/>
      <!-- IPP du patient dans l'établissement avec root = l'OID de l'ES -->
      <id extension="1234567890121" root="1.2.3.4.567.8.9.10" />
      <!-- Adresse du patient -->
      <addr>
        <houseNumber>28</houseNumber>
        <streetName>Av de Breteuil</streetName>
        <unitID>Escalier A</unitID>
        <postalCode>75007</postalCode>
        <city>PARIS</city>
        <country>FRANCE</country>
      </addr>
      <!-- Coordonnées télécom du patient -->
      <telecom value="tel:0144534551" use="H" />
      <telecom value="tel:0647151010" use="MC" />
      <telecom value="mailto:279035121518989@patient.mssante.fr"/>
      <!-- Identité du patient -->
      <patient classCode="PSN">
        <name>
          <!-- Nom et prénom(s) de naissance -->
          <!-- Nom de l’acte de naissance -->
          <family qualifier="BR">PAT-TROIS</family> 
          <!-- Prénoms de l’acte de naissance -->
          <given>DOMINIQUE MARIE-LOUISE</given>
          <!-- Premier prénom de l’acte de naissance -->
          <given qualifier="BR">DOMINIQUE</given>
          <!-- Nom et prénom utilisés -->
          <family qualifier="CL">PAT-TROIS</family>
          <given qualifier="CL">DOMINIQUE</given>        
        </name>
        <administrativeGenderCode code="F" displayName="Féminin" codeSystem="2.16.840.1.113883.5.1" />
        <birthTime value="19790328"/>
        <!-- Représentant du patient -->
        <guardian>
          <addr use="H">
            <houseNumber>28</houseNumber>
            <streetName>Av de Breteuil</streetName>
            <postalCode>75007</postalCode>
            <city>PARIS</city>
            <country>FRANCE</country>
          </addr>
          <telecom value="tel:0147150000" use="H" />
          <guardianPerson>
            <name>
              <prefix>MME</prefix>
              <family>NESSI</family>
              <given>Jeanne</given>
            </name>
          </guardianPerson>
        </guardian>
        <!-- Lieu de naissance du patient -->
        <birthplace>
          <place>
            <addr>
              <county>51215</county>
              <city>DOMPREMY</city>
            </addr>
          </place>
        </birthplace>
      </patient>
    </patientRole>
  </recordTarget>
  
  <!-- Auteur -->
  <author>
    <time value="20240104160527+0100" />
    <assignedAuthor>
      <id root="1.2.250.1.71.4.2.1" extension="801234534765" />
      <code code="G15_10/SM03" displayName="Médecin - Biologie médicale (SM)" codeSystem="1.2.250.1.213.1.1.4.5" />
      <addr>
        <houseNumber>8</houseNumber>
        <streetName>Rue Frédéric Bastia</streetName>
        <postalCode>92100</postalCode>
        <city>BOULOGNE-BILLANCOURT</city>
      </addr>
      <telecom value="tel:0174589607" use="WP" />
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Marcel</given>
          <family>CAMPARINI</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <representedOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
        <!-- Nom de l'organisation -->
        <name>Laboratoire des charmes</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0174589607" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>8</houseNumber>
          <streetName>Rue Frédéric Bastia</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
      </representedOrganization>
    </assignedAuthor>
  </author>
  <!-- Personne à prévenir en cas d'urgence -->
  <informant>
    <relatedEntity classCode="ECON">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111" />
      <addr nullFlavor="NAV" />
      <telecom value="tel:0647150100" use="MC" />
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>
  <!-- Personne de confiance -->
  <informant>
    <relatedEntity classCode="NOK">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111" />
      <addr nullFlavor="NAV" />
      <telecom value="tel:0647150100" use="MC" />
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>
  <!-- Organisation chargée de la conservation du document -->
  <custodian>
    <assignedCustodian>
      <representedCustodianOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
        <!-- Nom de l'organisation -->
        <name>Laboratoire des charmes</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0174589607" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>8</houseNumber>
          <streetName>Rue Frédéric Bastia</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
      </representedCustodianOrganization>
    </assignedCustodian>
  </custodian>
  <!-- Responsable du document -->
  <legalAuthenticator>
    <!-- Date et heure de la prise de responsabilité -->
    <time value="20240104160527+0100" />
    <signatureCode code="S" />
    <assignedEntity>
      <!-- PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="801234534765" />
      <!-- Profession / spécialité du PS -->
      <code code="G15_10/SM03" displayName="Médecin - Biologie médicale (SM)" codeSystem="1.2.250.1.213.1.1.4.5" />
      <!-- Adresse du PS-->
      <addr>
        <houseNumber>8</houseNumber>
        <streetName>Rue Frédéric Bastia</streetName>
        <postalCode>92100</postalCode>
        <city>BOULOGNE-BILLANCOURT</city>
      </addr>
      <!-- Coordonnées télécom du PS-->
      <telecom value="tel:0174589607" use="WP" />
      <!-- Identité du PS -->
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Marcel</given>
          <family>CAMPARINI</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- Etablissement de rattachement du PS -->
      <representedOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
        <!-- Nom de l'organisation -->
        <name>Laboratoire des charmes</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0174589607" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>8</houseNumber>
          <streetName>Rue Frédéric Bastia</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
        <standardIndustryClassCode code="ETABLISSEMENT" displayName="Etablissement de santé" codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="practiceSettingCode" />
      </representedOrganization>
    </assignedEntity>
  </legalAuthenticator>
  <!-- Biologiste ayant validé des résultats présents sur le compte rendu -->
  <authenticator>
    <templateId root="1.3.6.1.4.1.19376.1.3.3.1.5" />
    <time value="202401041120+0100" />
    <signatureCode code="S" />
    <assignedEntity>
      <id root="1.2.250.1.71.4.2.1" extension="801234567898" />
      <addr>
        <houseNumber>8</houseNumber>
        <streetName>Rue Frédéric Bastia</streetName>
        <postalCode>92100</postalCode>
        <city>BOULOGNE-BILLANCOURT</city>
      </addr>
      <telecom value="tel:0174589607" use="WP" />
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Jean</given>
          <family>DE SANTS</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- Etablissement de rattachement du PS -->
      <representedOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
        <!-- Nom de l'organisation -->
        <name>Laboratoire des charmes</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0174589607" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>8</houseNumber>
          <streetName>Rue Frédéric Bastia</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
        <standardIndustryClassCode code="ETABLISSEMENT" displayName="Etablissement de santé" codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="practiceSettingCode" />
      </representedOrganization>
    </assignedEntity>
  </authenticator>
  <!-- Médecin prescripteur des examens de biologie (ici, un gynécologue) -->
  <participant typeCode="REF">
    <templateId root="1.3.6.1.4.1.19376.1.3.3.1.6"/>
    <!-- Date de l'ordonnance -->
    <time xsi:type="IVL_TS">
      <high value="202012310735+0100" />
    </time>
    <associatedEntity classCode="PROV">
      <id root="1.2.250.1.71.4.2.1" extension="801234567892" />
      <code code="G15_10/C25" displayName="Médecin - Gynécologie médicale (C)" codeSystem="1.2.250.1.213.1.1.4.5" />
      <addr nullFlavor="MSK" />
      <telecom value="tel:0147150000" use="EC" />
      <associatedPerson>
        <name>
          <prefix>MME</prefix>
          <given>Eva</given>
          <family>BLUE</family>
          <suffix>DR</suffix>
        </name>
      </associatedPerson>
      <scopingOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120459384" />
        <!-- Nom de l'organisation -->
        <name>Cabinet du DR BLUE</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:014537865" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>12</houseNumber>
          <streetName>Rue Laetitia GREEN</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>
  </participant>
  <!-- Préleveur (ici, une infirmière) -->
  <participant typeCode="PRF">
    <functionCode code="PRELV" displayName="Préleveur" codeSystem="1.2.250.1.213.1.1.4.2.280" />
    <!-- Date et heure de prélèvement -->
    <time xsi:type="IVL_TS">
      <high value="202401040735+0100" />
    </time>
    <associatedEntity classCode="PROV">
      <id root="1.2.250.1.71.4.2.1" extension="801234567893" />
      <code code="G15_60" displayName="Infirmier" codeSystem="1.2.250.1.213.1.1.4.5" />
      <addr>
        <houseNumber>12</houseNumber>
        <streetName>Rue du renard</streetName>
        <postalCode>92100</postalCode>
        <city>BOULOGNE-BILLANCOURT</city>
      </addr>
      <telecom value="tel:0149154578" use="EC" />
      <associatedPerson>
        <name>
          <prefix>MME</prefix>
          <given>Roberta</given>
          <family>BLEEDER</family>
        </name>
      </associatedPerson>
      <scopingOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1120452948" />
        <!-- Nom de l'organisation -->
        <name>Cabinet d'infirmières de BB</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0138475439" use="WP" />
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>12</houseNumber>
          <streetName>Rue du renard</streetName>
          <postalCode>92100</postalCode>
          <city>BOULOGNE-BILLANCOURT</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>
  </participant>
  <!--  Identifiant de la prescription d'examens de biologie reçue par le laboratoire -->
  <inFulfillmentOf>
    <order>
      <id root="1.2.250.1.213.1.1.9" extension="2024123456780" />
    </order>
  </inFulfillmentOf>
  <!--  Acte principal : La demande d'examens enregistrée dans le SI du laboratoire (SGL) et le 1er chapitre du compte rendu -->
  <documentationOf>
    <serviceEvent>
      <id root="1.2.250.1.213.1.1.9" extension="202411111123" />
      <code code="18725-2" displayName="Microbiologie" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
      <lab:statusCode code="completed" />
      <effectiveTime>
        <!-- Date de réception de la demande et des échantillons -->
        <low value="20240104092200+0100" />
        <!-- Date de fin de traitement = date et heure de libération du compte rendu final -->
        <high value="20240104160500+0100" />
      </effectiveTime>
      <!-- Laboratoire exécutant -->
      <performer typeCode="PRF">
        <templateId root="1.3.6.1.4.1.19376.1.3.3.1.7" />
        <time>
          <high value="20240104152530+0100" />
        </time>
        <assignedEntity>
          <!-- Identifiant du directeur du laboratoire -->
          <id root="1.2.250.1.71.4.2.1" extension="801234534765" />
          <code code="G15_10/SM03" displayName="Médecin - Biologie médicale (SM)" codeSystem="1.2.250.1.213.1.1.4.5" />
          <addr>
            <houseNumber>8</houseNumber>
            <streetName>Rue Frédéric Bastia</streetName>
            <postalCode>92100</postalCode>
            <city>BOULOGNE-BILLANCOURT</city>
          </addr>
          <telecom value="tel:0174589607" use="WP" />
          <assignedPerson>
            <name>
              <prefix>M</prefix>
              <given>Marcel</given>
              <family>CAMPARINI</family>
              <suffix>DR</suffix>
            </name>
          </assignedPerson>
          <representedOrganization>
            <!-- Identifiant de l'organisation -->
            <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
            <!-- Nom de l'organisation -->
            <name>Laboratoire des charmes</name>
            <!-- Coordonnées télécom de l'organisation -->
            <telecom value="tel:0174589607" use="WP" />
            <!-- Adresse de l'organisation -->
            <addr>
              <houseNumber>8</houseNumber>
              <streetName>Rue Frédéric Bastia</streetName>
              <postalCode>92100</postalCode>
              <city>BOULOGNE-BILLANCOURT</city>
            </addr>
            <!-- Cadre d'exercice : Laboratoire de ville -->
            <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire" codeSystem="1.2.250.1.213.1.1.4.9" />
          </representedOrganization>
        </assignedEntity>
      </performer>
    </serviceEvent>
  </documentationOf>
  <!-- Contexte de la prise en charge -->
  <componentOf>
    <encompassingEncounter>
      <id root="1.2.250.1.71.4.2.1" extension="801234534765" />
      <code code="AMB" displayName="Ambulatoire (hors établissement)" codeSystem="2.16.840.1.113883.5.4" />
      <effectiveTime>
        <low value="202401040735+0100" />
      </effectiveTime>
      <!-- Biologiste et laboratoire responsable -->
      <responsibleParty>
        <assignedEntity>
          <!-- Identifiant du biologiste responsable -->
          <id root="1.2.250.1.71.4.2.1" extension="801234534765" />
          <!-- Profession / Spécialité du biologiste responsable -->
          <code code="G15_10/SM03" displayName="Médecin - Biologie médicale (SM)" codeSystem="1.2.250.1.213.1.1.4.5" />
          <!-- Adresse du biologiste responsable -->
          <addr>
            <houseNumber>8</houseNumber>
            <streetName>Rue Frédéric Bastia</streetName>
            <postalCode>92100</postalCode>
            <city>BOULOGNE-BILLANCOURT</city>
          </addr>
          <!-- Coordonnées télécom du biologiste responsable -->
          <telecom value="tel:0174589607" use="WP" />
          <!-- Identité du biologiste responsable -->
          <assignedPerson>
            <name>
              <prefix>M</prefix>
              <given>Marcel</given>
              <family>CAMPARINI</family>
              <suffix>DR</suffix>
            </name>
          </assignedPerson>
          <!-- Laboratoire du biologiste responsable -->
          <representedOrganization>
            <!-- Identifiant du laboratoire responsable -->
            <id root="1.2.250.1.71.4.2.2" extension="1120459876" />
            <!-- Numéro d'accréditation du laboratoire responsable  -->
            <id root="1.2.250.1.213.6.3.1" extension="8-WXYZ" assigningAuthorityName="COFRAC" />
            <!-- Nom du laboratoire responsable -->
            <name>Laboratoire des charmes</name>
            <!-- Coordonnées télécom du laboratoire responsable -->
            <telecom value="tel:0174589607" use="WP" />
            <!-- Adresse du laboratoire responsable -->
            <addr>
              <houseNumber>8</houseNumber>
              <streetName>Rue Frédéric Bastia</streetName>
              <postalCode>92100</postalCode>
              <city>BOULOGNE-BILLANCOURT</city>
            </addr>
          </representedOrganization>
        </assignedEntity>
      </responsibleParty>
      <!-- Laboratoire où s’est déroulée la prise en charge -->
      <location>
        <healthCareFacility>
          <!-- Modalité d’exercice -->
          <code code="SA25" displayName="Laboratoire de biologie médicale" codeSystem="1.2.250.1.71.4.2.4">
          </code>
          <!-- Localisation du laboratoire -->
          <location>
            <!-- Nom du laboratoire responsable -->
            <name>Laboratoire des charmes</name>
            <!-- Adresse du laboratoire responsable -->
            <addr>
              <houseNumber>8</houseNumber>
              <streetName>Rue Frédéric Bastia</streetName>
              <postalCode>92100</postalCode>
              <city>BOULOGNE-BILLANCOURT</city>
            </addr>
          </location>
        </healthCareFacility>
      </location>
    </encompassingEncounter>
  </componentOf>
  <!--
    ********************************************************
    Corps du document
    ********************************************************
    -->
  <component>
    <structuredBody>
      <!-- Section FR-CR-BIO-Chapitre : chapitre "Microbiologie" -->
      <component>
        <section>
          <!-- Conformité Laboratory Specialty Section (IHE PALM) -->
          <templateId root="1.3.6.1.4.1.19376.1.3.3.2.1"/>
          <!-- Conformité FR-CR-BIO-Chapitre (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.70"/>
          <code code="18725-2" displayName="Microbiologie" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
          <title>Examen cytobactériologique des urines (ECBU)</title>
          <text>
            <!-- Prélèvement -->
            <table border="0">
              <thead>
                <tr>
                  <th>Prélèvement</th>
                  <th>Nature échantillon</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <content ID="prelevement-code-nabm">EX MICROBIO URINES (ECBU)</content>
                  </td>
                  <td>
                    <content ID="prelevement-nature-echantillon">urine</content>
                  </td>
                  <td>04/01/2024 à 07:35</td>
                </tr>
              </tbody>
            </table>
            <br />
            <!-- Examens directs -->
            <table border="0">
              <thead>
                <tr>
                  <th>
                    <content ID="CBU_EXDIR">Examen macroscopique</content>
                  </th>
                  <th>Résultat</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <content ID="CBU-couleur">Couleur</content>
                  </td>
                  <td>
                    <content ID="CBU-couleur-resultat">paille</content>
                  </td>
                </tr>
                <tr>
                  <td>
                    <content ID="CBU-aspect">Aspect</content>
                  </td>
                  <td>
                    <content ID="CBU-aspect-resultat">clair</content>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
            <!-- Examens microscopiques -->
            <table border="0">
              <thead>
                <tr>
                  <th>
                    <content ID="CBU_MICRO">Microscopie</content>
                  </th>
                  <th>Résultat</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <content ID="CBU-leucocytes">Leucocytes</content>
                  </td>
                  <td>500 /mL</td>
                </tr>
                <tr>
                  <td>
                    <content ID="CBU-erythrocytes">Erythrocytes</content>
                  </td>
                  <td>200 /mL</td>
                </tr>
                <tr>
                  <td>
                    <content ID="CBU-epitheliales">Cellules épithéliales</content>
                  </td>
                  <td>
                    <content ID="CBU-epitheliales-resultat">absence</content>
                  </td>
                </tr>
                <tr>
                  <td>
                    <content ID="CBU-gram">Coloration de Gram</content>
                  </td>
                  <td>
                    <content ID="CBU-gram-resultat">nombreux Gram - ; quelques Gram +</content>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
            <!-- Isolat 1 -->
            <table border="0">
              <thead>
                <tr>
                  <th colspan="2">Isolat : <content ID="isolat-1">Escherichia coli</content></th>
                  <th>Résultat</th>
                  <th>Interprétation</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colspan="2">
                    <content ID="isolat-1-denombrement">Dénombrement de germes</content>
                  </td>
                  <td>100 000 /mL</td>
                  <td>
                  </td>
                </tr>
                <tr>
                  <td rowspan="4">
                    <content ID="isolat-1-antibiogramme">Antibiogramme (CMI)</content>
                  </td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-1-amoxicilline">Amoxicilline</content>
                  </td>
                  <td>&gt;=0,512 µg/ml</td>
                  <td>R</td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-1-ampicilline">Ampicilline</content>
                  </td>
                  <td>&lt;0,128 µg/ml</td>
                  <td>I</td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-1-gentamicine">Gentamicine</content>
                  </td>
                  <td>&lt;0,0032 µg/ml</td>
                  <td>S</td>
                </tr>
              </tbody>
            </table>
            <br />
            <!-- Isolat 2 -->
            <table border="0">
              <thead>
                <tr>
                  <th colspan="2">Isolat : <content ID="isolat-2">Streptococcus D.</content></th>
                  <th>Résultat</th>
                  <th>Interprétation</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colspan="2">
                    <content ID="isolat-2-denombrement">Dénombrement de germes</content>
                  </td>
                  <td>200 000 /mL</td>
                  <td>
                  </td>
                </tr>
                <tr>
                  <td rowspan="4">
                    <content ID="isolat-2-antibiogramme">Antibiogramme (CMI)</content>
                  </td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-2-amoxicilline">Amoxicilline</content>
                  </td>
                  <td>&lt;0,012 µg/ml</td>
                  <td>S</td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-2-ampicilline">Ampicilline</content>
                  </td>
                  <td>&lt;0,013 µg/ml</td>
                  <td>S</td>
                </tr>
                <tr>
                  <td>
                    <content ID="isolat-2-gentamicine">Gentamicine</content>
                  </td>
                  <td>&lt;0,014 µg/ml</td>
                  <td>S</td>
                </tr>
              </tbody>
            </table>
            <br />
            <paragraph styleCode="bold" ID="C_ECBU">Traitement immédiat</paragraph>
            <paragraph>Résultats validés par Jean DE SANTS - 4 janvier 2024, 11h20</paragraph>
            <br /></text>
          <!-- Entrée FR-Resultats-examens-de-biologie-medicale : RESULTATS DE L'ECBU -->
          <entry typeCode="DRIV">
            <!-- Conformité Laboratory Report Data Processing Entry (IHE PALM) -->
            <templateId root="1.3.6.1.4.1.19376.1.3.1"/>
            <!-- Conformité FR-Resultats-examens-de-biologie-medicale (CI-SIS) -->
            <templateId root="1.2.250.1.213.1.1.3.21"/>
            <act classCode="ACT" moodCode="EVN">
              <code code="18725-2" displayName="Microbiologie" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <statusCode code="completed" />
              <!-- Elément FR-Participant : Biologiste ayant validé les résultats -->
              <participant typeCode="AUTHEN">
                <!-- Conformité participant (IHE PALM) -->
                <templateId root="1.3.6.1.4.1.19376.1.3.3.1.5"/>
                <!-- Conformité FR-Participant (CI-SIS) -->
                <templateId root="1.2.250.1.213.1.1.3.109"/>
                <time>
                  <high value="202401041120+0100" />
                </time>
                <participantRole>
                  <id root="1.2.250.1.71.4.2.1" extension="801234567898" />
                  <addr>
                    <houseNumber>8</houseNumber>
                    <streetName>Rue Frédéric Bastia</streetName>
                    <postalCode>92100</postalCode>
                    <city>BOULOGNE-BILLANCOURT</city>
                  </addr>
                  <telecom value="tel:0174589607" use="WP" />
                  <playingEntity>
                    <name>
                      <prefix>M</prefix>
                      <given>Jean</given>
                      <family>DE SANTS</family>
                      <suffix>DR</suffix>
                    </name>
                  </playingEntity>
                </participantRole>
              </participant>
              <!-- Entrée FR-Prelevement : Prélèvement d'urine -->
              <entryRelationship typeCode="COMP">
                <procedure classCode="PROC" moodCode="EVN">
                  <!-- Conformité Specimen Collection (IHE PALM) -->
                  <templateId root="1.3.6.1.4.1.19376.1.3.1.2"/>
                  <!-- Conformité FR-Prelevement (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.77"/>
                  <!-- Code affiné NABM de l'acte -->
                  <code code="5201" displayName="EX MICROBIO URINES (ECBU)" codeSystem="1.2.250.1.213.2.7" codeSystemName="NABM">
                    <originalText><reference value="#prelevement-code-nabm" /></originalText>
                  </code>
                  <!-- Date et heure du prélèvement -->
                  <effectiveTime>
                    <high value="202401040735+0100" />
                  </effectiveTime>
                  <!-- Echantillon prélevé -->
                  <participant typeCode="PRD">
                    <participantRole classCode="SPEC">
                      <!-- Identifiant de l'échantillon -->
                      <id root="1.2.250.1.71.4.2.1" extension="801234567893" />
                      <!-- Nature de l'échantillon : valeur issue du jdv-specimen-type-cisis (1.2.250.1.213.1.1.5.819) -->
                      <playingEntity>
                        <code code="UR" displayName="Urine" codeSystem="2.16.840.1.113883.18.311">
                          <originalText><reference value="#prelevement-nature-echantillon" /></originalText>
                        </code>
                      </playingEntity>
                    </participantRole>
                  </participant>
                  <!-- Entrée FR-Echantillon-date-reception : Date et heure de réception au laboratoire -->
                  <entryRelationship typeCode="COMP">
                    <act classCode="ACT" moodCode="EVN">
                      <!-- Conformité Specimen Received (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.3" />
                      <!-- Conformité FR-Echantillon-date-reception (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.107" />
                      <code code="SPRECEIVE" displayName="Échantillon reçu" codeSystem="1.3.5.1.4.1.19376.1.5.3.2" codeSystemName="IHEActCode" />
                      <effectiveTime value="202401040752+0100" />
                    </act>
                  </entryRelationship>
                </procedure>
              </entryRelationship>
              <!-- Entrée FR-Batterie-examens-de-biologie-medicale : EXAMEN DIRECT (MACROSCOPIQUE) -->
              <entryRelationship typeCode="COMP">
                <organizer classCode="BATTERY" moodCode="EVN">
                  <!-- Conformité Laboratory Battery Organizer (IHE PALM) -->
                  <templateId root="1.3.6.1.4.1.19376.1.3.1.4"/>
                  <!-- Conformité FR-Batterie-examens-de-biologie-medicale (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.78"/>
                  <code>
                    <originalText><reference value="#CBU_EXDIR" /></originalText>
                    <translation code="4" displayName="Examen macroscopique" codeSystem="2.16.840.1.113883.5.84" codeSystemName="HL7:ObservationMethod"/>                    
                  </code>  
                  <statusCode code="completed" />
                  <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Couleur -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="5778-6" codeSystem="2.16.840.1.113883.6.1" displayName="Couleur [Type] Urine ; Résultat nominal">
                        <originalText><reference value="#CBU-couleur" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="CD">
                        <originalText><reference value="#CBU-couleur-resultat" /></originalText>
                      </value>
                      <methodCode code="MA" displayName="Observation macroscopique" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Aspect -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="5767-9" codeSystem="2.16.840.1.113883.6.1" displayName="Aspect [Aspect] Urine ; Résultat nominal">
                        <originalText><reference value="#CBU-aspect" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="CD">
                        <originalText><reference value="#CBU-aspect-resultat" /></originalText>
                      </value>
                      <methodCode code="MA" displayName="Observation macroscopique" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                </organizer>
              </entryRelationship>
              <!-- Entrée FR-Batterie-examens-de-biologie-medicale : EXAMEN MICROSCOPIQUE -->
              <entryRelationship typeCode="COMP">
                <organizer classCode="BATTERY" moodCode="EVN">
                  <!-- Conformité Laboratory Battery Organizer (IHE PALM) -->
                  <templateId root="1.3.6.1.4.1.19376.1.3.1.4"/>
                  <!-- Conformité FR-Batterie-examens-de-biologie-medicale (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.78"/>
                  <code>
                    <originalText><reference value="#CBU_MICRO" /></originalText>
                    <translation code="107" displayName="Microscopie" codeSystem="2.16.840.1.113883.5.84" codeSystemName="HL7:ObservationMethod"/>
                  </code>
                  <statusCode code="completed" />
                  <!-- entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Leucocytes -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="30405-5" codeSystem="2.16.840.1.113883.6.1" displayName="Leucocytes [Nombre/Volume] Urine ; Numérique ; Comptage manuel">
                        <originalText><reference value="#CBU-leucocytes" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="PQ" value="500" unit="/mL" />
                      <methodCode code="DC" displayName="Cytométrie en flux" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Érythrocytes -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="30391-7" codeSystem="2.16.840.1.113883.6.1" displayName="Érythrocytes [Nombre/Volume] Urine ; Numérique">
                        <originalText><reference value="#CBU-erythrocytes" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="PQ" value="200" unit="/mL" />
                      <methodCode code="DC" displayName="Cytométrie en flux" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Cellules épithéliales -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="30383-4" codeSystem="2.16.840.1.113883.6.1" displayName="Cellules épithéliales [Nombre/Volume] Urine ; Numérique">
                        <originalText><reference value="#CBU-epitheliales" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="CD">
                        <originalText><reference value="#CBU-epitheliales-resultat" /></originalText>
                      </value>
                      <methodCode code="MI" displayName="Observation microscopique" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Coloration Gram -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="653-6" codeSystem="2.16.840.1.113883.6.1" displayName="Observation microscopique [Identification] Urine ; Résultat nominal ; Coloration Gram">
                        <originalText><reference value="#CBU-gram" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104131933+0100" />
                      <value xsi:type="CD">
                        <originalText><reference value="#CBU-gram-resultat" /></originalText>
                      </value>
                      <methodCode code="MI" displayName="Observation microscopique" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                </organizer>
              </entryRelationship>
              <!-- Entrée FR-Isolat-microbiologique : ESCHERICHIA COLI -->
              <entryRelationship typeCode="COMP">
                <organizer classCode="CLUSTER" moodCode="EVN">
                  <!-- Conformité Laboratory Isolate Organizer (IHE PALM) -->
                  <templateId root="1.3.6.1.4.1.19376.1.3.1.5" />
                  <!-- Conformité FR-Isolat-microbiologique (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.79" />
                  <statusCode code="completed" />
                  <effectiveTime value="20240104155000+0100" />
                  <!-- Germe identifié -->
                  <specimen typeCode="SPC">
                    <specimenRole classCode="SPEC">
                      <id root="6E281244-000B-4ACB-9ED8-0826543A9694" />
                      <specimenPlayingEntity classCode="MIC">
                        <!-- code de l'agent infectieux (SNOMED-CT) -->
                        <code code="112283007" displayName="Escherichia coli (organism)" codeSystem="2.16.840.1.113883.6.96" codeSystemName="SNOMED CT">
                          <!-- Précision sur l'agent infectieux -->
                          <originalText><reference value="#isolat-1" /></originalText>
                          <!-- code de l'agent infectieux (NCBI-Taxonomy) -->
                          <translation code="562" displayName="Escherichia coli" codeSystem="2.16.840.1.113883.3.9471" codeSystemName="NCBI-Taxonomy"/>
                        </code>
                      </specimenPlayingEntity>
                    </specimenRole>
                  </specimen>                  
                  <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Dénombrement -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="51480-2" codeSystem="2.16.840.1.113883.6.1" displayName="Bactérie [Nombre/Volume] Urine ; Numérique ; Comptage automate">
                        <originalText><reference value="#isolat-1-denombrement" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104155000+0100" />
                      <value xsi:type="PQ" value="100000" unit="/mL" />
                      <methodCode code="DC" displayName="Cytométrie en flux" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- Entrée FR-Batterie-examens-de-biologie : Résultats de l’antibiogramme -->
                  <component>
                    <organizer classCode="BATTERY" moodCode="EVN">
                      <!-- Conformité Laboratory Battery Organizer (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.4"/>
                      <!-- Conformité FR-Batterie-examens-de-biologie-medicale (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.78"/>
                      <code code="18769-0" displayName="Antibiogramme" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC">
                        <originalText><reference value="#isolat-1-antibiogramme" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Amoxicilline -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="20-8" codeSystem="2.16.840.1.113883.6.1" displayName="Amoxicilline+clavulanate [Sensibilité] Isolat ; Alphanumérique ; CMI">
                            <originalText><reference value="#isolat-1-amoxicilline" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <low value="0.512" unit="ug/mL" inclusive="true" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="R" displayName="Résistant" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Ampicilline -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="28-1" codeSystem="2.16.840.1.113883.6.1" displayName="Ampicilline [Sensibilité] Isolat ; Alphanumérique ; CMI">
                            <originalText><reference value="#isolat-1-ampicilline" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <high value="0.128" unit="ug/mL" inclusive="false" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="I" displayName="Intermédiaire" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Gentamicine -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="18928-2" codeSystem="2.16.840.1.113883.6.1" displayName="Gentamicine [Sensibilité] Isolat ; Alphanumérique">
                            <originalText><reference value="#isolat-1-gentamicine" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <high value="0.032" unit="ug/mL" inclusive="false" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="S" displayName="Sensible" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                    </organizer>
                  </component>
                </organizer>
              </entryRelationship>
              <!-- Entrée FR-Isolat-microbiologique : STREPTOCOCCUS D -->
              <entryRelationship typeCode="COMP">
                <organizer classCode="CLUSTER" moodCode="EVN">
                  <!-- Conformité Laboratory Isolate Organizer (IHE PALM) -->
                  <templateId root="1.3.6.1.4.1.19376.1.3.1.5" />
                  <!-- Conformité FR-Isolat-microbiologique (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.79" />
                  <statusCode code="completed" />
                  <effectiveTime value="20240104155000+0100" />
                  <!-- Germe identifié -->
                  <specimen typeCode="SPC">
                    <specimenRole classCode="SPEC">
                      <id extension="55584739" root="1.3.6.1.4.1.19376.1.3.4" />
                      <specimenPlayingEntity classCode="MIC">
                        <!-- code de l'agent infectieux (SNOMED-CT) -->
                        <code code="58800005" displayName="Genus Streptococcus (organism)" codeSystem="2.16.840.1.113883.6.96" codeSystemName="SNOMED CT">
                          <!-- Précision sur l'agent infectieux -->
                          <originalText><reference value="#isolat-2" /></originalText>                          
                          <!-- code de l'agent infectieux (NCBI-Taxonomy) -->
                          <translation code="1306" displayName="Streptococcus sp." codeSystem="2.16.840.1.113883.3.9471" codeSystemName="NCBI-Taxonomy"/>
                        </code>
                      </specimenPlayingEntity>
                    </specimenRole>
                  </specimen>
                  <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Dénombrement -->
                  <component>
                    <observation classCode="OBS" moodCode="EVN">
                      <!-- Conformité Laboratory Observation (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                      <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.80"/>
                      <code code="51480-2" codeSystem="2.16.840.1.113883.6.1" displayName="Bactérie [Nombre/Volume] Urine ; Numérique ; Comptage automate">
                        <originalText><reference value="#isolat-2-denombrement" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <effectiveTime value="20240104155000+0100" />
                      <value xsi:type="PQ" value="200000" unit="/mL" />
                      <methodCode code="DC" displayName="Cytométrie en flux" 
                        codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs"/>
                    </observation>
                  </component>
                  <!-- Entrée FR-Batterie-examens-de-biologie : Résultats de l’antibiogramme -->
                  <component>
                    <organizer classCode="BATTERY" moodCode="EVN">
                      <!-- Conformité Laboratory Battery Organizer (IHE PALM) -->
                      <templateId root="1.3.6.1.4.1.19376.1.3.1.4"/>
                      <!-- Conformité FR-Batterie-examens-de-biologie-medicale (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.78"/>
                      <code code="18769-0" displayName="Antibiogramme" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC">
                        <originalText><reference value="#isolat-2-antibiogramme" /></originalText>
                      </code>
                      <statusCode code="completed" />
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Amoxicilline -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="20-8" codeSystem="2.16.840.1.113883.6.1" displayName="Amoxicilline+clavulanate [Sensibilité] Isolat ; Alphanumérique ; CMI">
                            <originalText><reference value="#isolat-2-amoxicilline" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <high value="0.012" unit="ug/mL" inclusive="false" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="S" displayName="Sensible" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Ampicilline -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="28-1" codeSystem="2.16.840.1.113883.6.1" displayName="Ampicilline [Sensibilité] Isolat ; Alphanumérique ; CMI">
                            <originalText><reference value="#isolat-2-ampicilline" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <high value="0.013" unit="ug/mL" inclusive="false" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="S" displayName="Sensible" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                      <!-- Entrée FR-Resultat-examens-de-biologie-element-clinique-pertinent : Gentamicine -->
                      <component>
                        <observation classCode="OBS" moodCode="EVN">
                          <!-- Conformité Laboratory Observation (IHE PALM) -->
                          <templateId root="1.3.6.1.4.1.19376.1.3.1.6"/>
                          <!-- Conformité FR-Resultat-examens-de-biologie-element-clinique-pertinent (CI-SIS) -->
                          <templateId root="1.2.250.1.213.1.1.3.80"/>
                          <code code="18928-2" codeSystem="2.16.840.1.113883.6.1" displayName="Gentamicine [Sensibilité] Isolat ; Alphanumérique">
                            <originalText><reference value="#isolat-2-gentamicine" /></originalText>
                          </code>
                          <statusCode code="completed" />
                          <effectiveTime value="20240104155000+0100" />
                          <value xsi:type="IVL_PQ">
                            <high value="0.014" unit="ug/mL" inclusive="false" />
                          </value>
                          <!-- Interprétation : valeur issue du jdv-hl7-ObservationInterpretation-cisis (2.16.840.1.113883.1.11.78) -->
                          <interpretationCode code="S" displayName="Sensible" codeSystem="2.16.840.1.113883.5.83" />
                          <methodCode code="BDB" displayName="Antibiogramme - bandette gradient" 
                            codeSystem="1.2.250.1.213.2.3.5" codeSystemName="ANSM – Table de codage commune des réactifs">
                          </methodCode>
                        </observation>
                      </component>
                    </organizer>
                  </component>
                </organizer>
              </entryRelationship>
              <!-- COMMENTAIRE SUR L'ECBU -->
              <entryRelationship typeCode="SUBJ">
                <act classCode="ACT" moodCode="EVN">
                  <!-- Conformité Comment (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.40"/>
                  <!-- Conformité Comment Entry (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.2"/>
                  <!-- Conformité FR-Commentaire-ER (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.32"/>
                  <code code="48767-8" displayName="Commentaire" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
                  <text><reference value="#C_ECBU" /></text>
                  <statusCode code="completed" />
                </act>
              </entryRelationship>
            </act>
          </entry>
        </section>
      </component>

      <!-- [0..1] FR-Document-PDF-copie-->
      <component>
        <section>
          <!-- Conformité FR-Document-PDF-copie (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.243"/>
          <id root="770B0DC2-A6B8-468E-8432-632B18D35F68"/>
          <code code="55108-5" displayName="Copie du document"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Copie du document</title>
          <text>
            <table border="0">							
              <tbody>
                <tr>
                  <td><content ID="titre-copie-pdf">Copie PDF du document</content></td>
                </tr>
                <tr>
                  <td><renderMultiMedia referencedObject="copie-pdf"/></td>
                </tr>
              </tbody>
            </table>
          </text>
          
          <!-- [1..1] Entrée FR-Document-attache -->
          <entry>
            <organizer classCode="CLUSTER" moodCode="EVN">
              <!-- Conformité FR-Document-attache (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.18"/>
              <id root="88BEB395-3B4C-37F5-9A31-03BEA73A8D8B"/>
              <code code="55107-7" displayName="Document attaché"
                codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <statusCode code="completed"/>
              <!-- [1..1] Entrée FR-Type-document-attache -->
              <component>
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-Observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Type-document-attache (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.18"/>
                  <id root="0D1629B3-CC69-4632-81F3-2301FD4C318B"/>
                  <code code="69764-9" displayName="Type de document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#titre-copie-pdf"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime nullFlavor="NA"/>
                  <value xsi:type="CD" code="55108-5" displayName="Copie du document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                </observation>
              </component>
              <!-- [1..1] Entrée ObservationMedia -->
              <component>
                <observationMedia classCode="OBS" moodCode="EVN" ID="copie-pdf">
                  <value mediaType="application/pdf" representation="B64">
                    JVBERi0xLjQNJeLjz9MNCjEwIDAgb2JqDTw8L0xpbmVhcml6ZWQgMS9MIDEwMjgyNi9PIDEyL0UgODc5ODEvTiAzL1QgMTAyNTA2L0ggWyA5NzYgMjc2XT4+DWVuZG9iag0gICAgICAgICAgICAgICAgDQp4cmVmDQoxMCAzNA0KMDAwMDAwMDAxNiAwMDAwMCBuDQowMDAwMDAxMjUyIDAwMDAwIG4NCjAwMDAwMDE0ODAgMDAwMDAgbg0KMDAwMDAwMTcxNCAwMDAwMCBuDQowMDAwMDAxODcwIDAwMDAwIG4NCjAwMDAwMDE5OTggMDAwMDAgbg0KMDAwMDAwMjEyNiAwMDAwMCBuDQowMDAwMDAyMTYxIDAwMDAwIG4NCjAwMDAwMDI3OTQgMDAwMDAgbg0KMDAwMDAwMzM0NyAwMDAwMCBuDQowMDAwMDA1MzQzIDAwMDAwIG4NCjAwMDAwMDYzOTYgMDAwMDAgbg0KMDAwMDAwNzQ1NiAwMDAwMCBuDQowMDAwMDA4NTA4IDAwMDAwIG4NCjAwMDAwMDg2NTAgMDAwMDAgbg0KMDAwMDAwOTAzNiAwMDAwMCBuDQowMDAwMDEwMDg3IDAwMDAwIG4NCjAwMDAwMTI5NTggMDAwMDAgbg0KMDAwMDAxNTA0NSAwMDAwMCBuDQowMDAwMDE4NDAxIDAwMDAwIG4NCjAwMDAwMTkxMDYgMDAwMDAgbg0KMDAwMDAyMTY1MyAwMDAwMCBuDQowMDAwMDIxNzMzIDAwMDAwIG4NCjAwMDAwNTAyMDMgMDAwMDAgbg0KMDAwMDA1MDQ3NiAwMDAwMCBuDQowMDAwMDUxMzQ3IDAwMDAwIG4NCjAwMDAwNTE0MjcgMDAwMDAgbg0KMDAwMDA2OTQ5NCAwMDAwMCBuDQowMDAwMDY5NzY3IDAwMDAwIG4NCjAwMDAwNzA0NTcgMDAwMDAgbg0KMDAwMDA3MDUzNyAwMDAwMCBuDQowMDAwMDg3MzMyIDAwMDAwIG4NCjAwMDAwODc2MTkgMDAwMDAgbg0KMDAwMDAwMDk3NiAwMDAwMCBuDQp0cmFpbGVyDQo8PC9TaXplIDQ0L1Jvb3QgMTEgMCBSL0luZm8gOSAwIFIvSURbPDRFNTQ1QTUxMzE0OTU4NTU0NDUyNTAzMTRENDE0QTVBPjw3MTVERjhBNTc5RjA0OTQzQkU0RDgxNTlCODY4Q0M3RT5dL1ByZXYgMTAyNDk1Pj4NCnN0YXJ0eHJlZg0KMA0KJSVFT0YNCiAgICAgICAgICAgICANCjQzIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9JIDIzMi9MIDIxNi9MZW5ndGggMTg4L1MgMTI5Pj5zdHJlYW0NCmjeYmBgYGJgYNnCwMrAwLmEQZABAQSBYqwMLAwcLxiWKDRtc2Bg2LqGAQWoaPRYnCpZu77ndc37GRumuEkqa17ats947ed9SQeA0i4dEABkdsCZTDAm1EwkIA/FDAzKDPyMfYxPmF6wXmBgmNrIzL6S/YsAi/wJtg3aD/6xdnGwSH7iqvBrYLr7KMG6cRGDbs8D5h0iFUw39BnsGRY3QI1jZWAs2QWkGYHYCIg5GRj7OqD8wwABBgAj1T0cDQplbmRzdHJlYW0NZW5kb2JqDTExIDAgb2JqDTw8L0xhbmcoeC11bmtub3duKS9NZXRhZGF0YSA3IDAgUi9PdXRwdXRJbnRlbnRzWzw8L0Rlc3RPdXRwdXRQcm9maWxlIDggMCBSL0luZm8oR2VuZXJpYyBSR0IgUHJvZmlsZSkvT3V0cHV0Q29uZGl0aW9uSWRlbnRpZmllcihDdXN0b20pL1MvR1RTX1BERkExL1R5cGUvT3V0cHV0SW50ZW50Pj5dL1BhZ2VMYWJlbHMgNSAwIFIvUGFnZXMgNiAwIFIvVHlwZS9DYXRhbG9nPj4NZW5kb2JqDTEyIDAgb2JqDTw8L0JsZWVkQm94WzAgMCA1OTQuNzIgNzkyXS9Db250ZW50c1sxOSAwIFIgMjAgMCBSIDIxIDAgUiAyMiAwIFIgMjUgMCBSIDI2IDAgUiAyNyAwIFIgMjggMCBSXS9Dcm9wQm94WzAgMCA1OTQuNzIgNzkyXS9NZWRpYUJveFswIDAgNTk0LjcyIDc5Ml0vUGFyZW50IDYgMCBSL1Jlc291cmNlcyAxMyAwIFIvUm90YXRlIDAvVHJpbUJveFswIDAgNTk0LjcyIDc5Ml0vVHlwZS9QYWdlPj4NZW5kb2JqDTEzIDAgb2JqDTw8L0NvbG9yU3BhY2U8PC9EZWZhdWx0R3JheVsvSUNDQmFzZWQgMjkgMCBSXS9EZWZhdWx0UkdCIDE2IDAgUj4+L0ZvbnQ8PC9GMSAxNCAwIFIvRjMgMTUgMCBSL0Y1IDIzIDAgUj4+L1Byb2NTZXRbL1BERi9JbWFnZUIvSW1hZ2VDL1RleHRdPj4NZW5kb2JqDTE0IDAgb2JqDTw8L0Jhc2VGb250L1pETFVUQytBcmlhbC9EZXNjZW5kYW50Rm9udHNbMzQgMCBSXS9FbmNvZGluZy9JZGVudGl0eS1IL1N1YnR5cGUvVHlwZTAvVG9Vbmljb2RlIDE3IDAgUi9UeXBlL0ZvbnQ+Pg1lbmRvYmoNMTUgMCBvYmoNPDwvQmFzZUZvbnQvWUlDR0dMK0FyaWFsL0Rlc2NlbmRhbnRGb250c1szOCAwIFJdL0VuY29kaW5nL0lkZW50aXR5LUgvU3VidHlwZS9UeXBlMC9Ub1VuaWNvZGUgMTggMCBSL1R5cGUvRm9udD4+DWVuZG9iag0xNiAwIG9iag1bL0lDQ0Jhc2VkIDMwIDAgUl0NZW5kb2JqDTE3IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggNTYzPj5zdHJlYW0NCnheXZTLjqMwEEX3kfIPXvYsWontArqlCClPKYt5qDPzAQScDNIEECGL/P3A9a3WaFgkOmC76lRBLbbH3bGpB7P40bflKQzmUjdVH+7toy+DOYdr3cxn1pqqLgdDxF95K7r5bNp/et6HcDs2l3Y+W63M4mN8fB/6p3lZV+05fBlXfe+r0NfN1bz82p6mG6dH1/0Jt9AMZjmf5bmpwmU67WvRfStuwSyw9fVYjSvq4fk6bvtnyc9nF4yLN2zMqmyrcO+KMvRFcw1jIsvxyleH8crns9BU/y/I0rjxfCl/F33cYPPx10seyU3kliQ/UbomCciSEtCelE6UpaQMz95Jb6CE9I6VjrRGdKUNSKNvQRpvh8y2pD2eabwDiHnaJYjxbPTLSNFvQ4JfogQ/YSUs/ORAgp/sSPAT+ln4CSth4Zcwawu/RHOBnyjBL9Ez4Sc0sjDaM4KDUcqVLhq9kaIR83Qw8p4EI6+nwMjpPhilujJ2TE+JHWMlXDTSlTDK2AcXjZRglLKbDkapPkPHnOYCP2GVPPwS9s/DL+EpPvrR3cMvY2Yefhkz8zDa8+3xsUdKMMqUYOTYMQ+jlJX3MEpZJR+N+PZ4GGXsn4eRaHQYJYwg0YinCIyERgKjjJUQGAkjSDTSfeiY5/sp8RtjzQR+ng4CP88qCfw2zFPiN8Y+CPwSVlDgJ6y8xG9Mc4FfwlGiI2OaKpiCn2OrfPT9OLEwLDGpphlVN+FzoHZth338+QuxdDbGDQplbmRzdHJlYW0NZW5kb2JqDTE4IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggNDgzPj5zdHJlYW0NCnheXZTJbqNAFEX3SPxDLdOLyK4JEslCcnuQvOhB7e4PwFB2kGJAZbzw33dx61YUhQXo8sbzisdic9ge+m4Si99+aI5uEueub727DXffOHFyl67PMylF2zWToMSjudZjns3xx8dtctdDfx7ybLUSiz/BfJv8Qzyt2+HkvgWvX751vusv4unf5ji/ON7H8d1dXT+JZZ5VlWjdec72ox5/1lcnFgh9PrTBo5sezyHsk8vfx+iEii9k7KoZWncb68b5ur+40MgyXNVqH64qz1zffnWwRQw8nZu32scAWYW70VVUalbFnkpDbanMrMollYUyVAU8LVU5K5U8X+CpqF7huaNaQ6Us3+GZsmyQpaTawvZCtUOcpNrDRga5hI31JPiKV6rIt6GKfKwgIx9zSvAZ9ikjX6oAPks+CT6T4sBnSSTBpzhBCT6bOgOf4awl+EzqE3yW9RSIdrQpEClOQoFIJRuIDKsrEBlWVyCy7FOByHLWCkQmqUjEKal4YqkeiMpUD0SGRAoMu+QJhrKgwhnpdVQaRIrT1fEbTLZ4RozTILJJgUixMw0iTVodzyhlAZFmZxpEmiemQaQ5CQ0iM1cIK5NWY94ebPvHejZ378Nm4qeAjZx3sevdx49jHEbE8fYf+dABRg0KZW5kc3RyZWFtDWVuZG9iag0xOSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDE5MjU+PnN0cmVhbQ0KSInsV1tv1EYUni4lkbJKQrgEWm4Gwq1tJnO3/QotlfpQqSVSH7o8ACXqA41ESFX13/eMx961vXHsEJ+cTbE2G3u843P9zvnOfFhdkZGAz7a/xKmK3v61uvKheCojabgR+X//08737/Ze//3+8Ncfn0VvP66uiIgr+MKvH9/ur64824UtL3SURLt7JdFKCu5cJB1PjIl2Qc7vT9gXbMQusC/ZRbbEltnkDVwmh2yyz8Z+uc8me/7JAVuDXdlP6/D8EtuA1y7D9wrcXYW9S2z96ato96eyukSCoiRSmgsnC33L+badF3LOPhXzWEQq5SpOGu0DE0bBvmAd2Dby1zWwbAyWrfvnwbyxfz5m40JlHrUfD17/m4ctC5c3RaqqLSLSjlsZF2aMchk/7FYSo3ga20gbHqu4SJpPRqIjWMjU8ThNwvr9bJ3yJDwQ5dti12+rK/vzKeaJAxU8NWCpDHbnr8ykOhEdvFtdAT9+qVi5zaVREfyTmY3+IVy2swfhf2ZczEWi5h+IwvTURJkgWBYCs8WfdZuzAD9/6TW9fP4zxO8VCPkD3vLm/lNo5kIIG8IUFIUHIPBl3YGZ9sIDGZLkPyWXfDRNMDjlccnE09krZrYGDa2WQqUJZTPTtkuYqhiLF19xktgGcJQMzmw9IriiBI2we7rGj3uuseZGU6PjiTZRzKWa1u+1rI1kHS3rI4fQLzagV6zDFRabbKlU4NUAKQG6bXOV+z6noMEV9VusT1Ll05ZULe2ZqJOVdilVXoQ1dv6BKBZG6P7zVWhpxl1J9aIXdWFql6pelPB2Lmui8H7iCDNf2dfZDfYV+xq+N9ktdpvdaS7kjKyNgWJKzxtZLwhZDES8WEQconCGPHxk2E9SrDDBR2GGv8DuAf3ePx0pN1XzApLyojDDQLwD8fZBvA+AbreAcK/B9yF7xB7nxbrzQtbfNikUa1J9fcSu5C9Mt1nNrXDVbVdB/mZG8tczmr9ZfymF4OnqO7daRgBruEnlMAIMI8CCxfZzGAHuANdPDjpQe1OVDtQ+UPtA7Z9M7XPkfESN3mZ3YUpfZhf9t4VMneEaCHgg04FMFyu2nwOZPmBrUKRLUKaT/XA5hCcbbB0+a36x2YFomyp4INqBaAeiRSVaqNp77D4bQyHfZ5M9tgW1u9VCuLHhytqBcAfCXbDYnl/CBSdCcUquQzHFGmotydfvp+uExzkXZttry+nuzkVVfi+W4J/vD6ZcWN1ngckTaB5L0EuOGwbYcqm7fKj56bNsFbd65km+njpaj0M9Tp09r7wYJ9xadbTrc200f7Pi+0P2iD32EZi8YSN2nd1gk6fsJnxG7Bv4fgvB+M7/tg2fu4y3jkRNPXYYiYaRaBiJUEeiNZiFoH/B3ziv3k22wwS7BmUtoaInT1vmo8RwqePu85HW3KZpqNjy/WknJJClpfsfz0jgoBPBWLg1Nunf2KCi1VTYFufGno8hqWRwhyEpRKG2PPu4dx9FtqCKL3q+3YDiHbPL2TRyG0r4TivzNlVvE/OerHpbuPfkJbso9NCZfRegaAtbu1TtosS3c9lSxbc3/gXi3YACHgMNX2KTvYyL98LtPXjuvyN2pZixFVw8L4+mw7f2FwOXW3mt15RJqDE45uTaRg2bHJcw49c2zXcN4xPnudbwWE27xvElW+qk0GwcBLG8Ni4fnuBeK4TpKdfZDLWZ4uMrOVg9tT2cO2pLMbvtx5EgvzIK6m5Tq2mdWqfm+horLBS9jaxzdh4NJQNQsnUk5TkRxyZEVKOv6ksxu+3fu/aZI+xqS8JZm3l0EiwUiVZDFmiz4Ay30gxZoM1CDPFO3ZAF2ixAvBVMJKfMQnZCSebWonTfr4eF0PbB1m9rGWwpTG2Y9yxsS4tsNCkr3oq5FXEkuZvyeu5TnGMLrnHuSXEVze6Uzo9Nmv37QWjlLHke1dbEq+iMfVK9Ky0JNxQeOUyPEgqPZP/IKEvvHwJdfOofG2Xp/YOgi0/9o6NcqTT9AbVBKJIOoVBbhCLpERq1R2iSHqFRe4Qm6REatUcYkh5hcIcIkh5hUHuEIekRFrVHWJIeYVF7hCXpERa1RziSHuFQe4SjOWmg9ghH0iNi1B4RRGMNXr0L78ITmB45Co8STI9k/wjocjDrHxrVoyym9P5BUD2yEuRDkaBAkTQIhYoOhYoORYIOTYIOjdojNCoKNAlRaBJ0GBJ0GFR0mP7R0e2IS6EVdb6wJOiwqOiwqL3DkqDAoqLAkaDAoaLAkfQIR4IOh4qOGPUUKiJDMGRSKDW9Ky1DAFN4gilc9o+A6lEWUzpqTiVqUmX/We12lKXQSlLwqn90dNGKihpFghqN2iM0CTo0au/QqCjQqIxgULNtaMifpBeY/lHQ7ciKmD9LwiAWdY6wJOiwJOiwJAziSFDjSHqNI0GTQ2UcR4KaGJWJROQQBzVM4aZ34V0AhulRQuGR7B8BXbT2D40uWkkwI1FBI0lQo3D7Bgk6VP/oKEtHRYEiQYFGRYFGpQ+Nmm3df7a75IMEBYaEQQxJjzAkDGJQe4fpHzXloxZqj7AkKLCfgoLoPwEGAJqFNAINCmVuZHN0cmVhbQ1lbmRvYmoNMjAgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA5ODM+PnN0cmVhbQ0KSInEl81qFkEURPcD8w79Bk73/ZnZR3AnSBauQ0hwEQWTuPDtnSBCf99CetEnhUJAoS6dOlP31rKVrTyty7d1+bouP9blw8eHx7tfT6+fnu9+l5vbddnK7c3ndYksWdr55/lhXR7X5cu6/Hz7z618X5e9/VU5f55/n97+/d/PQfWDVM8NVW/T1e9f1qWWl/v/TXX0Tajbibq9o25v5Xh/s5tiqCuG5vShnfiheFGdT0yvLkGjzmejV0chqPMp6L9UTT5IKGiShGgoHU2SESahxiTUGJodhtJhEjoc3SCuOS5QCnw+BSNvktARkuwICTWBUhMSagK9RxLNjpRQkCgFKaEgJdmxo3Rs5ew+738fSqb6/Kk9Haj6gapXDQZVw0EFQBgZyxJSWUSaKCk0iDQNIg1AZGQsi44B6PTyACK9PLs2jE0FA6wdWbWs5S46IFgUnEXBNSiEZnGEBpHQLI5g0QkNOsmmSGoQSbiHsCgkeyvsrOWnepPUXcFUl0zN+VM79QNVrxo8qoaPqgGkAoSMjGXRaaJkAdDp5TWINA0ijUXENIiYJl0MQKeX1yBiACIjqxxAp5cXHSiadHENOs6mS7CIBLtogk2LYK/SYK1NzeJITSoki0KyKKRmQezs13+qu+Aek0x1ydSUTD3mT+0rlwabCnDTy2sAqQAhvTyLQhMlCItC06DQNGHRAERGKheATi/PImIAIr08mwqmsdxZy110WLAoOIuCswsiNAsiNCgEi0KwKASLQmpQSHYRpKhXsCgki8LOLoJTPSW1dvbUy/oqeFOibzpQ9QpgcFVHSXmN4RVwfGQsi0ITJQKAyMhYAJ2rmqp4FYDIYE0Ff5mmQcRYRIzdG6ZBwTUp4hpEnEXENSni7KIJNi2CvTlCc3MEmxbBWp6s5clanqJewVqemgWxsyic6gd41s1XH8ljydSUTD1Q/yqAx0hz03BTNeBUDTkVQGekcsGJA6DTywOI9PIACld1V2C5sZYba7mxlhtruWksd9ZyFx0WLArOouDsrRCaWyE0KASLQrAoBItCsl9/soGfov7AWp6s5Ttr+VbOuxGsqdPVh2qqYmpKph6SqRXAZqy+SsYCQF3WVMmrNOg0OHEARC5rKiqvQaEBKFzWVFRekwrGomAACpf1lZR31nJnv3JnrXXWWtcEe7CWh+YrD80xGSwioUEkWUSSTYUU9QrNTZAaRHYWkVO6oXV3tvpY3QXflJI3HeibKotBBTi4qqOkvMbxClg+WEcVY1lEGotI0yDSNIgYmxbGomAsCqZBwdgF4azlLjoUehTKHwEGAIVDSSQNCmVuZHN0cmVhbQ1lbmRvYmoNMjEgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA5OTA+PnN0cmVhbQ0KSInEl71q3FAQhXuB3kFvkL3zJ/UOpDMYF6mNsUmxCcR2irx9tIaAVkW4BH0+2LCwLGcYnU9nZobncbgbh5/jcJpO0/dxmG39PL9/rv/ny/d/P9+//zYOX8fhxzh8+vz0/PDr/Pbl5eH3dHN/+cH9ze04RE1m0+Xv5WkcjpF/fB2HNr0+/qvsIimbJ01ZO77sVj5YeQ0iCSCykS8NCsWiUAAKPV1pECkWkRlAZCO/qgenbqh6HK/e4zfa04KqN9buxvrdAMO38oCzHTw1wPKOsgag0FOWRcRYREyDiLGp4BoUHEChpyyLiLPzwTVpERpEQoNIsIgEi0iwaZHsDpEay1OzTKZmoCSLSGnSotjdokT3BpsWpRkoM5siq3qhZy2oHser9521gqoL+iQbi0FjOWgACLtzV+B4AyzvPHfJRGBRME0mGIDI7qwF5Z213FnLnX37XfP2O2t5sJYHYHnnOUp2pUEhNIMgAUR6yrJpkZoBkRp0kk2R0iBSmnQp0b2hQadYdGZ2AK3qi2ANPL7q9bkr6KnQnhZJT02DR2P5aBpAGktIAxDZnbukPGu5aSw31nLTpIKzKDiAQk9XACJbeQCFnq7YVAjNgAh4gWBRCDYVQpMKqUEhNWmRLCKpSYtk06LYwVEaFIpFoTQolCZFZhaR03RZXj7+3D286tW5S6qX5IktkqpNg0cD+Ogpy4LTAHKuz13JqwwgspVno8JYy00TFqZBwTVp4SwiziLiGkQcQGQ7gjUohGZwBItIsIMjWBRSg0KyqZCs5clanqzlpbG8WMsLsLynK82AKBaRmV0bV3UD1zpUPY5X7/Eb7WmR9NQADDrPV0VZAJzd+UrKaxAxDSLGRohpMsRYREyDiLPDxDVp4WxaOIuCa1AIFoXQoBAsCgGg0NOVBpFkEUkNIskikhpEEkBku1JrdovSIFIsIsUOlNKkxcymxaoe4D6GqgeqXqj6gqo31tbG+tpYYxvrbGOtNfiNZa011lpjrTXWWmetddZaZ6111lpnrQ3W2oAHLWttsNYGa22y1iZrbbLWJmttstYWa22x1ha8H7PWFmvtzFq7qtfH34p2fNXrc0vQU6E9LZKeGoDH7jxTdAUAsjvbFF0BiOzOOUVSsFFhmqwwNixMkxbOpoVr0sLZtHBNWjibFqFJi4AXC01aBJsWoUmLZNMiNWmRbFqkJi2STYvSpEWxaVGiO4RNi9Kkxcymxaq+gPvY8eo9YwPtqVD1RfLEGotBAzjYnbWKhwaQ0Hnukq8snAgsCsa++6ax3FjLHbC85xJjUXAWBWfngLOWx39ZPv0RYADTBx5MDQplbmRzdHJlYW0NZW5kb2JqDTIyIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggOTgyPj5zdHJlYW0NCkiJxJfNahZREET3A/MO8wbO7b+ZfQR3gmThOoQEF5+CiS58eyeIcPMtwl3MSaEQUKjmps5UdU/rsi6Xefo2T1/n6cc8ffj48Hj3+/Lr09Pdn+Xmdp7W5fbm8zyFLb4vdvx5epinx3n6Mk8/X/53Xb7P02b/ZI6fx9/Ly7////mG/P3zPLXl+f6tsaEZW+eP7eV3yaty1YwF0OnlNYgkgMjIWA06BaDTy2vSpTToFJsuBSDSyW8sCusS6/tbYpKpIZlakqm7ZGrT4NQAnnp5DThNQ07ToGMAOr08i4gBiPTyAAq9vMZyZy13Tcs4i4JrUsE1iISmUIJNi9AUSmjQCQCd/kTTIJKadEk2XZItmtSkSGkQKQ0iJbpzNOlSGqQ2dnc51E2wg58/te8BVL1Q9R1Vbxq7G+t3AwwfeRVLQmNRMACFXh6wfCRYNCgYi4KxKDiLgrNfv7Nx74C1A0Q5a3mwlgdc8KzlobE8WMtT0/3JopCawE828BNAYfB8VYzV7AqlQadYdIpNkY0tjkM9JOeoYGqcP/X1mQqq76h602DQAA6uzlTFq1gSGoDCyCcrSgoWEdMgYiwipkHENYi4pk2crRNnEXENIqFBJNgUCRaFYFEIdrdIjeXJWp6a4kgWhWRRKA0KpSmI0iBSLCKlKY4NQKeTP9QL3MfOVx87dwVTC/1N7pI3NQCPkbEAN728BpAGEDIyVoOOadAxFh3ToGMadEyDjmvQcRYdB9Dp5dn+cQCFvrLZPSREiwhrebCWh+brTxaF1KCQLAqpKYjUIFKagigNOiW6Z9h0KbZQNjZFDvUd3DJR9UDV63z1AVh39E0NsHvkcgM4GBkLADIyFiCnlwcQGTmh4KTQIGIaREwTLqZBx1l0XIOOs/XjbIo4WzShKZqAFw5NWoQmLYJFJDWIpCYtkk2LZNMiNcVRbHEUmxalSYvSpEVpENlYRNbliKn339MkU+P8qT0fkjft6JsagEcvD3DQy7OGN8DxXp611kRfPmu5sZYba7kBlo+dr5KxLArOouCavHcNIqFBJESLAotOaNAJtlBSg0iyKZIACiOv0iCSLCLFrpPFolDw/aCxvFjLN9byQ90k5+vZU1+fqaB6oeq7xI8GYHB1ppLygOEjvzSWhAagcHW+Kr58FgXToGAACiNjNWnhbFo4gMjIq9jacA0izqZIaFIk4AWCRSE0KIQmLVKDSLKIpKZoUoNOsilSGkRKUzQF3ycaREqTLhu7ixzqIdjrJFNDMrXOn9qp76h60+DRNHw0AJBeHiBh5FUAIiOfuChZenSWvwIMANRmbykNCmVuZHN0cmVhbQ1lbmRvYmoNMjMgMCBvYmoNPDwvQmFzZUZvbnQvSFBKTVZVK1RpbWVzIzIwTmV3IzIwUm9tYW4vRGVzY2VuZGFudEZvbnRzWzQyIDAgUl0vRW5jb2RpbmcvSWRlbnRpdHktSC9TdWJ0eXBlL1R5cGUwL1RvVW5pY29kZSAyNCAwIFIvVHlwZS9Gb250Pj4NZW5kb2JqDTI0IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMzE2Pj5zdHJlYW0NCnheXZJNbsMgEIX3lnwHlukisnESJ5EiS6mTSF70R3V7AAfGqaUaI0wWvn1hGEdVWYA+eG8YZkjK6lSpzrLk3QyiBsvaTkkD43A3AtgVbp2KI86Z7IRlhLiIvtFx5P31NFroK9UOcXQ4sOTDHY/WTGxxlMMVnpzqzUgwnbqxxVdZ+436rvUP9KAsS+OoKJiE1kd7afRr0wNL0LqspFN0dlo62x/J56SBZWGDh6zEIGHUjQDTqBu4RFI3isPFjSKOQMn/Ar4LxmsrvhsTDLxw8yYrAmWe8g3RCmlLtEbaE208bVdEOdKaaIs0x9x5ylKiPUbhREdUzjc8o/JMVKLySHRCZU509rSa77ugsgzEUyTKjOP78gtReN8plGcug68UdvbRCnE3xnUBPwBW39e9U/D4JHrQ6KPpFxlznPkNCmVuZHN0cmVhbQ1lbmRvYmoNMjUgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA5ODE+PnN0cmVhbQ0KSInEl71q3FAQhXuB3kFvkL3zJ/UOpAsEF6mNsUnhBOIkRd4+siEgLyFMoY/DLgiW5Qz3nk9nZqbHefo0T9/n6bJclq/ztNr+fHp97t+nl9//Pl9//zJPn+fp2zy9e//wePfr6eeH57vfy83tyx9ubz7Ok8WSsdj+eX6Yp/Pli5XfUHm/sPLGyrPWOmutA9be/5insfy4/0/ZYC0P1vIALO9cGoBCpyz79ieAQuNUySKSbCokmwrJWl4aywuwvFOWRaE0qVAsIivbIHb1Auel89U7OY2eqSRn2iRVB4BHpyzAzVGeBWQAhBzlNSiYBgVjUTAWBdOEhWkQcbaZuKabOIuIs2nhAApX6yspz779AVjbXF8VZVkUkkUhWRRSg0Kyb3+ylpdmJigWhdKgUJpUKM2ssLJpsatvgrnr/Kpv11rBmQo90yY509DgMQA+OmU14AyWnAGgc7XuKhKEjRADULhadxWXpkkR1yDiLCLOIuJsKjibCgFYfrXukvKaRhCaVAhNKqQmFVIzWySbFsmmRbJpUWxalMbyYi0v1vJiLV9Zyy/LzhQ3vp2v3slp9EyFqm+o+mDtHhq/B2B4bx1FLxNAobP6wImgQcQ0iBiASG99VZR1AJ3e+iopy7YZZ9PF2UYTGhRCNHCwKIQmRYJFJDWIpAaRZBFJDSLJIlLsLFIaFEozi5QGkdLMIiuLzq5u4JCMqsf56h0OJFU39CYHgEFn8QT46JTVgDM05AwWHYMTRIOIaRAxDSIGINJZPDWp42xXcgCdozyAyFFeg0JoUAh4QNGkSLCIhAaRZBtNsiikBoXUNJTUIFIsIsUiUqJ9RoNIsWPpyqKwqwc49J6v3mkb6JlKcqYNPdMAMOhsdAAfR3kWhAGQcLXukq+mxnJjLTfWcmMtN8Dy5vqqKKvpDs4i4pr+4GxaBDsnhGhQAFBorrWKsiwiqUmRZBtKsmmRbENJ1vLSWF6atCh4r9CkQmlmjpVtKLt6CYbb86u+XWtB9ZLc2CapOjR4DICPTlkWnAGQc5TXIGKiBNEgYgAinbIsOqZBxzXoONt9nE0R1/Qf1yASACJHeXgQ0aRFsGkRAArHVYy1PFnLU2N5span5u0vTYMoFpGC9xNNgyg2FVY2FXb1DZyvUPU4X73jt6TqJqk6ADw6ZQFuOmUBoI7yADlHeQ0ipkHE2GgxFgVjUTANCs42E9ekgrMouKafOIDI1fpKymtQCM3EERpEgkUkNY0jNegkmyKpQSQ1jaY06JQGnRLtORqkSoPUyjas/f8XcN5D1QNVL1R9+5f68keAAQBnaFdeDQplbmRzdHJlYW0NZW5kb2JqDTI2IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjgwMD4+c3RyZWFtDQpIiexX/28btxVn5NgGJNiOk9QJml8ubWrH7czw6x1vW7It3VZgwAZ0CdAfqv7QZDWGITVQ10Ox/34fHu8k3kmnO6midEoEW3ckj+R7fO993vuwzyIW/XjQTwTe77I3/tFgo3c2/u+D/jcH/auD/rM//3D5/X/f3Xx1/f3/oi9f2QmvvvzHQZ9jAYsE/q5/OOhfHvS/Puj/5JYvZXsRdnsVdvs47PYm6PYirGtFWNeKsK4VYV0rwrpWhnWtDOtaGda1MqxrZVjXqrCuVWFdq8K6VoV1rQrrWh3WtTqsa3VY1+qwrtVhXRuHdW0c1rVxWNfGYV0bh3VtshzXfvsdBv4FZhD9zX78D+hf9EvGv/9+0H/5GvL/qiPOo9eX9otdfWFfPIleQ8y3T8mt8+gp6dnHznl0QRljHO3bXnv3PCqae95wbzy8nw8LtIdvyPCmtKJo2i9X3ga2M1rlfxiQ4aW37Mbf/brcPyRH45k974OntNcckDvenGNy9/y76DUM95fXmf2/LkzGI9wwSiZTnBqZRobRNBWF7Xr5crtAledLhvk6MpwqkxbzH5CHZHhOeiTGT5FTcpvs4s+ZrKTJT8VWPBI0TawLE5pgw7c/5mFChZE2Unga0yQ1rv9u3OeCJvByFjJ+u5hXjs5/fvUyevvzQZ+aWCQRTRXOz6Of316Nlnj7KjCtUtAWql5QDiKAB8/0zGOZpwllJg9ou02qomwiusUC0QozRbBnCv2SqQZXal+IG8Bmr6rKjSUX2nGHBfvnq2uNZXJtBdVJHEBbJ6NRWcwzOs20u/DQW9KXZWbnzrgJFUKWB1Zieiu1/jQuLrzDZOeYYnun+Fh9Z6Zqf/mucRIa3ONSg4xMGek4lb15UC5GORUov7Ko3iNH+Nsj+7ZvXzv50CG5hxZmHCNBOuBX9uOSSrDefMP9+uzAGGV6Rn4QSEEi5iPcF/358kNmQJsgyknB22zOpGBXaqWdL21HMbn80Cyk1IemJ3oD0kKh7Zx5oTDDxMC6rd86MazP+tUKaSMfP8UcEAq+0JwUkAKOyRNQkE/JHRCcLEVcuuZjjNtfQgwogbT54g14gSQpicATVMYTpB1MyW/HXGFmyujVpgxl3WIrOVKGgSHzlFF8NopKwUfmn44GVkrKRleTdOK5So+8w5blJyuwPqryE+SKzARJpeBgpYrlRJ/lbbtrkIKTy2kBlOJEM4Eytr5thwFKUtV2BnnGCZSgHIViSnBOUl2VUAUHt6a6QlOuuQswv91QyqgRkDaN4woFHmzmKWdV4pLzrhUQsSp1WRoPziyZa4w2W1bo+wXCiWjUFfNEKmcjuSO3DBcensJ1QPXLs5vt91dgeStyYYb7wJFXR27BZG/wOrF320P74d6I1c4grHUol7Gmib1O5Ogt+guivExYR5vNjXDPXzKO0TTlAcbyrGtFmFgv32eF2Prg80TPxnYlXeUBFzwAK7mqEf7Fedrgf3U+sFKWkADWll+Xxmi/AC/9DTmz6Les9czy1huL/x4ZPrVvhdYp+R2+YjzKRuahrtVJKdVjCnELe+9kxHjP8WWI6FlSPciZ9fAa/UGWpCzj7pG79tMlHoPp+8NaSWKa+XPOUhJBYzYHS5EJ1Ua7nOW3F2Yp2EQyMU8O60iNbMtAMivFOaJRLVQAbXMZjcpiXiIaLhMdMa/zvadwCwqSm6HaX4Pp23OQh2AcFv2PgfBPmvlGHV7r+MaCeJ3ON+bHalfqWWtO0clomnKQNkjuivFbQ3l9Fl4amzhBGT+1VfwMpGIfzwv8fu9qe498Zkv3Y1RzFPc7RNgXnYdLTOA0128mxwCLeT6xQ81BRxtBfqoXZStPkMvswNU0vtJ4Bm7PPiG7B7kLHEPENAbLWOQceB/iIINfQbsqkySnaaqLSfcJx8YnjleeWjUu0H9BnmHsD3hy3E8f4mfDZhGSWhda0lDBRVuGKDijPBXtGaIQVPIkv+F67YUZIjZhUPv9ZYiZlUx+hxKUJ3GAS5ST0ags5imdzq4rXo20RhBgBqWBlZjeSm28v44PU1dynOIj9XMzVfvLd42T0OCeeVjkIMtmA4v8dlSyFth1VHJBYE+nkvODuitsZhEqmQdi+LAqI97KbD5IG8hXYFJYaWIggHMqSGlLN1tgf315d2l0c10cYjo9nUlD5yZdGYc8nsa98qRWmMmSmUk7CTB9Lid4jhfhQqY0jeNpTAjhVOxiskyHKRphjXxZjLwbj6iEpm4kXzQxMF4zO0uWp+tYopjGUUpj5qXKVtFTUzWE0pSPnXJmrX4Iv+xZd+wjaj6Hg3qw/iHauy4KnA965B5a9+GGzH9XeB2hMXAzsNr1H2PPW4i101EJqiP8M1ynhT3NTL9onhUQzy/5yNgv9qXjdOyGiQFvTSu/5NMLv0iuqJZ6ehUTVGs8NaOJLhUyuzrWOUWyHQmViiKavYtOfeLhtYkHyVL7UtzAtDypkUkFkxUVp9cyyRE2jOf5Hcc23Cxf50JKs87Wk0aL2UWrK4Z2keCrXFeRumJmSYXGxUvjncopVz+TUMXHyhT9lBo3wPzm/Be/0XaltNfIECskxW4Tp8nkACs6Ws9NUmqsWyEphaQZ162x+NnIs4ZUTuWUJp6Ov05hj6I4Cc2q4r7AhJ4NuYAmZvOY1wWIp3Ed4vy7rJs96oe3fC5xEXI4Ud4TTiVKUYkdPrC1OULtviAU5Tmv8ru1V0OeMppquXHAZ+sB/VwRuQV8NwC/JvMuBuqYUQE4l0D9Eaj5rqPdlohH4OnDc4xZZIOI382o+vCmFuQyMTRWm1fdKyA30qwD5FbsEkBeoSouZEJXngpJ2aaBTUkDJqZKV2r7p1ka2KuHuaPwuJzwRAcHeQzFlgHyrsTRe1qtNyGHtoZwZ3NoK5DzKsgBVF4p9Y/IH1HLT8DjXxCOwv8ntD7CyMfoPSAP8R2Vv0c+Q+MFPn5MaDO13yaEbULYrJvTe1HT28D9ueXw+6jqwzfN7H2L47A49pHhQi90afHP4SQuB+OVOrlKnFeq5RbrI6wPyC3yCZ7DS7yGV7Z1ZTs9EuM3IMfkCBT/TjkPLCZdgHCpSBhGVTKS38t3npgVw3ZxdZaVP3m3MCnl6ZQUJAynIuaj5FL0F0xBAmnOT0Hj7eZLQRUc2G200pMDrOgoJsPgoJBUjwNPfNfpRqFqm1QU0MRsHvO2TjMdrAIO5bKK8jSmTPJykjkjw2tySHbInmMWO+icgF0gwxyh0SO3kWfuI9vs1fINYRQ1jG8c2FkZ17GJVwL0ShRasUsAeWdvuh9KGlhTlq2BOhcxMFEhFI9IBFAPyF3cHw7Jbv0FwtXuNKUMbCA0nKvXh0Xh3JWI2dblbgCSrTobtoNqG+b/AmX5ObmwZfg5ynJz5d1CNSxUOxdLHwqIOw9VA4K8D6hasDYUVMkMTXW6Rem2oG7K9aM1Tjt7/WiP5GdEAc0ouadENlbcLZZXV3Hz8Fthyc0lLgfnFWgUNloF1isA+ZDq8ikqsq3MVfZcs4OgRqpIijhDV75HL19anSU5TWV1kt1/suRLRdMkfJoQiV5KmtikWH1PaUFXMnXrVNDBTO1ALqsg59zQhFUSxRNyTE5s2e+RIzR6yBrHZK+ZAGwYsjeBbbZGdGfZ5oeC+bWW/0lcZ2W7gutHJAKgB+Qu2SWHZLcW0HmhVoB1zLd8PhSf3xbhVRXh1WTD5TH1L2zxfQ7CfobfSyJtVzXX3y1gJ10R/V+AAQDoLxeXDQplbmRzdHJlYW0NZW5kb2JqDTI3IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjAxNj4+c3RyZWFtDQpIieyX32/TSBDHR1FDpFShFJ3KA+rVBzpSRLPd9a5/6YAHyo+Dh5MQle4B80A5qnuASpSeTvff3+zaju11bKfFTpxmFSVZ2+v1eHY+M98Z2j4jjnAsQil1rC+j4bvR8O1o+G00ZBbFD7PkDEG5RZhg1qevo6E8OYmu0vgEtdTfRM3BRQLi+0I/pNHQE7Zcy5ZH6j85+Hs0/HM0PBsND59/Pv34z5eLV+cf/7OO3klT3h39MRq+/4Br/IV32T63/pUPjKz+mjyh/iUYJdR2lNXxK8R/mfdIXKLszbx9sxbXO36iHpOxWBk7w/FLcu+zY1zrJbN86/g0sRoN5IQxz/IIsz3rGO99vw+3YBM/PbgHFjx6+ME6fjMavjjW35cT2/Et7gh8B67e75syQpoTO8x2WXT8JT2WtqkTNDtMZs145U/f8R19F837/ulsOjddzqXW+efR8HT2fmQw6FS0zI2pgbFVGDuXBefH9C6EF/AMOPwmB2N4oA7CExClzNq+ID5lhtq2qe1cWK0Lz52nNjy7THV1BXHjNzacmuraEfeuQ3V9KivpBD9P8CuLKiK7Bz4MVMHdw5MD2Igv1ddbw7Gpt9eS8M5zvAEHyC5S2keBHJ7UFVxPEId6BlRTcLW0Im9zfTd/YjGul49tANXI8gXnyWj95oryGEvuWPa7G1iHBzjsY10O9yXgPTiKLlj19dhgvrB6HEfmAgty/MRmUoBGTeKjRaQBjZ11qtp9JNvCyo08I9lP4HmGbhza+H2B35d4Scn0eCDy027nE0HJ423ic2HxgGFqCBIDevGthVkeEZ6vz5IPKGgJQSlx7GmSqSZcCzMmKPE8u3iCZg9aCbPp4qVhJme489FTMNtN4aDNwF5r7lW61a4kLd3xHO0ojSxaiCp6mYhawtZkArnrsjEx9UpR3xys9e6d1dbIgJHJbap3aCp20sqFYyVMYpmTjGilxLE9J5E41MquksqbKO9yPe9iKnXwpVziC5Ek1F3YknkbbmIFGMAhDPQ0zGyHOAHL3zXGu3YgfAg3ZBHYjsbbuMgAh3K57RpFqBOVCkLpZOEHU6mXHF9REGa8peamy11OEBbA5sUTGbBZW9HHa8sEWxW4panzw718966G2CtQ7zg4meXV3l1Ua1uwiaD2JfmlsAoJv8dWndaAiWXQKh/bAK2aUo32vm2hpGlUw3NneBYzeN6VLVg/qsYb8seKwMaa3MNLpXzHYgV9IFKxUo3WUqXWevVEiyG9LgxLOqLZMVPsiLrgfNP1LKjrQavdgLXR9biY7ObqepieLzlhzMu3Lz/BHubGMWbJA5k4Vb7Enz5wmS735bgHj+UfXlWXRG0/k+ehNYWU8cMPKaSuFGHTsxiNU8ZsTuKEp9ivbCKXm/H/PSTzUX3nYrhsl8vO6RVD7ELloEBDA8SNEjut/KvRQkzSZ1U5Ghdgka1RaDerXtXqlT6WCsN1Sn1cJrlZ1r9NWz1dtcpwmYMFv6zdK9IqZPKe2sL8EZ2OGo/r+oApgdLUPqNJu+Derle4+TXpIUrQMTyHATzA7wQ/A2wiw5PaZtGAacDsnnuvD5iv4HfsEcNzuCX7xvAM28Vf4TU8Vk3jBEh922gINW2jYXcZ7LJSOKe6llPC0BsGTlM+O+Te64Og1LX+5VWtwdJg2T33Xh8s30SaNlK0v1xe0xo+jaY15C6D3DulcHJiO77ebl4zLnAJFlmrRo2bGq1aE0bqpyqIMvSqBfNHyvzoVGIybc34shAR3NZDJNkEWqsc7AQQOWz2HeI1a3YgmjXnFkSTtcPFvsDMXcAaypkwu7DcXUB3s8C9+i7wtFg0zXO0fH3WjOZV1uHMRsi7AibyJxZTBORj5wkqXhlUkeG5SOL6IU2HzbxJnK8rt6Ys1zpZpUyzMnnqcnlgB4S7Igqf7JjOK5GppS2VKuRKfeESX4hEXxxCHzgM4AC/Y2wJwgvYwK7AgvBEtQlPYQfuVLQITAgUWYECizqOaRHakkKr1QjQYr5ZQgJalybhSNIqOZboDuABfvt4qhRa2xfEp4ZZw6xhdlnMvoFNCM/xZxPuQ3imiu1rLMD3EOFJRcEVtoMKgxl424Y3i0MUbznR2W5wxU9sBmxNQS8Sbk1HrxPg4cM8wyV32sTnwhKOR7gzvbcX36rPcjn6xdVnyQcUOxHXJdRz9E53NpwzI8QunqDZgxYjxK6N/LkCv2C2m/aHtMF8U2Xu3AHdwXyjO56jHaWRRQtRVRAUVRG1hK3JBPIq6Dhp6pWivjlY6937tiQVyeQ2lSrKTNtnBHOZsjIeK00RK5RkRCvViY1xGKsTamVXSZVJlHe5nncDB73gWS7xhUgS6i5soQ67DTexfRrAIQz0NMxsTPQounJ3/ayaLbiB3Vcfb99R3x3UdVu4yH2gtW1YnqfWlFzGVz+k5FahT7imLVpX3LsaKq3AvOPgZJaXaXex39pCWG8jvMh9fd+12rQGTCyDVvnYBmjVdGq0923LJE2hGp47w7OYwfMuhBeI8g1ZkjfkjxWBDdtYl8OLUr5jqeI5JEilSjVaSxVa69URLYb0ujAs6Ydmx0yxH+qC803Ps6Cex3OJzYM2eh4Xk91cPQ/T8yU2L0xreX6CPcyNY8ySBzJxqnyJP33gMl3uy3EPHss/vKouidp+Js9Dawop44cfUkhdKcId71ms/wUYAAJbE5MNCmVuZHN0cmVhbQ1lbmRvYmoNMjggMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAzMjg1Pj5zdHJlYW0NCkiJ7Ff5bxy3FaY3OgAJ8m3Lrix7fMQHGlEcknOwrR0kThrEKQq0MdAfsvkhciP0B9VAHBVF//t+PGaHnHOPWVtWFqvdGVLk4/G+73vvbf2ysxVHDJ84iiWjqcCTUcaT6M2/d7YO7P/cQ/foJx56bJYJNE5sQ0+kseS6bZ5F4187W//Y2Xq7s3X41c/HP/3n5PSbdz/9L3r5vV73+5d/3dn64UdY+Sdm8VxE/9UrUMZY4q9iO2AMs/62s+Xt+cAs4+3YbNb+N9iwonku7XYVzbz9DbZZu0Jlq1++hq0/x1EevT4udo0NChrHWZTRmGfRa8z94SkZvyXb+IzMr34+IBH5/bMfo9evdra+fl09uOQJTTI8s4SqJDNH/cXsR+/M3Z3MlW2flG29TdPB/NdiVMPp3/yK4+Ypdvrrm7eTsaW5lEXvft7ZOm52DX7iswgcb+lif3GB8wA4zBwktsDRHq403zukVoxd6vVWb1hioyqSeUJzoQqaTYNxXl61bizpqnnvVZufrouGgdju1UK72BwbZJvGeucd81zSNGm9Y9Zyv7F/v0PvemK1a+Nag6WYdd8eLlKxlG13YcKD49S6Z1wYttjkbXBc9wOmhZSr2Dd07FtFuPMY4abPSQ+Rgj4hX5FN8hjfA3w2yToZH7VmpVrKc7Yi5oqYZ/F6zw8xX6FCHL/TP8e6cByRT8m35E+mZDwgtL9oXPFzVTSumPshmDt+1srOSVqrEprxeMXOVfQ8S9d7fjio09p89qR2RcsVLc/e9Z4fWvpJ7cPZc9oVPVc57Yq4ZyynFZQnebXePGfEgInY7ta8Db5Va7UHR+anC0UefY3BsGW2b7uKLbOlbb4NIiqvIqTwAetNHHhBEP067BGczR4H2FFTesAOrjTf7wEanYAYigC38sIH9ULCkMlIOb8XRBkshqazNd8vmnZcZxz2HKFnqViGHe8nBuhlpwGV6ASV3XiAJFFtsvJ1mJM4ue50TbPUpojeXqbM/DR5cuW6wRUVqbTw8d/ZtCkyiyqmygy5M79IaQ4GuPzikKwTQTbJZ/g+QUkwPiVrqAoiMj4yZcILcpPsdpQIsZRIspQhVsrEqkRYVib0cRUCrK43H0CAfitFwkvNVs1jTd1N8hjfdXS1kpbnkuZsxdkVZ1ec/VCcfUW2yfid/jkmF0yo/Rbh9wEIfNARbiVPaJLFK+oum7o+GSzagpRzudByKw5D60r+/D6pXcmif0v0Hj8LOdwyk9NcyCjhnCqs4+aO3NTaqBzcl32jREo5y4tR39mMfhPJAXKEqEgURujRWf49Mn6K1zUiWqxJTqE5fWvKnKa4cjcqhllJnkPIdEYi8D4iG3g7wEpY7p7pyNGBrY3IX/Se1rCrEblO9vA7foaq5Jbe+TO0OL5aHz8xYza0iSM7cfxWq+dbLaAQ0pF5HpM/mv6WfSbIexLVd5pEwZ9x36hUoOjivaNQD6q0OqqmtMyqrEZIzEOIIE/LJE3yrGpEIwvccQtlgJ/SwE3ShCpedJyUHShNM9PhZlTbkwkt0SC2ewxG61tgeVqNBxbtogXtyD6ZmOB4l1yEY6/AtfDqeni2Qhdw1UludpxK1Rz0UhHEPDRjhVDlAp3/3hP04lrAs7b4TAGvUXV5vYP5jRlFjM2gurxfde0VdamuHxTtaL8tZHEcc1nF/tn8J/FDol2vUY9rOBOUV/X4hpGQTS0ORkNOgbor5BI+F3XjJtlozbliKajKe+CXISnz8afbgwHQGWtDIKuhr5bK16AY+8iLh3ZWYTX0VmHp79986UTP4EQ68ZvembsID7fJ7/DdI3fIPrnbWelmUPx238WcprA/8Z1rD+O70th8vnPzax3Mbwzsu8LqvEy7ZWLyEWim2dVOK6EyKrK0wzVpTjOdgxWuce1hXFMam881qaIs9V0Dg4qnzjXF1od1jVuzoy5wm+gtb6rhyap3m5qL2RPsKWOTsz2HTjQk4TUoAoj3ofuHwOJIZ55A5Yh8ofUebyYhfo5YcIDOPeSkj4sU1eWXh/heIZeRZG7jOSKfoyeG9kxS+8rSMfKpcu19jNVp7Auy104Bk9akDDmiiEsCMC+n8aoym2QZNJVvbBrEs8i30JHFmP9PmQGYsWGLTd6GBb41OYMgpTSXXoJpK59TkwLchyg9WCwRaHdYLa4u6LKJidJniwTR4FoeInQ+Akxv4PspwP+kqE3q1JJQWbg5mD4i16o0SATNcxUOuw77N03A3jUhe686KWYM1ZYIZ93pjRoVH1QFkHWq39lBcXO24h+uUTHihGYrxViaYhTFwgYK001EBV8/NhENdLl61ahGRC71y0Wrt86KXLTE0uBOdPT7jnB8Y9yPFwU7OBoe/Jxx1DtcI0d5QsWKo0vnqC42jsFJHb+vTRO8W/1y3tkYHvycsdE7XCMbhaRqxcalsfEh2LduE+oF8upWJ31M1HRFZ6TzhlOUlSOtT49wF4/6KRpewPmgqCOglDSZhoBc0jzN7Qb999lI6GZ20NCNmJKIbnS1zbz3Ye+1MDovIcdPgbgNxMXFGNnqtRojB/CbZ2YYXgoq03hSsFYrTzsGAM7yYsxNhFVmAmpM9rqC6iTuNF9QzGkK2/aCXGPRCwrNlBc0PSZuAwdX+0Wo+UjQoCyX7kiuseiRQjONZJ1Z+84UU6eJF9fJEwSLTfIY3wNdao7A0AKsPeif2AV7kkSEhrd14LmAz2WEZ/17GR3NJIgFZXWm1HxXXdVNVpT7FHpCPlvkKAKslapidRuadQHqhRNdtvm+/mk+DFJBqZLqYRoAbwNTqqhQqj8wgX9SSIsb/322wORmdgQmN2LKwORGV9vMex8W7oXReQPTXYjQ+N00safVMbXYM4BrPDNLyAn3yT3D8XX9nYWCHTIdXs/cenlGANRIzTymuRBTUDOhvIg9/vuM1LQzu6hpR0xLTTu62mbe+8A364zOS81HpoiDbF+Bim+TqyZt3Ec6dLefrK2uqpN1cWd5ZpZTwKFYwwU8tLEG7SLs3Ee//o7INeSIt5AhEo6HThdHOuU2IU/oh8TjzixMrw5KaD5VECvkIHTA/HJwNkDbKAc4asymKCGXH6nLIQnuXm/oYOK/jrvFLBWLsCPLeLD5gW/XLVm53qakozhJm7LZXftxQs+otpn3XhzAPOc+jV3BDx/G9rwitw+27vbrWSvW3lvyUYGbGzMr3vS0Wkew/+EBZ6yG/hlOnI0e23rmInT6vlHqiUprYcZD6abCMIWByg1VGKwwXNkCYiZ1riOF55JmiWpDClyVwpq9addYFCmhmWaklGNmQoqbVusI9j8wUgqr8zL5lvH5EbKUS/joXAVt/fjEdV0EGDZsPtNebkwCaLMfET+zvEiHXWNRP4Zmmv04RxqfBQ4M5XgpaXxW917DEaaBYjW2uKm1DuY3lhNeCuPd+mXUS8hER8rh08uM5GQNCeSmBu86XhSqR4nPmmmhU5E/kPGpB2q7UEaTVEHCciq51BKbFfBaRIA7JbGYGfNwKouyGNuIG+cBJhzpqowyHlMWS33zSZrg5ic9J2WPQGJke9ykWkc5p5t+4fAkxcHyNFI0ZR4NWxSomJvRHMmoO9QeBGZNOyQyEjQ+hYMu2oeRo2081kxZdcX9O7yFMMPVB5OZV0UZkKLBE3hCZrZ9UrYVzW0H81+LUX1SZMaVpoJLqGWIhibtlNVmRK7qHcxvLIWyE+M9Oa69oa4U19NTO9hrZtLl6eaihtVSu9g8KVNLnEQo41mB0Uf4PAEOb+D3Lj77eI+BRoNT/LXHRp6kOGzSjstJDHeIK9oD4LI01YZLVsPkR5jRBJ6qZDTtOUuqKOe8wy8qpUqo0i+uPYRfJqbm8wvSLL31oIPlRU1S7HtYv7g1O3IVtwlv480ZV0X1rCw0q0TmSdygeudMN4GsJYAHILsOGYggAY/xPdBouzQJzT2SU1rNqeAqNAvk3kf5dQjwjsj4qTY8Il8YiTmyOctzs+AIkfAy4uI2niPyOSbEZJeMn6Gxj9dDkOAF2WuHvg2UqDJFkhTAL/XKxrIZqx89LREdocuE3kEh6ZbsC1neQdpiVjV1tjPa6gD9vpy82dkOD9QSTkLvFaVWk0AvWmqFZppLrXLMLKD5WAJMUHvcBjuv9oeVZv84bQ6EelH/hGaa/TMJEF3CzALIZ4FjQgrohQZ2i12wP7xMA7Eqn93Utng5iVtLoHRhfIZIE6CtFmlGc8QaYDGBUgaGt8n4mFxAAMHDxhJ8nN1ZateKl6Re/f8yB2YCA0tzWOInGHYGliAASRGGBkA7zZA6s1ABjDY9PC+gNOYNFcxQw9TU1ARY95gA0w+wsjCG17Rp6F41NTXXA9aKqMqYGJTg/kWoNAMmQQt0E5UxgkUBIMAAfB3kQw0KZW5kc3RyZWFtDWVuZG9iag0yOSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDYzMS9OIDE+PnN0cmVhbQ0KeF6VU0trE1EUPhMrbkIV0VC6ussiSRgfC+suJmmatMSYpmhE0HFy00wzL+/MRBO66saNaFfiwo3gD+jSRRcuCt0oCqX6C1zUB4hCl+I3D5OxVdQL955vzvnOOd89lyEaW1dsW08wIsN0Ramea15tXmNH3lCCxilJWIrq2Llabd7HpmVyOrD23pLk2+2MX4v+bx1ucUeFfYFt3XFtl0iSgU90G/U8cAF4XLWF728Az7Yc1QB+QnToeJTrr5MlbnKhqawklD6rCaut6XGtf4v/0/JnE6Jvl4M7S6mXqid6UViSXhG5/K7rf+Qtuy+0pY7LTk9Pn2cZdkaWz7IcJsRZ3jJsz+WClU01m2aKrrOA6jDBHS56vJUlQ/d+3u0odpKbiwuwU0SJD9wpRliyW0phDvgc/KkWLxSBL8C/2dZmysBZ7M22mFmEPQU/09xyI/QnNky9Oh/6ExXTql4CToPz2HYv1oHxDon7Tm+hGNX5uqxUarApcCpda87nTIDjDjqNK8DH4L856OSroV/6Tk3SiZNGJk6TGM2SQoIMnAplyAa2qI24Bp5GpYDF4dXIoS74JeD3AVaCSqMMnWox7DN3kbsb5N4mD9wwG5WqtJqW1+VP8jP5nfxZ3pGfAn1cm/SmbPvRg1VxQ1NfP/yCen7nUb1QBYtUhZVVdPyTShcxc5/GHLZOS/Aawzk4UYYClQ6yPHD9ipn4jdrm2uSQ1yfmK+T3qnux7nyoc9T7VlC/G2jrBQwHZy6mIXyH8HbLiI7Ugr21sjER77oz9vz6dnJrZd9sWsF088F9BmAenFH8baxhvyVsa8jmv52oGu//Sx38rT8An7HwUQ0KZW5kc3RyZWFtDWVuZG9iag0zMCAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDI0NzIvTiAzPj5zdHJlYW0NCnic7ZlnUFRZFoDve50TDd1Nk6HJSaKEBiTnJDmKCnQ3mRaaDCqKDI7ACCIiSRFEFHDA0SHIKCqiGBAFBVTUaWQQUMbBUURFZWn8Mbs1P7a2amv/bJ8f73117ql3zn11q95X9QCQISawElNgfQASuak8X2c7RnBIKAPzAGABCRABBaAjWClJnn5O/mA1BLXgb/F+DECC+30dwXruOVJM0Qcdw2MzLo/fTjRv/nv9vwSRnchlAwDRVjmOzUlhrfKuVY5hJ7IF+VkBZ6QmpQIAe68yjbc64CqzBRz5jTMFHP2Ni9dq/H3tV/kYAFhi9BrjTws4co0p3QJmxfASAZDuX61XYSXxVp8vLeil+G2GtRAV7IcRzeFyeBGpHDbj32zlP49/6oVKWX35//UG/+M+grPzjd5arp0JiF75V25bOQDM1wAgSv/KqRwBgLwHgM7ev3KRJwDoKgVA8hkrjZf+LYdcmx3gARnQgBSQB8pAA+gAQ2AKLIANcARuwAv4gxCwBbBADEgEPJABtoPdoAAUgVJwCFSDOtAImkEbOAu6wAVwBVwHt8E9MAomAB9Mg1dgAbwHyxAEYSASRIWkIAVIFdKGDCEmZAU5Qh6QLxQChUPREBdKg7ZDe6AiqAyqhuqhZugn6Dx0BboJDUOPoEloDvoT+gQjYCJMg+VgNVgPZsK2sDvsD2+Go+FkOBvOh/fDlXADfBruhK/At+FRmA+/ghcRAEFA0BGKCB0EE2GP8EKEIqIQPMRORCGiAtGAaEP0IAYQ9xF8xDziIxKNpCIZSB2kBdIFGYBkIZORO5HFyGrkKWQnsh95HzmJXEB+RZFQsihtlDnKFRWMikZloApQFagmVAfqGmoUNY16j0aj6Wh1tCnaBR2CjkPnoIvRR9Dt6MvoYfQUehGDwUhhtDGWGC9MBCYVU4CpwpzGXMKMYKYxH7AErALWEOuEDcVysXnYCmwLthc7gp3BLuNEcao4c5wXjo3LwpXgGnE9uLu4adwyXgyvjrfE++Pj8Lvxlfg2/DX8E/xbAoGgRDAj+BBiCbsIlYQzhBuEScJHIoWoRbQnhhHTiPuJJ4mXiY+Ib0kkkhrJhhRKSiXtJzWTrpKekT6IUEV0RVxF2CK5IjUinSIjIq/JOLIq2Za8hZxNriCfI98lz4viRNVE7UUjRHeK1oieFx0XXRSjihmIeYklihWLtYjdFJulYChqFEcKm5JPOU65SpmiIqjKVHsqi7qH2ki9Rp2moWnqNFdaHK2I9iNtiLYgThE3Eg8UzxSvEb8ozqcj6Gp0V3oCvYR+lj5G/yQhJ2ErwZHYJ9EmMSKxJCkjaSPJkSyUbJcclfwkxZBylIqXOiDVJfVUGimtJe0jnSF9VPqa9LwMTcZChiVTKHNW5rEsLKsl6yubI3tcdlB2UU5ezlkuSa5K7qrcvDxd3kY+Tr5cvld+ToGqYKUQq1CucEnhJUOcYctIYFQy+hkLirKKLoppivWKQ4rLSupKAUp5Su1KT5XxykzlKOVy5T7lBRUFFU+V7SqtKo9VcapM1RjVw6oDqktq6mpBanvVutRm1SXVXdWz1VvVn2iQNKw1kjUaNB5oojWZmvGaRzTvacFaxloxWjVad7VhbRPtWO0j2sPrUOvM1nHXNawb1yHq2Oqk67TqTOrSdT1083S7dF/rqeiF6h3QG9D7qm+sn6DfqD9hQDFwM8gz6DH401DLkGVYY/hgPWm90/rc9d3r3xhpG3GMjho9NKYaexrvNe4z/mJiasIzaTOZM1UxDTetNR1n0pjezGLmDTOUmZ1ZrtkFs4/mJuap5mfN/7DQsYi3aLGY3aC+gbOhccOUpZJlhGW9Jd+KYRVudcyKb61oHWHdYP3cRtmGbdNkM2OraRtne9r2tZ2+Hc+uw27J3tx+h/1lB4SDs0Ohw5AjxTHAsdrxmZOSU7RTq9OCs7FzjvNlF5SLu8sBl3FXOVeWa7Prgpup2w63fneiu597tftzDy0PnkePJ+zp5nnQ88lG1Y3cjV1ewMvV66DXU29172TvX3zQPt4+NT4vfA18t/sO+FH9tvq1+L33t/Mv8Z8I0AhIC+gLJAeGBTYHLgU5BJUF8YP1gncE3w6RDokN6Q7FhAaGNoUubnLcdGjTdJhxWEHY2Gb1zZmbb26R3pKw5eJW8taIrefCUeFB4S3hnyO8IhoiFiNdI2sjF1j2rMOsV2wbdjl7jmPJKePMRFlGlUXNRltGH4yei7GOqYiZj7WPrY59E+cSVxe3FO8VfzJ+JSEooT0RmxieeJ5L4cZz+7fJb8vcNpyknVSQxE82Tz6UvMBz5zWlQCmbU7pTaasf6cE0jbTv0ibTrdJr0j9kBGacyxTL5GYOZmll7cuayXbKPpGDzGHl9G1X3L57++QO2x31O6GdkTv7cpVz83OndznvOrUbvzt+9508/byyvHd7gvb05Mvl78qf+s75u9YCkQJewfhei7113yO/j/1+aN/6fVX7vhayC28V6RdVFH0uZhXf+sHgh8ofVvZH7R8qMSk5Woou5ZaOHbA+cKpMrCy7bOqg58HOckZ5Yfm7Q1sP3awwqqg7jD+cdphf6VHZXaVSVVr1uTqmerTGrqa9VrZ2X+3SEfaRkaM2R9vq5OqK6j4diz32sN65vrNBraHiOPp4+vEXjYGNAyeYJ5qbpJuKmr6c5J7kn/I91d9s2tzcIttS0gq3prXOnQ47fe9Hhx+723Ta6tvp7UVnwJm0My9/Cv9p7Kz72b5zzHNtP6v+XNtB7SjshDqzOhe6Yrr43SHdw+fdzvf1WPR0/KL7y8kLihdqLopfLOnF9+b3rlzKvrR4Oeny/JXoK1N9W/smrgZffdDv0z90zf3ajetO168O2A5cumF548JN85vnbzFvdd02ud05aDzYccf4TseQyVDnXdO73ffM7vUMbxjuHbEeuXLf4f71B64Pbo9uHB0eCxh7OB42zn/Ifjj7KOHRm8fpj5cndj1BPSl8Kvq04pnss4ZfNX9t55vwL046TA4+93s+McWaevVbym+fp/NfkF5UzCjMNM8azl6Yc5q793LTy+lXSa+W5wt+F/u99rXG65//sPljcCF4YfoN783Kn8Vvpd6efGf0rm/Re/HZ+8T3y0uFH6Q+nPrI/DjwKejTzHLGZ8znyi+aX3q+un99spK4siJ0AaELCF1A6AJCFxC6gNAFhC4gdAGhCwhdQOgCQhcQuoDQBf6PXWDtP85qIASX4+MA+OcA4HEHgKpqANSiACCHpXIyUwWr3G0M1rakLF5sdEzqOkZaCocRxeNwErIEa/8ANSYTGw0KZW5kc3RyZWFtDWVuZG9iag0zMSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDExPj5zdHJlYW0NCnhe+w8D/wA20gn2DQplbmRzdHJlYW0NZW5kb2JqDTMyIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjgzODQvTGVuZ3RoMSA0NjcxNj4+c3RyZWFtDQp4Xuy8eXxU1dk4fs6569zZ7uxrJjOZZBIyQEIWIBDJIJuIQNhCgqQE2XcCSkFRQGUxoqKta91wxQWdLEBYWqkv1WpLsXVptVVsi4rWKG9LaRUy83vOuXMnE9v3930/n+8f3/ePd5Z7n3vuufdsz36ecxBGCJnRVsSh+qkzyiqcVzbfCil/gH/LglXz1z77emcQIVyLkGH6gg3Xhve/cvpOhJQ9CImrF69dsmr40+44QjbIbkwuWblpceSGc88jFEwitEtaumj+wviGCccQeqobMgxdCgnSS6kauD4H14VLV127cdzXoSsRetpJy1i5ZsF85HryHYSeqYfrxKr5G9eK7e71CD0L5aHw6vmrFv3z3Pu9cA3vJ5vXrll/LdQbPs8PpPfXrlu0dm/H2S/g+iqETGWI43bhPUhAsvCQUAlvDGhn7tdoMbHLAjGKPKEf/mM0OH0cbbwa3mKg75s5eUwYJVA4fUl4OzUNV0qjcEcC4XQ6jRAfE47S0pALjlzmH2T9iLjBcAWQmEA8Z4eEh6BnReSH3MWoBA1AcTQQDUKDURkqR0NQBapEVagaDUXD0HBUg0agkagWXYZGQdmj0eVoDBqLxqHxaAKaiK5EV6HJaAqaiurRNDQdzUAz0SzUiOagq1Ezmofmo2vQArQQLUKL0RK0FC1Dy9FKtAqtRmvQWtSK1qH16Fp0HdqANqJNaDM6gD5Gn9P2/I+u2//Uz0P/Y78ERqIIRtEOVF0B41aAjMiEFBQFvFSRBUg1ggqRFcbuSnQFjN4wGO/RMKpOFEB5MKoeGMs4ciMv4Hcd8gEmDECTAIMTgBUOwPMpiAc8iQHGyIATtYAVEuD8IMAiAfBoOGCEAfCmEjBFBAy5HJUCfgxF+dBn/0sRjf9LEf8Pvv9LEXP+lyL+H3we+h/7/Z9LEUg4gnzw9wvPIh8fgxJQ+jP4n6Xn1LL0WXqfngloeag780doH9qPl6H96BX0Kj4HT72MDqMu9HOo6Vj0MGDLD9FOKGsOpNwGuDcd6jEW/RD70l3Qsr1Qt73oJOSdjW5CR5Abe9Ofoy1oO/c2PLUd+qgAWl8PeHgHvip9HZqLTvO3QJ9cBbi5Fm9NN6bvTN+Tfgo9jQ5zP0/3Ql/6AZMXoJPpr4Tfpf8A7Z6L7kUPotP4HsMB6KPZQO+HuUcAox/imnmcXpL+FmoQQd+HOvAwMifxcRKHty9Cn2Ev3syNgbc8mU6mT0CuINDKUhjBI7gaTyARYW56cvokjMQgoIqtUEYHOgjfbvRj9AE2CefST6XPwfgMhP7dAv3xK3ycS/VuS9XRjoZeGgBjPxHa9RP0OnoLR/FPyRrBJFQICeH69Dsw2kOAQmejZ+HJT/E/yE3w3cK9xo9PXw44sh3dTXsb/Qz9EftxGZ6KG8gAsoY8yq2DUR8Izw4Bal4G/f0AvP0jHMcHiYmc4p7kX+Avinmpj9MWGJEY+hF6BP0Um6GlYbwe34zfw38mY8g88iPyJ+6H/HP8b6T50OrvASe4A72A/oHteDiehq/GS/FmvBPfjR/EJ/Fb+CwZTWaSFeRrbinXyv2Yvxy+M/j1/C3CDuF28WyqMXUi9evUP9IV6R3AfTajbVD7e9Gj0LLD6BR6H76n0Z+wgI3YAt8wjuBZ+Ab43oTvwE/gffg53AWlvIX/hD/Hf8V/xxcJEBERSYBESAF8o2Qd+T75IXmYnILvW+RL8g3n4Qq4OFfN1XJN3Bqo1U5uD3wPcH/k/fwpPg39XCHcJzwm7BNeEF4Vzokm6WYZyb+89GRvae9HKZTalbov1ZHqSv8RqMwHOBUECqmF2s+H73IY7/sA415Gb2MT9J0fl+JR+CromXl4OW7FG6Enb8UP4adZ3V/Cx6CXfou/hjqbSZDVeTCpJpeTqfD9HllEWskecg/pIu+RbzmJM3JWzsWVchO4Zm4Rdy23ibuPS3K/5D7k/sRd4C7BN80rfD5fwMf4OD+Bn8dfxz/Kf8Z/JswVfiF8IiriKnGH2C3+pzRUGiXVS9OkZuku6aD0jtwC2PkfwLsP5TJK/DG3jRvHHUB3kkreR35FfgX4PA8t5CYTwFSyD+8iN+IuUihsFEeSkXgKOsfHoK9fI4+RC2QkNxlPwjPQcjJEe5vo5MECRbX8f6Ae/hi07Vfw5o2iCd9EvhZNqAMjAhYo/hlXzse5X6APuNNY4vei3/MK9uAe8ixXD1jwY36U0Igi3MPoJa4V34gOkHFg9V6UdwMeT8HPA1+YiSvwP7k04sgUwKJh3J/RLWgF+R3qATrehe7HC/kl6E5UiTejz9AzQBUDhNViqejCb5BlfBtx4C5E+OegdTW4EHOCE92Km7mHxK/J+yDjTvEK+oh7EWp/irzETebPCdPxUqCAG9EO1JrehjYJjfxv8BLE4QZUBMbrD9FmroKPwHkLcJW5wNMOAnUfAT4wmpsMKV7AnKsAL2YBh6D8/wHgEzxg0DKg8dnAxX6FusSZpBstESwYuA4oJr9ITUdz0s+gB9NL0Or0PWgQ8IOd6c3wxn3oE3QX2oe3p24AuRwCyvkIXyWMJ6eE8elBpI28T2aQ+/qPL/R2EfaiL+D7ElyMAvu5jf8taAB16d3pdwG7S4DDPgjy/0p0Blr5FZRwBXccVaamkPb0eG4ttPc0mpZ+Np2PFbQ0vRJ0iGPoaUlA86U4jHES/wbaewNaRKanr+UWpZZBP9wFvZCA3roO+M9tfCt/C/8N2g00fx/wm8eBbp4HyqG0jxJXb792/brWtWtWr1q5YvmypUsWL7qmuXF2w6yZU6eMTtSNuqx25Iia4cOqqyorhpSXDR40MF46oKQ4VlQYLYiE80N5wYDf5/W4XU6H3aZaLWaTUTHIkijwHMFo4Ljo+JZwMtaS5GPRK64YRK+j8yFhfk5CSzIMSeP750mGW1i2cP+cCci5+Ds5E1rORDYnVsO1qHbQwPC4aDh5cmw03I3nTGsE+I6x0aZwsofBkxm8h8FmgCMReCA8zrt0bDiJW8LjkuM3LG0b1zIWXtduVMZExyxSBg1E7YoRQCNASU90bTv2jMIMIJ5xI9oJks1QqaQ/OnZc0hcdS2uQ5IrGzV+YrJ/WOG5sIBJpGjQwiccsiF6TRNHLk9Y4y4LGsGKS4pikxIoJL6OtQbeH2wceb9vdraJrWuKmhdGF8+c2Jrn5TbQMWxzKHZv0XH/G23cJL7ePadyZezfAtY3zLgvTy7a2neHk49Mac+9G6LGpCd4Bz5Ki8S1t46Ho3dCJk2aEoTSyvakxibdDkWHaEtoqrX2LouNoSsvycNIQvTy6tG15CwyNvy2Jpm+KdPj9icPpj5F/XLhtZmM0kqwLRJvmjw22O1Hb9E2dvkTY1//OoIHtqk3r2HaLNQOYzLnAouw9BrHsFJo0PduzmNYoOhEQIhleEIaaNEahTcPpYdFw1LZgOGSDTxOGp5ILYUSWJQ1jWtrUETSdPp8UitRouO3vCDAg2vNl/5T5mRSxSP07oiDFkyyqwX0dTsbjydJSiiLSGBhTqOModl09aOCGbhKNrlXDcILuQ/XQt/ObRpRB90cidIBv706ga+AiuXVao3YdRtcEOlCiLN6UJC30znH9jmsWvbNVv5N9vCUKmNzF3HGupBzL/qyq2zFu6Ygkdv//3F6k3Z80Izpp2pzG8Li2lkzfTprZ70q7Pzx7LwMlHWMauQDJQCTAsbuAlHOzmelFoynJF8FPZEi9sFuSAStZCg6PT6otV2jHJiUS+W8+1J0+R59ip77HMtVMjoj3vx7Z77pf9UxtHFQYxOukmXPa2pR+9wDVtAInZk6A8WhmYyQ8JolmAWUWwa87fXw4/TcFkgnosjE0A+CflpS57JcxkIGb4EOxc9DA8cDo2trGR8Pj21ra5nent14TDavRtsPkVfJq29pxLTridKeP3B5Ijt/dBH21FI8YNDBK77S1LWxHXBEUkwi0YwYMG3N7U3JqvCmavCYejUQbF0Fb2kcgU2RmyxiACLq8PYp3TWtP4F0z5jQeVsHa3TWzsYNgMqbl8qb2QrjXeDgMooKlEppKE+lFmF6gSRi6poPILH/gcAKhrewuzxLY9YJujFiarKdhtKCbaGmqVlCMFZQAxXJBN6/dSei5eUiTtbStWu6STG4Z7qj0zhEEEgexm9qnHS5mNiaUYYkRiZGJUaSOQI/QpA5IOQJ5R2LUOQrX4UA7vHM6S+7GW9tHJgKH2ZumZ3JuhZw0bWs2DWpOs+W8CMrTGj6rrwWz5jR2jkLwfnaEHJfTD+W0UIlcGmKMieL57HijibRNmgEYSG8qwwNKzu0wfTCJo8l50Y0R2rpkQ3RTBBKjyTBwa8jUjiYEm9rawvCNQq8saGjUjvQWHhiENzUlt16j5w0EASf6Lk3wKMOrziDlIdnSbtBLWwelUaBNLy654N+WBrVP4qvpkf1Y9duHoqhWPkhprdC2uW1zAB8jyTxacKYecGkJNrE3QE0eYDXBTDgtAJ1gMaWlMGVywCajV7aTKXF2xuzcdmV03ELIQf8gdKthsCLhhU00V5QSDUX8/zITzslEBQl7eZs6Ur/CmSuNfNuSS/pfLs1ejqd/0FGKBmtsAtrCSDaSXB5IrmyKZ7PMp21uA9oeQQl8BHt4Av23gNiZkNy6YD5UEeTNxAVRSLgSEsKN12g9SAV1G9WcFsyHx2gvZ0pKro73eyXwBAwsCl5Em5PcWh9uaQq3AA/B06CzA+GkAOfwYlCfovMp36jX2lMPzB9O89tmwLOIDlsgKQE/Wzx/UZQy1yTFd633aR15qB2a0ZhEgba2KOAQVLFoPGSG18eSYmwiPcFvbTw6fxHV7BZTxW6RpnJAdVnv0LcFxkUjTZCFFLG+hI4DQruGHha0Ub2xuSUOPWFrs7eFa9qA4JtVOh21oKEF+FpYDY8Ps6GeH4Ar6ISJ9KoJXqRlNBTRjPA8+8WSq+LtzVJRXwr7rYlrmWX2VqZEJOv1LBL7AdAaTxLPcLhJG4+nz2FyAQaKdp5QNBG6NwFYFaBPAxXNzIgN7fmJ9NGAPmDaY5DSpAsAwPf2IryrPpcTzk3aJ02/OgAdOwjS/NBoVTiCFAS2bHJ7vPEYMqW/RSZkwomuBrNoMnVTQDBlAFEHDDqg6IBgMRq1PDpg0AFFByQ5k1nWAUnO3JLlbB6zOZOSAQQdEHXAoAOKBiSGNdgbTUtND5meM71hEq7irjL/kOfsmMjIJHKSoBg5CZlMZvObHO/kOJ4zI2Iy8xJ3lBwFrk/w4wkF8TxkQW8qfDdZfEgQlERefpXSnf64S1XJLAA+7TKbGfAVACIAeFjCLCUKolXS1ki1tMdKQPgmjGZnFQIxFCYcoQ/TZwA4c5A+Qw5YuvHu9tu9cfXLeLw5rl6Ix8/H4VOrfqr21qK6OvV87YVaW00NttlranYOjvM3qiesVuuQcgxqy2FkTn/UYa8xd6ffSRgra7iCQTUcn5dXS1/R1IyaIU/CaUoYa0xb62tMiViNqSAI50E1cZYDx//1g+KBgybeIHJm0s1VHFppNkM38ALy1tXZa8rilZUV9pryIU0RW6QaV9oqXVEbZ8Pkvt5bySM/eO21rlQ1nvc0d/DSlU+n9oKQvrd3BSLpJ1LT8AjAKg7Z8Q6KVZ1ExwBOB0w6YNYBi45JRAc4HTDpgDmbR8cATgdMOmDO4ERRAy8UCSP5SmGHIHhkQZB4nvCCA2GzkXBOE28TjIAB6ePIjMyQP9rA3YSRUZSCNuseJ3Z6PH5AmSJF2WPE+cY641QjZ+xOf5sYZrGQWUaVDqxRNZngaDIa4RgyGkWAVRWOgN4UpmNu9Dmc+yMT6r3x+JTzeq83t9ZOhgGfoo5bNPbTVlQ3uaeuricOY27XRp79Kyt3qnLtkPIxmxIWWbXGZFUJYINFCiAUh6Hchpv7jWSg3SZ1c+UJw0qb1SiiBCgT3jr/ybq6OIyfo7rShYe5KyuGVtsqbU5JjBbs6EotLRiaP2xoV+Xo+yfyn//619/c8KBl4j383IuPn5i8ELjDlemzfJAfhUrQMK6AjmNioMFsKPWZ/aUDzKWlNeahrmGBEaUTS5vNzaXLzctKW8rbzDsGPOT+kf85s6ukO322i/ZJMQAJH4We8T1fctB3tOSE71TJb1wflshj3TjUnT6fsNH+stvpkfIacVY10E5iKoXyPfne+MDSqhq+ZuBE/oqBDXJTfLG8LL7BtBNo/RvzN3HbsCoL5tWywipPRcTpnTdgzQAyIFhmqbPcZXnMkrYIj1letnxt4SxHgbUZkREnDgGyWa1klqU7/QUjbwuthJMOnYUNmkW0WuEYy6CUxcvQ7kCDxRLkPN3k+U7vQIa1CUuDd6CiXD7Le68zGJRQti1oXLFSEeSMA+ar89FoNX1BKxg1IJT+p8ZfGXwpg3zGBiRSjEJFkcLu9JesUhQAfgKphTzFM7g+00VRDYDzrGcB+EPCSKtdyCoM15e6aPGF3eTqhKU4gWJqLBwrj70cE2qAO3VR1I11p9/TgKPp81rxnQ2xIfR+whyKVpXXHK8hj9fgGg8Uc4i+3KNx64ShwVPkLSjTCa1MJ8YyjYQTtoaywlfEUyLJF+tEIjp1geDM8m/tPYNBRtDuF020caKXNk5kRESP4izRQsdAVGlLxCHDKZfsI5weOJ6Hg9rcGqc3mnuyVFXbS4+ffILqeurOxOt64PKMjXKxvodb4ZoSF1CZp2ZIOWIkhFvhhFoDhxAXj5tMlgHd3KBDK2GsixWugsGc0evxBJ3dXFnHShhmb128oqyyLl5ng5cDodoYjywSgapi1VVDhw5j3+qq4li0QJSKR5HKCrfb43a5nG5PNMaJkoUACMQImbjahYeXv3xswvorqld8sARXjtu1ZVNe0rv6rdt2PV+vGjwFx4Kea06smVuxatnSJ2J5t8wa/8L2KdumOC1mf2GRsnrQZU2t3tbbJyXmXzl447mL2y8bjj8sCaolk8uuaLl66mXfB+NoJ0Lcp0DGbvwpI2KHwIkOsk/tVv/MfeY4x11wiDyYu4kCo7lqk4ofUN/yfuxNe/mw7LQ43fagIGHRbVbMFpMFMPmfGsoA9lrSf81itQVQiWF1IthgKfQmKP56E4wvllDY6GRck2K0jXFOhtHGApaDUo2RcU9GgnD9DcV7gBSK1XB9IcF4gzFRObQqbcTwM07xUoT1Vw2tSnrPecla7+PepPe4l/dypNLl1nHUrUsXt46s7iIMZHqhy2YDagN+zkiNAgkPrSJiFUMKrRjiaaXYPRutCCgNlLR5WjVES7dDdc5RB0gYvYU+Bstyike9AHiZ/TCMrD1fy5A19wZ8KCLXqiD0a4H322qwvYaxerdoMyiyIimcqMZsoiWArYo9gBnLLwWe34oAjwMJg1lxK1jkBDvw/I6VgoaUdXV1gIhUTg/NoJwtaquKUTR02XY+cd2HLXvrVaWrdMUV65/lY/e/PG7t5Iobe9eTHatXjb7nl73HoC2gEnJn+RhSyAJNIZT1YQapC7052pxhXV9kEUHWYcjhNpuzOc5nGZ2cPqcrlQTI+jBNbCfMpvYIMlJkEYsKEgyygIlQSHmDUBb/8KT64UmQgqAW1dHOCRyqFjAqsNWADvZRwmyrMQByVsn0ABrWF51wxpkz5PhdwhCKVKESOChUABkKiqqQGw5w9UHippLBVSgMB6tpACoxxJQaVK1cgSYoDbiBNMmNhsV4MVkmLzNsRN/H3yeb5I2G7ys78U6yg7tN2iW3GR5BDxjuVl5ETyg/RoekduUN9DPlA/Su8iX6s3IRnVcGQnMUL3IrJSimDFOmooRiEBJ2d5UAqF3VLrK2G6A9tOlIoSRgZWolYgKI9gVNs9ML2isslQiCyUg52odx6Bv4n4yfjKOyujob65/EMEWS5SKD4jQYFMQRAqjuxBgqoiDFIMuEYFFSDBzCQpkJmwrkBPD0rQZi6MaBAwlhq0AEgBKGMEngAuMXvwE19UKP39fb3Nvs9/acaaaME36AsSp860BP3SkMju+88cTOwV56agKGmuGmfR/U3Kd3Bg4K2lhT9bKukuqVuNLh9gwd5qjE+KXUyp+cKQJp/+Xh1Go+1nvrkjUzN5BdFz8AVWQXDWpkKqVEFE2lVHSVUgdEHZAAGO1jiIdBwvZJ3j5YyIF5HQbkNOqqpw6IOiABkH1pb44I74OFHJjXYXgpr+uqOiDqgARATk11gkI5sJAD81l9YViDYShlUVMNewyPG5KG44bThnMGCRnyDWthSB/LJH1sSBuUfANGWOIJB1p+n7pbytRdURB5RZSKBMQ/xj/OJ/nj/Me8eJw/xxPEh/m34IoH4fBPxiX5LJfkGZfkGZfknZRL8poqxYAUM5AAuJRQKMfkp8hU/+2T482t62qZuVMLWm9W4QUjp3ldfx6Z+wkc4hUhV6/NqLUcyN9dXV1d/F9Onbro4mMMXyaB6hoCmedCecTNpJ4nHwVdZBbXLDQbZhkXcSuENYZFRtlFlSpaXRsAiekUygvSY7H9feFb5wU/P8Q+wjckONo+2T86OM0+1zc9ON++yj8/uFHc6LpALnhVEKxWs8dT725xr3Vz7qB1j/q4SlSVDwQVCR0hz8PYHmcdiKnQsNBeUjHG9zqCvNEDIvVcFms8OSLVo4vazgZPAky+PzBb0qzbn2ba4bR3zfSlhuLSqqQZm/35cNVZFKui50NUm8vH+e6jOt4cbHBXqrrtreqyUc1YTI4GtVBKFJZW5Ut10lSJk3SZKZm0DPEGKUyHXGIqmxSkFZIsdPilIK2K5KY1k3yhqmHe+BS1z9yJT6aC8AykwfheYGM8mco/0NR6gVucqesBptZc29taizUmQ3GBKWe4dV0gkYdQPVqLtqI9SCjPAMdB5IrUfeEGrSxhXqkitVwlDk5VeAekdK3kjUqAKWwKk411cXvNvO81l8VtlWXNrYA72EP1NWRTUWUFApMo4qYaGY7EmNbGfe/IwK8Of576Gjv/8C624EtnlY7tC3b3fkCmmYY33Lb5OdzgebIL52MOm3BJ6qPUN2r45SNL8b07xix9BsTodoTIa4CANiwx9BtZ5sAqj6N8FT+Gn8Ev5q/lRYNNNsgGs8NmMCNOxsagKFFZYCjZI2O5IOzADlJg0wfJpqs0Nn1UbEyTOZ5Qv6uF6PRKgYQtR6sRmVZDjQSKg8xacTPFRmSKjcwkzxT7hBP9iVVTY86ozefXnaHCGLSVGt1HgdQ3dlpuPEFV6XW4GVRoUEoMnGjs5oZ2rBQ1raSiTysBtcQjMa0YFJLtT4xaVnf190ZdfvnI7zlDfGxv6xUjni2eUNeyrvcdaE8tjK4kHEchUky7UJeZNtXsdTgY3p8HLY4BXyUMtEXmkFMIUWHvoRlCIXo3FLTAnRCTn6FucjRhIorHE85XbYSE86kwfeckPZ5EZRQjwWyAw4kKEKcZBYUWaLLbGemdTxisoDdmyvk4YbQ7yKyQk6bRd3fAqzWrl8zyUF3XQink35UWj2vl0dJYYYkJI4WR4lHhFfGo9Lr8RlCaaGoyzbSsMC20XG+/3nGb/Zj9E/8ngXN+0yvGQw4SUlRZFN8M+sHs9MtBP4eJ7A9y5pDaTZ7qnGrDtm7sPUDriWjFOkGBUIDT9GlkSg6nUXROkzA3KOs9b9MFA5FoFT5KtgFOqXh4wmQ7UEfmkTVkC+HJEVKI8vFdzI11ofl8D6BKrXpeI2dg65Skz1DzitlYOy2D45Yb1ROYqShJMiaZqIc+DahBNU8NqeJPgPtJ6Y+ZhmiA/3D4YHpoQs0gDpqaAnRozQFJMpNQN1fZtZKYnGZG105Bo2sbWGDQpdQCc0Viw6j5BbaXZnpRhHO7nCLgmyjx0qVhxFP05ENf73vwhpsfxocd//z12xeuePbVJ+aG9u8fXbvg+E0nPlm84gcPtzlOvf/F/sbnjz21a/4QkCaz0p/xNsBEFeXhFMNFDTUUf4gXnCGz2WOgw071VgNzdtBhN9gQczIgN6M9ZusiaoueZKMPNmoPRTLxX990vosSpUFzOTLgK81/Aq9UGY0y0xipzDzRX9n3zsQUXtxJdhl3Wd+wCAbJ6CXjHFe5rvSNCcx0zHWBBAuskFYYFzhWulb4WgKbyPfFDcbrrTvFB6T71De8H5D3xPeMv7f6s1Xqhzj/VkSB6e9Zb6BIUw7KhkEFnXK0Ag/pGQ3ps1rGQw2GPfl9HOw7zK2zwbaesTQTvImuGiFIz4p0/zDSsh5sQHtCr9+eYVTNzJqiIHCrjGChXUHNpeYM0nWJYZ8aBEO3g4SNPwGUc8PfDn8r/IfreNcEGNdudjIJYjbzfoZpfAbTqMah2plpZXepBMRHccyhUrFhUwHfJHHWircf39Bx7eXL3977zqa7Dz+3efNzz920+cpm8jbm8WUvzutMpT9IpVL/sf+BQ/iR1P1fn8NL8fKvlu0AbncaBMZFwDEFW5h+m3WsZ7sg60ZHWce6LhMynZKINHBgGFWt4LeQu8iDMv8ijw2g44HqJ2ATwW8qrHcVOk4IhxGVHx/rouILauQCFGToyjgXom4BH5MQGYxj2Oc3CQmztUpg2gx9l4DDQgKsB5/xCK7F2xEV/meouZuVIlSITGYqH+ULunjPGAYB4MnYICYEwYBNBt337D+puVUiURvQbjWQdSW52DX67Zn3/6nsWv6GUZvzX5rw5jxow/Opj/At6CRS0ELacwcUMBJeELtxfSKGuVowehRcC+YsBxdIHC6NmIrmoTVoC3ocCehx494HAIfON58/o/Ywa5we1R61t0fjWIEDkojp1DDVOctOUjkGOqeTsZZhB0/Wz66oGcqdPNl6e2yyb/7VNBwYeIULxjEPleLPc3hFvhWUhXmgLgRKQgnQ1MwgQgJCQchpVkIYFalUuDC+oYY8Kh0ID3Muexjf8GSI/OQ7J9WfMdym+lKPeqKZkvugFT48Vkq4xvrGhufYZ4ZXcAulhfJy+8LwtfJ1we3yjuB78jtumxRmeq02KyHOilIBFqBQhN2g1ao3E6hYAL9N+7WbLAULNVNJ3I2Hd6ADRf14QVEOLyjK4QVF61XGC1SMVMAuaNu5QxR/1D0DFXhPZ0hH6ZCOySFA4KPsPSFckzDXeeZ51ni2eHiPmskAvcEw3NLgcdNXeZiq6ekmhZ3xLBuIN1PapwIpwwbO97DOYgKJdlhWAh2mQqerOBwNR6AbNIFDX0DRsilwAGNBMZcA7R8AJhBwFjB24DQHBMYOAlnBUxav0CQPlpjaSKUMFTl2KnKYcjmMcgvsZLqlJpS4i53egRNXNIyedQ0ZfWxJV+/337r1j6kzj9x2dv+HvcOm3jll3VNP3HD98/wMy/LyyeWjvvrDgpbUP37T1nMTnoQ34+d+uu/VSx82P9/U/egDL78M+HYYpPUOPkYtYzSFqZphYFeiZCBiLc/VYrDvSG0ZqkOE0vteOYPvrdAzdT1qT0bfZpgu8DI1r7xAenUndesK/odPnjzJNZ08eenZkyfhHVQaRoRnQC9jqm2nQx9Nuw44TJlRs+uAw5ThVHYActw/h6ltlDBTHMdBixJyuYJ2qqQZrTwfCpotGEleauhQgmAAzemlArTsZJlOCL0n1BNxSghVdqbmWdlxkn9TXlvefY5nHf9hes/0+4BscHgtpX7OobjsDsebFqvT4nBarGZQmBIOWnTC8riFWCzWhAtnqnHIyuO3aXwJKFMJG62QbZ66Rt2i3qXy6lapHy1IObQg5dCCtN7LaMELHat6iZc61Wn1vHvC9mO4GlnxvZBzeIflAD6Ch4PpfzxhzEq/Pfnd+J6MohXvOd9zPhe3m2uZ+ZQxngAZm4FvndkpD44LoHChXIWry1AulBuPgKDjdGxnbpqmLANGKGh2WIDr8y6F4b3LZQ3yDO+DZqsdNK+OlVa+D+/hX8kc3xT7HcNy8FsqdkRcEQ7wHrnYRFNs1o9dD668uWv/7tm7S567k7zfe2jqrXcfx/K1d5z/eS/eqrbdfuKJhzqm1rnJf76Y2jA3deHXr9/d8TF0+3ywANzCs9CXtzPMtpwwYx5+ROYNnBlRRCknmDeYzOs5jtBunsq0VI74rfJ6w1/QVOC48whXB6c1eAvIYJ8l06FTKA3UTj7fM0W9QGWTSukBtFcwbDTGD/0T6DKYOBh82nbM2l6pOR0iLhFxohQdarcPm88d2J3qmTTUepi7+W+38d/u331vyp662P37/fgL/PrD0Ip1qIcfwR8E7GhirchHqw3kG5lbLUiiYbXCK98IeHUdmUoI8Zlmz9HqNvl8LUiiM7W1qOw8VOs8dX+CvBIUiSNQofaVHNBpvLKiorKMab62SHUExgN63kZwqhXf9Ty+K9Xag+/ZR8/7UquhIrenlhGvcAQYxRJWkTjPxTFRBTGOJDtHiCS+xAtgVIpMA5ANBjKL8owX5UeWahgYpzWp1ZzWoOjDn2qwSGBogiyYZ+yROWgy2hJUKAp23+34jvffTy2Tpt37zfv3Al4/ipAwB2piBYVaY1r2cD4eIwfzQgQTmxqyIpmqnan/Qu28AOmUvPIbPLGwAecnmMIdppqMQWFquJelUKHK5hMN/vy8Pn+HkmFGqsawQKioYaYOhTO60AXGcBiQ0YO+7WKd0p3+B3O6MNNaYdpQc2jk3D57uVlz+Wcum/usItZZYzYlhnIBSRZlQeZlXvR5/V4iGhWTYlY40eV2uh1uTgxwngi2W+DglYMR7FZsEepXjcdL4bMNrOx2pDJTCMk4T8NOku1ywIEKj9sDCqqTWEi0KFKRsYdAPkUexd+8MOempmvXT7n+7pPbU+245u6nh4ybfP/KKftTvxSOuPKuuiZ16sSzqdRz8yv2Dx0y7vNnPv1HaYgGj6Q/Ez4U3kEWFMAz2YBN8luxU3U6A55AgOdV3mn0GAP8c56DltcsnMfjDZBwXsI21THVk/A3Co2G2eos2zzHHM88b4N/duB2z4NE9YU4zh4yGlz9RtqVM9IufaQPNrhiYQlLP8kxKiQwueh4SZpLjAHn2DBJVFIwtxQ1pphPirouLcxH5d+ah/OsJCOqrDpSWBVNwVAarDGKCll7w2TKOMeo+yTrK/EFF8zN+riamTNritqcVXcnf9cIaW5uDbQbgY9WdK00GjgfAB0rOS7HrkCRCp4OGh8tKCTDNK9UFQGOihbgXXjoL/D4F7pSB185lTqy7+c477e/x4FNn9/9q9RvyZt4FX7k1dTTfzidevzAz/Gcn6T+kTqFq3CgExt/kPoE2vIAQqIVyE3l6pnElkuNGgEQAPpJYzl9IWGkXShbzDYWuQJdC4BAbdASCpns9LZgNXEGhIlsMFqAUxDFKLJpPi0sAjr7IJvfUxE1YnVflE5Ul7r62cLUcK07flx9663j1GMQB1FODQOk28b51OkozhLZkWNHnh0FdpS7039NRClE2OwxxwaIsME2MOJX2FGiNWDTKZR28ykUA6sorNirrOwgmDiELUYky5iwMB/6NgawlxwlDciOVNKQMCNTDibor0WYtuV82XlG8XW1tVpjmrXWsA/KSNstiFhlJwnI/AbTDtPPoStNE00TrdwAvsg80NLIXc1vMG+07DTLRiLINeahlqlkEgcavjzZfLlFeYA8yN0n3Sfv456VRDuxWizlAnEKApFB7ykXZABl03TrdJzAhMiyQTEazWaLRaXj1GLfaif2I2QfENWQDiEsd+MhB0wGRZ86URR9ql8JJ0xbjNh4BJptwUbIS7rhZMUILPvccIYLGuUeakBh61oVq92k4VBYaBG2CpzQTfZ12kY2eeM+amI113p7KW/s8fvUHrjy51yeaaZmXy2bWdK/frWnp/8M05ByNClpnDEpGZo2p/HHyJS+CBj7HiLp95hKMylpgnsl0+Zoas8cFjH1z3aLQm9mAqjeORipsQyMsCCqg8NqLBXDGHhgEKRmAqXiTetam1FrM25uakJ0vMxGGcmCRTbJxMpYbSX7al5NYNCeocNwxBa14Si2PYAL8dXlbl816BzC0VTDy6lG4cjFv959Rf2PuEvfjud/cbGa//gi5TCvgOa+jc5pYY0qic6TOB0gkj7HJWUnXnH6m5zO/yY7cyWYMpNMAGSzXtS4J8t6Ueek0AKZUOO9c/hlzIjvrKzSzoPKtXPJAO0cLdLOeSHt7PVrRn+pWa0KC3uElwWOC4O4vwts6STiy0BnrUen0Tkk2MOQuAdxghYTR8ndm2EDX+ps4Ctdtl5IMFMXMXJGT/DvNeXIUxi2jq0Iw1jQSaPs1CJ1JeRQFoxSJ0hDOjYZX7PtlVeFI9+Oh35+GJSNfOhnAyGsnzmvyfQT1ily+qyGvB0NdiPzjDhcVbLX5CazOOrQywDnE1Gb7fJZsokdCbRZkp2SJBOJ42QDT4hBknkOhNjFrBDjcoQYp6cfaODCoijoXSBQxsX6RtB4KigXCT9jbM1hIw4b640txrXGrUbBKGdjKQ1KBjcMYc37b4Yq/x9UF42jZ6MZ/lWDUUbm9Hi8mfn7acxCJjaxV+tv4GkscqamZifPiFLjz4epTXHIZKuSw3BAzKgYUk71FRi6Ljkxvga68PjB8TVyokIDK2qkAl8NyJaPDvoArNBAmhplYMIYrZEsTvg76PX5gw4A8zQwD0AXBf/Z7spQq+5GYtxVI1gTJyMsAdHyRMMJNkVeo2EGBuQAQn34dY4cef1SCqhzG78FKHPrxa2g6TSm7xS+Ak3HhUoIxzSde+fFHosRn3eYixiDfD4fDQSd+c6oWCoM8sRjI4Vaz4jYVcJVnomxZmFWtDG2RriBu17Yze0W7kUPcU+hF7h30bvuT9Annk+8/qAQR6XCSIFvFu7x3hd7N8YXuUtjVe6a2ETvxOC4/HHRSbEGudE2yzUnOCevIX92eHbBMmGxa0XshtidwTtjv/f+IeYzerELeFZHoAbRUNDyQA3vdXpLhRECTzh3CSeVxLxuAYkRzuEXCL1AQmEoZOWIXBiSDP5++pY/B1X9Wc1aafDHHF6KSg6dUh2MJEwMOMeEo0NXrxwsVoGileNK4g+Xbi0lpRGdi0V03I1kVaxIDBDcmNWsjF4W/cPkqdE3oE+z6lOsJmcmE3W9qq7H5slES4KYRbZK9Q31DU3WNjejdZR505lDl4CQZPXGYoWhEre70EoSHCcVMi1MMlhDTAuzZrSwSs3lWEYPzLS10QiFIrdHihWLVCmrrrIXVmpKGqQOzWhnbAJxWKyY//vOdTWPPvLkz15PHXs5ice9QTW21b2f7lv1Aihq76f+hAN/WDr36kWPNMd31txw9XE894P38cIjP009/cGB1Ok7ypofxjUdWPlB6rcpyJz6VfFIH3XYgOJdAMzLiUcyZFRi1ka+UX5D5t2U+t1A/VX8SHk8f6W8wfqMcNYqmRCx0bko0eDsN87OnHF26uPc2eCMEZ0hkSxDIowh0wBmjSGR5rAbh931bkLnuLe6ObdZH91s/K5ZG92DDeZYWMGKzk6VcCZ+WmNMis6YlCxjUviMoqUxJiXLmJRmF2VMuRPJdPgnq6BMM2aV1bJrqZYdR2AZiTYwiA6uFA2IGDXKp9o1rrRlFGsW/sq8FTa+5dWFqYvv/Cr17dpXJ+y/8b2DwpFL7R+mLj15JzZ/zk291PHKgWtexU4YhCcQ4ul2CUbUwwbBJQohWZYkxPHUXlUMIdAaJdpip2qvkmZyV4aVsJkofjNv0Pspl4NnPJmG/7bR+W0XNcYzKaLml8/wbtPIq3O7qLmWTbXXTgF7ffL5M33GJyA2cHJmsAsy9NGBlYKAkUG3I/l+diT18GjKjSuS+T/BF156lItfepe7VTiyP1X3Ysq8HypfnFqGu5hPoUULs+CFuCSqHIkjbBehCPISzxXRyNgvaTAINOJFw4/mUBfkv3cmYMKcCdgiar5Wsc+ZgCPVwLirI7grtf799/EdqWX3isX3Qh32wfBspwIevc3qUMCG5y4wF/URgtF5OEzCRkL8xv/LIckIU1NGmKb+ZUCUkXP/ywE5ozmZWLBD7mAcYoPxnVGwf3cQ9nEfXvqEJHvr6QCM2N+7GGr6Ef88mSq8iji0gbad+lN/3unx0Yi44/RMBW4iBsAWvJWcxtwabgvawnFr0BpMpuJ6QhDiYLS4nZjH3aSlg+zgusmMA8jHv/8sa8bk3vO9qK63mZEYfKAtdLGo5iamhqujkvto+5d/4J/H3tTZdFoLvYEaPYlkul49gbQjvgWF0N/6rlEgYSEfR85FSERBV8QJjhwmBXRbHBxvrkYsalWM8aNQlFtDGzb6HuTIYWBqDmzPgW05cF5O5FQwBw7kwP4cmObXmWUwBw7kwP4c2JTDXM05sCUHtubAtP46rObA9hzYlgM7cmJtc+Nu7TmwLQc2Z4SxrEtlA42CnGw0VxXxZ/gzhj96PgkL7woXwsQjh6MGbyBs4LhoKCi6goDMEhajYIgpbxXhPUWPF5Eij8dvKdpjwzaeEoON6QI2FpJOI0psTkoGNhZsQcMdbIQShI0tf7CxYHSbzq1suoVs68bNnV49/MirU59Xi4ZLmBu8RXsCOMBKCmRLCrCSAtQBYaMlBZi4CCi0JEhNaaHCARMtM6AHwAegqIOIVEb1QqL6VGk04/NzNkSL8FsI7wHbheSjOjQVaIi+Lo8FzDBHBlJ1WoejO0PxOcEzTjY1ymLcEItZR77Com68sfO76z1YxJsWA6XmJDI3fvYy3tw7ha0HWQccsbYWOMVktUeleg7TcrTwYIvJ6Yg5TbYAtptdmbDgbXqsVPy/+AQSiqr4FRqbY3R1c+UHVxolAyeGWOhwNkgnXlfXL1AHVBwaPJETQUwhAGgs8d6KZ5ZvuD//pjcffb4zOnfU2h92NS68atsIPnbvlHnXNB55+WBvMXlk5bwR9z7Vez/p2Lix/qG7e9+HHp6R/oz3CceRB0VROXmtb4K0y4QCocGUW3kcDjJr8GB7JCQKJSG7OUS9OJoz9yDz6satVAGlWGLVo20owG5avRy9SVGW03Nx2blVrtDFBtPF3uhic6uuPj9U/+gMyn972MyYZugcCmnupExFRK0iZ1iwhlVf4pUpn6ZxNACygCbSYumTLjYx5WIt7WufXhiUhcsyFdD/dFZrcrUbD3BPdE+MfWr6vFwwlOMb0Y14M3+t3GpcZ7rOfL3ndtSGd/M75G3GW007zHd4fml7zWE3oZAXmaCkxwfjnM7sN2kVymGXIZ2VHGwIrX/FgA2j7WQJiufkjufkjudMccXXWxPhaFW5FSOraiXWbnx3V4XX9C90rkdueNcnOQxiZklnoZ6pUM9UqEeCFK536fEFYVfCRVx7hryuT4TF6ewXi/g4n50Myzpc7TXNrCttbFYzO99bkP64Ixj2g0rbEQ6X0dOgcAxO7QPCbEJMmxRrXteKWpuaAp3Qc4PZPFggINpLmE5iN4sRTSfJmf9lRiWO0WUfWqSR5IYjArsAUhzOnGnf3DlgvHztyk9fOf7FilU770hdeP/91IW7r9mxYun22xYv2TVi4p4Z2/btv3nLs1xgwAPLH//g9OOL7x8w8MSuY2mE8fG7fopnLr31lnkLdt56KT15z9Rntt78/D6Qlyj9GakR3gYSW6gpAlz6ow6nZk+HnTX3c5hwj3Evg6jfgDDdI5ZgyKtwZxE5i7vxcwdAieq8HjqYxnLR2TBQyajzrflG9QTTrqmHxYBxxsPiwpUYP7cn1egTvvyW6sgN6U95NxB2HF/IiXow+rxsbsYbRCz4NW6iM70DoorZarKGFGWAKxTkQwOCwgBz1Gzy+jCyhxnTDUsxZm5C9lgZC30oY1O+9pq6OsoVKb28pr5mr1FPxCvon1JKuWB2m8eZd5j5cbbZtg0Bbrp7pbrcudB9nXmTc4e5zXlb4GmzYjSZLbyEoTxMg+Xo/O5RTHfwMuNqEB4u3nuEPIV8NPoBaidA9cz2flSTq3DYc+jAvn5eeA2omV5K5eH/9vxwjM0PxzBdrEVi+vxwbM8gL4258L397+aFB/afF86ZFY73UUIvi3roUbXwh8ySpwxBdAhhTot8aKLSA7fSQDvALz5qMlu1GWCrNTiAzugdWjnA7PN6gy5t+ZOQXf5E8b+yooZOBX9nElgaljsfzIRJLm3EGrry712x5eUnbqy8ymk3ru/esXzZbmdX5IuXNr65YvHCm/ekzr730zS+xfvgzuTNm/c6HyUbb1xw8623hg+8vqRj4byHB4d+fOfx1N8/zYTmUXkSQqVkTl+Y6CFjvhejIptX0+FFGjygKUVeqqqXUG7stTF2bGOhTTavbWDcWBKyWvItUy2cxeJE9RgznDWrNnEWprP/BTSekvbsiXhzBQsoqWBsBjg1FR0qDc/58GfZ0NGcSvRFMCRKGT3YmAT6L0rtX9Z3iirLLSgxYYT/KncierV7dnQxt9K9yr8ker3/xtBu/+2hh9zP+Y/5v3B/Gr4QdlzmftS9382NGLBQJCWhqZZ5NNQhSAvBb9drwT5dtNj80cU5SJufg7T5OapmPq5Bxpx8xpwZAWNOPiMenrD1j3/YM5CGEh1AB4p03l+k8/4infcXrbdleb8tYSO2PfF+vL+HrbJisT7xTBB5JgqiL8LnKCpOf4yi6Y87I2ExrIeUtlKfPo3v4Y0WLb4H+jwb58ACfXIDS7PxPRpyjyLVVcU0sAfOCHDabmNBgDHMEF1b0rd2v3vz/Bk31g/FQ4+uOngJS6/d1XPD9f/5xIsfkF88fe3Gjuc237gXz1CvX33Vlt+tNXkbVmD5d6ex+lDqz6m/pj5Ldb70Clf1o4MnHt798sswLJtT00gLcHU1E9ujFIOQVe2SrKrduLITPWaR4ZywSY9ZvkcNuTDHcS/aHtnNOqv3AnSUxskpBwf+bZV0/o1jxFY1bOiwSlGisdgqxqfv/dXkOce2bSq+LAqaZGraMfxPbPnqg96LbzW13Xf0x6n8FLWM69NnuR4wy/xkvrY8zNO3tEvRVXuDDlizaw10wCb3X/5VZdlixVaKOTTCn0O8PWiUvEHeiC0uSaaquMS0NInRi6Sy5QdsRefJd15j9KECgdA/owaDCecHxzjGeGY4ZnhaHC2eH5EfcQ+Zn1Kf8ptks09ZTpZxy4XrTGvNW83PmA4YDioHTCa3aYfpz4SzFMyzrrFusXJWkAvPJ2LlbDqjBapFbYSP0TlkQFarEfXVMQhVZ3GufeZehl4S1gZroYUF1FsKAohNmvVlQ+mvstlQoTGeD2IVyD5hibM+womMrYITmV7DQ7UVtmFIomYITlAbBF9BORf201LwxKBLN3FcOmW5MgtzIw2uwlMSpss6SGa9BjOfJOaylfTYrMx6j4MN0pBAVd8aAG3Nbc6CgHWZDWdY8NbwJri77jylxHW6JguEozafgR9dFgAk16ovAQNDBDQVu8VqtfPezCoNOikORGeUskRXmZEo+gqNKhZy65FifVTG1bbnff3SB6l/rPv8tv1/yH/Zt2XOruefunX5nXi759ApnIeVFzHZ9vLewIqV//H2e6/eDJJibPosXwyYa0Y+nKa4e9DlzfiuzzLJQG2IxCIK+dgNu6T4TBPEK+QGsUleIi6T5Sp1hH2Eu9o7Tp1kn+Qe550rzDVMV5vtze7p3lXCKsNCdZV9lXuh9/vYZRAF89XcTGGmcrVpJbdIWKSsNCmeIC/ZwNimjtlcZ2wfZjizmoHa4CwMMN0pwNbRStkIXYnFtmRIQXfFMyAT6aCZH5loCAYALy0sqioH6pdUKSxxUnbpNx3s02B0s3k6ul4IYIuOSNktGSwZRBrdYClEJgv1idmZgcyoEgWZgcwQK2MHMz8AYpGaKAFFUwObIB3R+qK6tfjAgw1oiJ+uGcoEc+sfhnet8WbQbnLWFOaGVtB5WrrrhWGGMMNwjXCNgQcGzyaCAu1GG8Mwo5H3aFHcUk60xTAtPo0hWK6aPvap2372e+y+4S+3n071HO7YuaOjc/vODuLAxXduSP2x9+RfbsYhbP7lL37565/94k1o0njgh6eFI8iG8oiDsejNCuHNReYq81izUO2sDs4mM5XpzhnBJWShsMiwwNkSPJ7/jvCu40PfJ45PnF97/uL7JO/j/HS+Oz8/7q911/on+dfm78mXBpNC82D3CFJtnkTGmcc7JwZnKw3mJeZPxM/c3+LzFhW7OItRtaIAcCMbUlxBzugdreRIX6++1QDYXpWg5PYt5AWlxNpvLbf13zKxwgZrkaq+ZcMqSOEW21Ybn89wUYu3stmZY4jtecCcQyJzDDHstLGpBOYSYuvdbHoYRZ8z6Kheu4MNtmvtOsplY0jtlgxq2AslNZMmqZqnaGTDK9Ip6bSUlnh9qVooZ11aSBMYjCyYiif5GR34QlX1Oa5ZGqDOZhB6+3CL7syhMrTrjdeeyUwu0L+NLlGk7IyhXKCdo9pwQlnJgaCyIMUY0HBNslJ/NWBZJRgqFNMi1VRBAPNQ42G2ShvONQqHLzqx5d3rlr9zS8t9ZZ294Rev2/D0vhs27t3x6O6LTz6GubZpo4nl2/HE/ss3f/raB788AYJkLii8fwGNoJwbzfyiNtBz+sYxlgNnI7Jh+PUe9OmAH4DR+Rm/4dksLzLlwMYcOJgDB3S4q4HzZlQ3ogNYAxIlDQu4Bfx67lqeLyqu5mqCY7iJ0lV54/LHFo4vnsE1SXPzZpfc5rBEAVH03S40oEgHYjpQrANR5ojXMmtAkQ7EdKCYxhOMp1CJOVZICrnioqHWqujYonFlc8IN0VlFK43LzSssi52LvJuM15uvt96oXle4vmgH12a8zdxmvUPdXnhL0T3m+6z3uUKZAKRBkZg9EPMbYgNwDKEBfjtfMSSGFgH1mwdtCtwWIIEit3lQqLgIFwluIRtzKIQGGUIhN8d4Fd3chS6gzpyamTVW1qN9A4lBRYUWs1GIBPNCAVkSeY6IuKiwANJEIRQY5E9QxL7Lj/09bjSIWSUsZEDFYVyPW/BavAeLoFcnE6ZBobDDcfksWrBA5+/M9IpWBVpwpaGfSWrIEUKGPu+PIYYG4AHUZqH0PIDtzkALG+CviOjU2Tenqzt1oI9wzE6nEulTdn3KxE5n86z0cftMqj/6hiy4OhPheobyclWb4L2gz/WyiH26LA6s1vgZejhPe8rm0bbtALCJKRV9FIv77atAeX/gEA7gQQH3IIHNbg0yukNsXsXN6SoG6CiaVh8iQItadGRhMfPiaBsn6LqGx817mOlKJ4Bjcw+Z5/38xjXPz6ifOzK1ctqyJTf99YdPfrNDOGLd/1xyb81w/H7j1ut3XHzk9dTfHsS/VVffMfvy9WPHLYl65seHPblozU8XLvvlNsvtd267empl5YqSkQc2XHdq/bWfQ68cS03DTcx5MybjvME3JcBiEvYSojttUBhUxL08jd+n3Uc3EGquVb+imweB6gu6fdY34wAuc+yR1DTp5n/eBC+/DzTWUhBRAnqKCSgTJjwXEpAc5jHfTZ49IJFsxFF2fyYuOyXG/R+nxPRZygv/Elgi/rvQ2E+btRk/FjvM6ROQbLJWm++iM173vUp+Ixz59m/7gcp2gOZGA3hUkLF21oQbsGCyFgrVwjhBqMtP5pP8/IJgZfDyIJWc4ggHFaNXua/yN8vN5kZrs/t7/uXySvNS62r3av/x/PdNH3g+8P3J8aXnS9+fmez1hYUya5mzXKizJoSrrPXCYuGDvL/z36om1WXhRQIyVpQwiFgLiFi1n4jtIydvVm4WNHgL3zJi1Zgwthi3GnlNXhrZckCjNxMieYF1m1FX4Iz6uj8jXaDDIiEY5dGONF6LbURf/itnlHRbJbLrMaq8voA7s9BX26KkMruBVmaXrISvgSsi5DgGdvE4TuJzmM/HdXgq5jCdycwsUb+kTYFgZndh5o3DdipeMROpWFteLGpZ2fph7GWGiJMZIr7QhP6rvzOzHzSMiKWdYdI1e6svoqOuT8jCEyBlu7CiWlyamW7kRU3GihLRZGwN3fCknC0Qq7QB2YaIS0XRgmIOqLbP0zro2a517de83JpI/fXHx1aQqll3b3jx6es2vCgc6f37XVPvenN96uvUe4/g+16ZdfvJX7z1Gl3gcgtCeBgLzNumBeblbjWRja37NxtLfGcDiWzWf7NdxHe2hch5q45a2U0gDjUIbK8HFoI3bLgWildVrZ3Lh2jnAi1UL1Hk8lRZhXzhMeG0wE+FwzmByxfWCluFtMCD7aUQTls2Tt/EAshcldVVjyF8HOxb6Nh/s4b828yUWO7OOGzPByRnZsK0DR8ASOscILPzA5rC99/5gaICW0aghe+xq+9+gJcpbA2BHsl3S1cmkq/PG7JB42QlpEQlBkXFyG6g/hDlMcBkXNmFHuO+Z9HngSx66LFF2+uBAV8mrIpCZlHHG7G8aM94TGjx/+I1wVZDlrNGwRotBmFRXEk311FJ7zawbAsuK75+27E5k08BF/8Y//HY4fva5vzmYu8HX6X+mpIRgSFHQhOLkbCQNqa05cFI920DpuRMKhty0oUcmO/T5bObJ4q8rhfLekSjoG9xBtlEo/EnmWfPZ/HTpCfivsS+jVPc2aD3DGDUt4BU9LhDIRuAaNGroadIWsqhBmyxqlo4UVcG0HR+GsGXaOoLzNb2eitTy9Ul8lJDi7qL26O+IbwmHlfPqUZZaMINpF5dakyqfzP9zfw3i4E38WbewhkVg8DzJrNFFiXJBLAsmsC0RVlVA4UlkxNuEY6jaS6axoV5kxOeMoQEQQ6JnNhN1iYMSDZ9niCYkCPYiDA2gloVRoskbno9f4o/zXN7qIjEOGGsNx2XTpu4PSZsoteqFQwQskXaKhHpB9b3fqutqfPBH37eHi2muQewptbfU3emlq4tZaHM8RtVFssczyyJp/so7FRPnLCcOLFT0M6AdNkYZz2OuYu3crJ0JH2Obh+nzVSt67/Nzr8QUbssdnNDEqaVsowwL0NDM5HLNBKSBZZEcSWOchHOEeFixaLEkcpfk8YPX+j90d738X8+OB4EKiU7fCw1lszB9x3+/h23AwkOAGUiCbhswjM0/1/O9lDf3fCzA4w4ymGsZlvVFXiCfIWBU2SjgWTUaosJWczYGDLJshACGVsHOkGv1iuBRPwFHnMEY96g8LKixPIiVSUK/kbBShjzTkhXSozBKkwPcnf6d51w5mm4g4OmwiNCSBKJUQmZkKwcxQeg5jw+kAggqVxOyES+0lRnxEa/BVQscRrymQ8+qAW7nK9VWaRO7eTzYAieUS9lg5PAAmROLDYn1krDXy0wlPA/gdc1MU9EnDkiSEGkBnsjNYbu9EcHfDWkwMfCVJvYVpsdGCks9grJMg1wAqVUZME+FfCj3K4aDx0WqY64sBRxDSBf119x6Ve8/9IbTdy+Lu6FhVfu339JWkJVor3AUvbDMHhRAdnCeGHEbrRg+9DgnPzF8qp83sCWasvsKLEj2EzHmcrBNs6ggEkHjDoA2vqfOu3+Kjif6yworrLR67ziKjVztmbOdtrleTHtPuRXM2d6PzERgCLLlcErwzOMc4OrgusMGy2brNuVXdb7zc9Zu61nLZ9ZVWAVYZvVabNZbVaTwR4gEb9bEe10rw3BazC4PX5fyPOT9PGskPVQUUWljseDIgUsqMvrtVotcqhflGP/Ge1MlOOBhlDM8rCo79Eg6sqrSA0kH224KNIuEpvDhWsLtxZyhQVeXSPum77OasTe/6NGnAkSE//LiOvoyH3/Lkgss4LId8abWTimbbTFIsZAMsFFTRnbWUPbWEPIzs3mfKgFxHaCVeSEtcaqjrDZR1AExK1sBYQl/VHC76uxAV7a4W9JBGvUAif88+GfDaluCnQYfJ5uriJhXOnzIWwFBoILWLhsJjpNYyNaSHVEn97zuD2OKDeYFMeiURskaxtxRPaSthO/vP7NtyeXzLoqff7VWatnD4pM+iPeu/2+Kfc/mSoXjkz9+aaH38srKpxyXaoVD7l193Cj1HsdVzls04SldG+E0bibLCerwDy6jOG6by1Zy5HJeDIhOIqIX1hLLUt+7R3axgPqp6iMGkWoFcR3h76kuVxbuTmaDMDdByhDKEz/lZQKDyIPXs2EcrhfRJcxB5ZzYCkHFnNgha6XiFUZKMMrBGCrDyNQoRXMIbdqiFsV0R3kjFa1ABVgc5+7S8cue2bhTUGDvciE05I8zjCuRVoLAmaPxCMpLD0uJaXj0luSyJa7Zda9nWeoJ1FBy6ZKNEGbAZgvTNvhUPMGJ4zMLyxmnMKa11s6QpYjLx7avvg7ehrbEUHDyjPna5kjrLeWms62ykr1jRy0C7RzbhZRzRnpYtmKhGElBjS3WRRDNzeoY6VCt3ujS1XLMt7XIo/mE7NFqyttw9imwiw4gqj+q2qvWTnw1ls7DxxwxEtCex9TRy16gizYjaWVqTt29/5g8kA/DFxd+izXzo9C5XyI6eeeLInqgA+A0cPYuJTkWGi5U5uxfvsY9MGFOXA0By7IgSM5cFiHE5sb+AJnwQjDlYaxhQ0Fiwo2G+403Fr4jOOFga9yZoPH7/WUTxr4nkcIgEZE1AqseOfKcw1zlbnGuaa55uXycsNyZblxuWm5uSvWVWylHonCAUML5yhNxoWxhSXXRq8F1vQD5WHTPSX3D7y3/CnlOdOTxU+VdMZ+FnOX6NPbBToQ1YFCHSjRuHwmDwWiOlCoA3k0XMQeqpkjFxeZFN4fjrl44+A8P50QK/ANZM5fX51vqm+e72XfKZ9o9eX71vhO+/h8310+4vsxMD0XQtqWZwknza7SZWgqfgvYBlYxob6rTqe7ivmwVIutCuPBc/NW5pG8oEviu9nGtmynuU/13eQ+TTgo2vLBwcZ8P/YX+hIOb1UFfbyCIr/Pqx0p2vvYVju+MH3SF6ZP+djkvo9tFkHvjjawQfORq/sCMjobpMJSeN+BYM1bpbiUFk1fU6qLi1Jt3YNIgS9YT5Ye1Qe9s6HUz+oSKS6taqk4XkHqKrZWkAq6v1sh8mpBhIzlh7VhILMYQGtIgUO0kuHM7Iq7IVxoZdM6VtYQa5hFtFF54mTRbmxNo7a7gVVTzBO2BmvBaYRp+CJBviGZjdeaW/X1Emy2JK7Ced0UfcvceLyVOr5zDPQeOnUXp9tRtTJJQ+0y6nyjJ81pmYkeGbMpkSgeFIoKzoExm2pXHSonFpjDAWQokQJYGASHkBMuI5ZoABVEzSZ5gBLAJcUGRYzzAZSv5tGYRRpkVKsdmE5VGt+2bRvK1oZOGdIVeNkEmimQUEBBzzPGYnmDtaiUwUaf3+/KY3M7rr5Neel2UN8NSQGDbTCprqIrob/j3oNviGj+vVhdh/W2GzZvrC76wWsPTh09vPTuGTf+eI4taVq/bPNyt7sscOsr9zcse+3GU+/jy4Ir1i0ae1nUW1QxcduUCZtK8uNX3LDEO33u9GHRYJ5DKawcvXnunMdmvwjcqol/Hv+aRWi3MuFl5IbT+OyE1cbs72yQtt/tq6rH9RxJcPWIcGCLM3rZCUA3mdGBaWB2Syfx8a2HcRnS1NUe6i6lbkAtOpv2FeiYW4ku8EC/r8S/vvuz/6TR2em0tqM3i83mvxObXY2+/U5s9mM1X9eQmqBCY7NrcmOzCVqTmia9K7yLJqDZuJo1ajYfUcPuSKSo2lxpGWeZ6B0bGV84fuKEhpmW6wdY3EUDcMxQmhcbUO0fWjOmqMHblHd1pGFAw8SmhkXeRUWLB2zwX5+3rnC791b/7rzbIztjPotab0HcDLrFg2ItLjfWG4lRch8lV6AxaBI52jVmBKfk0y06RuBwfG2cxI/gyaiYHD1YdkWhVcJSN7klYVXrR6FC++PWwnJ1rUrUI/g5FCCPdtUNLy2E/AYUJY8mDOFqXO1rnL0745Xu6aX7bDT3nO+lBNCDynp6mul+0mDT1TWf6dH2js44qQL/X2tfHhhFkS5eVd3TM9M9M93TM5k7cySZyTGBQA5yEMkkhEMiEgQjQQIBDBoOOQLoeuDgsaCywrq/db2eoO5PUddHSDgCuAuKxwrLyj5X3dXVRUVF9yHqU9eDTN5X1T2TBNm3+8dO8lV9XV1d01Nd9fVX9V0Jf1FRSY2cXyLb5BkzJMlV08SZkMs13hSqwWy1VWanAJOqTK0urSsrseueyoRhYqHKMk4TbFeOUSvKSV5uDg+DUuXLwnmVZYJALVfy8qF2pUqtxOnOA3OskR9jwiSqlgLj2Ub42+sfnt66vfPRL1Zd9lB1Tu+WYGF2Rcuq255KPX3sk9SNr72Gf/YVFvCCWbvLvkk9+fk7qdtT34yfecV1+Fmc+AbfuWr+7/b8acKlTmvKdfPMqhtWTt4wP7FyceLRpsuv+tP6rbhu2+VtD/TP3yT78y9oxtbNj+Oc/3wrdeUnX6UeeqJ7XeebN6364Oe/fuvLt7GMw0dffvpo6p13jxTle/FFt987/tajizbeU7/l9zB4NqQ6+Qi8vVUUxK+xwbPaooxQLlCaFL4u3B0moXChJTe7NKs0uyF7RXhL2FTjrvFPcU/xt5out8xxz/EvNi2xdCrL3Ev8h8KvOt/2vO17NXjSeTJ4IjwQduXyQO2yKvgaZSI/RZmtfCD9LTulSHYb5wowB4uugE1CNu8wEbx3yAvdmxHBB1q8ecdFrIgJsV1MinyYCT/DCd186UPKTwHmSZszsdfGUMtxbUOXuR+WKekWV2NHGSk7D/enK6V7gftD6Pz7s+ltWWXItqwybFv263O3Zdn2Cla1bdnQpEoPHrYvm9mWjQOv94MdWc3Irnr4hiyy2W0uRn1tEhY4IcA4PCHtfTpercsfstI6f0w/Kt/ODRF6bvhlzd1XbTy+eM1fr5+9eaT9sbXXPvX46q6dqU7Dr++YPn3TwL2Ppr6/86Ka/u+5Xx57/uhrR4+8AVR0P5DDDegYUNFKNmY8hPr0qtU8ee1A/Daos40JR2D13kaFSFQogtOeu0Zpfrv2H2MejBzAoiQNrwLnP5c1FnSasewt8Y7ywtLC+4DlQesTVpPPWmDt9h7y8l5KnUO+UHm2ycpZ5ICIs0jc6eA5AYlbndg54NAe494WR4LP8KLu9EN2689WanFHecSRu7G2/zpa33+NB0LlWxD2Jhgfk7DSrVYnW1oWsHVlDtt8LdaXll/oS0unvrT8JG2N8CEba3TxyVxtoUc93mfwfhRBX2MR3hbxIU70qYZFrUK3Opik+3T8dBu1S6plzhur7dpr3qnYBbNRMAlEUGB9juyC7MfwAihavx7H4eW8yr8biS4H9UYzAlh/QZTZ6lDEmoytrFTbvQUWH8jWoN/PrCzK7vds3erw3bL2ojn+qtJLGl95hbt/08ol5RMvU/9DnNi+YNPZRZoBEHeKWT6+rMnEXNBpWW76sjyRYFomUb6Cm8Dtt/KsKAtepG6T3WJ3cgaM5IDB6JREyzBpjWXIlLdk+Pb8FkvUzDzLm/EhM3axWe5iLuzNzHm9mTmvN2ec15vZTrjZR+uZqbiZKTqYmfN6M13kM6GNWdS9OH69h+14XswMNt3UYb3rMxdZ4drm6nYNuHgXcaaHijMtr3GmR5HzH/t4/Qee603neK53DfFcTxgnenHWud6YdT/1lD8cwhTGB50p1mrCmYyTeptgM0ZtgsWPrSY5bYWC4tSjn3+PJCKRM8BwGLVrqcGI08Ka9G6+RhiG2pLsWndo7X827VqzpPkntYb9/V/c3fbLB/vnkYc3XD/jrhv7D8A7oyE1nfsE3hlUy7eQTdl2SQIeVIo6L5ImOAVztje7WIo5i3OrpTHOKdJEZ4txlnSV9J34VZZtZG5x/rjccfkX5W8p3lZsHBMZU1hXPFGaGJlQODMys7DTuDCysLC9OFn8Zv6pyKe5Z/LtbpeQ1Ud27ioIOIxMF1AJo1GonXkepn6HjcCR3ZhQDIGALE7ICVhEV1ZZtEwc9koRh1hyDTpYzWsRox7PcTdW3Al3uzvp5othQpNLi9lLxc00atwZjRo306ihru5Y6SfaQKO1qOs7XaPGrTlUAaReTMduYvtl3+nfaWlxr5ZxFOWE0qMqlB5wIZ02uVtCeQflV+S/ygMyH5Lr5GkyJ6cHo6xr3YxskZn3Z9nHFic5bHFCTcfSSxKmZSN748WrI+XnxrvRhfuDrxmtWHMucPJrur9wUtfjPakJXlYiGudABLrv4hByBAxMDgg9bslhLyDodSHLUcDYf8eQF1AcOKx5c9tgtLkpe8+ibORrOruU2XJXlNk1dn+o2teiHVLp+NU3bvTY8Nrutz67+g8/eea6xzre2vabT+577MYbtj993bXbZ/mmR0uvmF3ZfSeufftejDfdmzy7+JtXrn2KK/rDoYO/O/ziYSo6HDjFnaDB1vFejWj5YPKagWqRsMNFt0c/S3hVZ3ncgfNMDpcFO1wSvEXsAU5CZa5htMo1ZCy5MrQq0OKKetyUWPkYgXIzAuVW2TjJxItxM1LAxpE2Ypz6iNFJk5sZy7kp6bLSZzbgxofc2H2xj5IaF6VQvs98ZIVvm6/bN+DjfZnYSpmoTRZtcPRS0pmhT9T1a9h83HzCzJvT8kNzxge1TjVFRivpVzPKZGaUycwok/li7zDKpJOfHwbP0PxRM6FxbZofB6rk4xWbVbYSQXOwxQkKb/Ejq8muRUwqKloPjAxcCWyMiDk7M4TjJJcgavEIdGmyprAF3Da1FHezBSQLmsTV3fDa3EenKdIuyX719Ol3jd314K7Jy6ZVdJG7+3t/MnrS9BmbN5Lq79+EUbBo4CPDWuAvsnEJHQW7F5LF2XTnQ4uHhCg/OI9iYVRqXQhUZXV2Et2avQXdb3iK+//Wfdwu60vW4+hk9v9k221qtj07mysSCuxFgXBokrXFeVlWi/cqw5Ls69U71fu5+2z3B7bjX5Lt9tdsDuREPsWp+Hhq9tNTUM12WcIF1YqMMO93BC2cP8iblZg8BcWoOokv5E7vcw8yLhkvDe5Y2IRNupcGa4uJ8ZkmbzDjnyHtnuHrNm0lepp5ZdCdMKykNol4labyy8uKYuH9bJuQN1scjFew6Po46jCVX36IqwV9oU7XQvQ58LueuyB1+IPTqTce2IHHP/cXXDz2YNlzP3vi/TnLPvzxo+8RMvrM98/iq//rA3zpzhNHR2y7+5HUmZ8eSH18xzOazzm+H/gJK0zOkRrb12Ff4iRNSpPzcuVyJy9ZgrLNhtwezWJcHSZXOK/NT2+LGjMdGPhaJ7S2FpNIp5+JOWbW4nfQ0W3yhX0Y/n2ef+g1Aa61/qtShbTp+Q99AXiHqtuk9W0uVla2DfWWkHYG0F+reeH177RZmAm6zUZN0D3nN0EvZdskJBJh2/ppd3Kk8O6pS+9u/TT1cmojvv6Zh9ouGn1r6nbDfpvasWfZgVR//684vOmmObdkWeGXmREyXAgPwMHNYvvtEhoaF0tO49TDfVpIbRsUUquZQtOgjNsg6N3IZ85aB7UTHZ50ofkHKouJopaYir3YJZFCtdBRhSu5KlOVucpaY6tQKx2i6girkXKVJjbgLnsht+q5Wc9NlOtcCghPa3E0uQZfI5EYX2gskIpsMXUMX2OqkWiLk00z+TbTHGm2baZ6Je7gYQkrddo61DX8dSaqhniNeo3jx/wdxjvEn/N9pr3qi/zLpjf4P5n+bHtd/Yg/ZTpl+1AtFpgKuMVOLlVcNJVMNKX6OL0U0cWqkgVlORWPaBeofOtUwkYxRQDmD5lEQphiA5WxxuO6qLUN6KXZjGmgdU5SFIcMzDVWFKtddTgkeGzEKnEWhwjrPYU4zKLDEUZmJ0JmDoh22MIB08qJZjPHEeKwwusEmUqycJbb7QtbEhYCw33e3rC4RTwkcmIf7ts9j2wlhACWEIVdCaVZeUXhFKiUEMPI68x6LtK+nbEOPu/U/jbPB97TbafbAGGW0W0ZiRhNNximDvUNRh2ewkeWN9iU2lrT80MzTVD7PBPCxrVhnzGWZlIxiXod8lZjKhHz+KtVSj791Q4t46lxsb/alOOnUt1DPYFqFnMjFKh2JALVHIDV5nLXOlSX+wKTGTCOB0yiW+kjVWhTrZYs2ZELMMqO1EoixQjFLA43lDncUEYxAlh82GeoPXcrXnmuoqN/r9VEfboR3cMRnagYl2nuyADLxVSsj82kMmX5CIszckePx/mv9veT+GepzaHI6KzUFnKW/Ca1cU1d82X4tv6pZ78l0oiK5mCKWoZSrcGPNcV2VITf0bgZHkhaISU/PD8xtyV3UW6X+Vaz0OlbY1hh7pJuMdwiCfkuM+fJLwq6sqmy6akhii2DGsQZd/AJT4vZ7FCDRUWFhUhz/hkKBu3I5BlGfD1DiK9niIsiT0ywUHIp0M2YKBPtMrMEgXkwFUz0TgW2CSIw3TRhZnRYu8P9V6fbVVqiMUuAtmth5NzCNHppWxZfMdyjTsIHfVdnSHjwn5LwtKrkD2l3/DyqkkwvVqPbQ7fzz/XpwiLcMd05zDbpmTsAf49ZLWK6BqqKUfD8/kLtPxThQmojuThSqnkNBSoP5yrZFiPg95DY9qNdi668bfNlyWc3pX6GL1hfNaVp4s0Ppd7Cy+bGxs+umfnzTamnDftb93XMfaws/5nklTvbR3OX2F2Lpl64vPD7bUZL1ZKJl/xoNHRTBBZ1nwKv7CMvMDGe7MksgzOGTDriSiMyb7X+Rn8Jf5nWbrelz1rTiCVTP2PBkkYyIUQpC5tuKqPCQhncoeZp2aJT5iQu4JVVQRIcCRWWQAlLWGZCJ9lbEve97fMc83kVmrHYKOwJ+HvlAJYpAegKVBc4W+QdIpewJmQihwtGlSs0MVrMqsvqUfOlfEu+dYxljLXCdp9dKlALHJNdrWqrozWrU+10dGb9SFhr/ZH9Oud1WbdZ77BvUjc5bnfeK26XnlEO2Pc7PxE/cn5l7Ve+dQ4EgqrDY7M1pF8ELocU8PNyo3wrLOa8mR+hRXDRVNAp+a+UZYtiV1URcV6nwxFVRSccyBbZbolKolMC6kQjc0oCbQAFlAApCRwMkEAfqdstQ48knH1kZkKqUxMqmaceVInahxv2yDgHTfCL9BTrs0TYMsoyzcI1WwbYS6Ght0SGHiJ1u/zhGxZ54tCF/VR3yudhqlMe5cuTXhpD4LTPo5xmGIzY02nCPzJuoopUBqD8Nt3XtU7um7ptM5q6PYOqUwc0m4aBU9TUuTWejqTrHHhnT2W1mFNZDa/3U7uzqu268kMrpbJoZVsct7XGh32A4u70Un3lhLjUK8uiyHqTRTLTjIrytcVmJSW/6ahmNPBIbs5NzrHFtZPd9phBSi177u14Tij+/q7U0vq8UTe0lKeufEIpyPMvkbP5gv771qy/YS1Z8v1vdzS0zoBJsgyWEvtgKRHFjzOe1ed3+rNIez6ea3JglcvLQxHVTaIoyCSrVNVNuBRjwR20cZGgYMbwDojmDSN6eUOIXl6G6Flb8sIcFybh/HYWufhkxiMYo12AvMloF1PhY3JIsiqZj/Oz0+QwO00OszPrh2zmCCyzfhCZLFb0xhZePmz9MFXXemnTN6Mpd5Lx7U51RTMSyLQTlEbqg88X8AY4wRJTolmxUMwU5WO5UY81O4JcsiMClZ2OsBGOcgzRCA5I7gh22iEJmiMRlMdBwsSLWJdFpj9FzJeKfy+XyMuL2Jjv791LMbZRzw+le5cKZuCJbG62erFxQ0SOJdS+Q5e5VUTtwxYxLrdxJKFbXUaByXRgjNi5i8iyzanj2/6U2rqrFze/tRXju2M7Igv2LL/tuWsiVRsw+em6z8aRul/h/hOruvbhuX96HXfturLv/41akZw6/dZpG7c+n/omOb8S22GMyAhxnwMhVUhc08mzDhI06vQ6zQNnCrlzqFyWjCWBJ2aBCFYRiTp1K6GLhbo6tqLz75VVLAN3JFCi1uytni3fw99jgsWnfMhwSDhkPCqb5YSr2sc5zFlWn1KBa6T1+C7JVKJexrcaW6VZtl/ge8V7pb2kz/Jb6Yjtd8qb3GvmP1jfUj4QVXWQdVXt8BpQ0qwrxWTGuooiEX7Iui4SBE5jXgUzY19lWaHcqyxblQzrqogCEF5ReRG9aCZKNMO8vmjF1uhQ/lVQGP8qTlOxeqF1nSVHlOcL5nUJ4Fv9exNCs5BkaqPjE7Ywt47kTIOuv9B+w/N6GCQWKBHIl/KB8uXpH7CqI+NtOqvaphMsyqky9vR5LYXMyGhYbatGpHbZPNnVjIuUsqstOe5qDoAe90SqFTrZxSxgLiPVZmBA0+O3lcUHjaeJlz9hYd1H4z/Cw0XDPGECr+imVKqS8opcPpbxran73n10ZKA42vtG6qf4zrffrEl9TApw6ttJoxrKvk9Z+n+Pp7Sm2mAxzWKusKgTNrSVEaYS4P+kn0mPSp9JBhhlNOjlRLFF7BB3i++JRkm0GWk0CmOtIBhsvPSUSOOz5BpqeRagYj0sDQVjLS9WSTWGEr6OJ9Q25WE5HayilgqoWGAWGiO9v/+0okVpYeErENNGWolWrfTvlcRhQSxKhoaxyARtOaaHbUnHtBgM3jI51cmd4MchBQXwb9jPWiqROCnyjCVN5EcWoS6rztvk3RLcFjSUO8r9dcFGR6N/hmOGf6Fjob89mAz+UXhN/VD42PKJRykkOZZ4VjWpsFxIJlpmk07yZ8tbnvddH3s/9J8lMuatTl9AMtoEZ4CXkM1tK0PDNpCHxk9FQzaQETXJlLEiJ+R2OSnzQbaBHGQbyDLbQJYzG8gy20CWXboeSUrbQZBddDtQTqu1sOqMC5VXnyfKnK6c4m6x5/3A6vIcy/FEQYsxjxlisi1iI9siNjIrYCOzUjd6s4Pnbg7re8NDNobT28JU6+xcKaQmhMS8k+0B85JNsEo+JoSUhgshsV03Hh+jb/oOs7ssLvrFpb9OnVn+6roXVj7SH/nVtV2P7Vi75tFUJzGNvRiPxMZtqVseu+u78dzTx44dfumPr78Ec30Feo8fyx9GArpBsz5Iks084QnmjAZygMymOsZkdo8hgffjZmSA8Z2FnhKegtdqrYB8prABG9YYaXwH5cM24Oxrp55G3hLfafh4fPpY1mJS+xMSh2CeUPXnhIEN5dKSY/CSOcacDeEK+s+PPVvB4bMD3FGyPjW/F9fh2t7UIhjDq/DDfA0vsIAwV7EbzTcImDeaUZTDUY4YozwvREcRvJW8AmvHgwbkM2OvSQs8cVLTnQS+i06vWnZXTEmdecHS7OkEAXgNGoKCsBAUJbpvRlgnVET4mrNV3G8pcHO39z9AHRNtgzn1HZAKL9a67YICvsBQ4Kriq8RqaTI/WZwstfKXmxfzi83X89eLd/B3iHbV5bVwEoFMFojoDBglq42UeaPUTl1bVfmHrKpOpiVhH6ZLUul11qe79JCHH2lx0pHfpklJ+9MmK5mV2N8STJaBfO3+pJ90+w/5yXH/CT/xy5ao1WrTtLaGW5N8k7YmOcu+j5XQ7wPkDJPL2pgJhMyQ/gSbCCds+JDtuI0gW9jWbeNsXl8fHrNTs0tuGzRzp7wQrP+gZKjgtnZq/0ltTtQOhmBkQ2YvdJAocUaYF6V7lholr2DTd7WrNdEbtudWCFRrJD+Wb8/NeEEdU2Hnvnu4vGxi24zEqJqenvI1FzWvK6dRVNc1Bwsj3in9KcOvU+O++unMWXd+iV843zTYzCUNhDMInIkY6DSAoQfTgCQEOg2INg3wU2Ge+Ex8LVsg69Pg67ZaGn6FzoKp558GPMKYGOAlnyDnTgNHBc7COGsFd/RsiiNk/XZ8f2/q+dSzvdD+KIT4/dTgBrvZylJIM6nGNCKkPasb/6lndSHtWd34TzyrJ2wtBhLkOeptVDDw5j7S1RvW7Ef2CmFMSqjTM4x3Y6xFXjtFhySV2Oq7BF+kB+176WF8Nj020wZW0KKJmioM7hNQS1Cl/2TbhwrzpKq5UR3qFn0XMgksZEzPUk43NaBSDjpZaawYRyqbvyPlN1iffvq7/4Hbqhz4iJtPt32wlz1dpYNcKawma4SN1o12wcxWGbskusjow75dfFA2m4etLobbFGf0780xUTQNq2gaUtE06I7YFJM0pQZmlaDFe5LSE1pKi1BoiTadpLawA4cdCUezo93BO3AMpb1Uo3SAXED+ou+yNKl70p7OTyu6E2E9ELtuhng6XsfG3m4YeWaZZwQPfqNmnTpcrZBJhTRR4tgdxhULL1xc8Fzrszc/ewxv82y/YXzXOu6Ls96+I4vfgW6dzfXifGaDW8u6NQsZOGz4lCBufRhvwQQvFlY+zqYEFaPo09q/m8coQbR4x4xnc1A+hts48tgoaE/96qvUpzAU3011wiP8GxB8TTRuwXVUJx55+fH1Q2g6M7eljBH9CRw8/RD/RKrz5psRVStIf+bJtV8hzXEreq+0v31obtLKBZS+AlLjuNTFDBcHHkRXoHM/08gsmIpdyEeqofpLA48APgVgA4+QD7+ENgLeRJ5Et0FeC3ApwF+h7pOQT4V8n142n/8VWgXHdxpeQg8J1Wih8CS6F44PwvGDcDwL8ocNLegRKMvn30fboc13aNtQbwPkM+j3Q95C24NzN8D3NwPeCDARrptDnOgZwO8B+DHc1y20jqFloB/aKqRtw3E9tJEH19UB3kp/hymEltPfAuX7ARzsd3WhBoBb4JpF0O5DAGaAe+C6CNznMshl/fdNht+0gv4u/kG0jeHvo1FwvhJvQLP5roF3B7uRtGjAB6HHP4DOdiBkeQIh258Rss9GSP0PhLLyEXLfCWPlBYS8MxDyH0YoUIFQcCtCoQ6ATxEKX4tQTiFCuR8hlH8jQgXQVhzaGvEIQiVw/agGgBcRGv0cQqUzAR5AaMwqhKqPIlTThFAtlNc9jFCiFKGG/0ZoAtSf1ItQ00YAaOuix+CRu6BrdyA0fRFCM6HepfsQmvU4QD9Cs/fACINRMu8zhNorEVqwGqErngT4O0KLHkToqu0ILZmO0LLLELoa2l+xDKHVfoTWwr3+CO7xeri3dfAkb1IQWj8C4I8I3Qzt3VoO8AZCP1YR2tAJAH2w0chG6TQYs9fCFKJBjBSUQD+GlYbbUsKOoRPRPZmxnIfS45oA55Sn4xxgcR3nAZ+m47DGQV06LkD5OqiJeTOUTEaP6Di849EnOs5B+Tc6zqPJQPY03IBceKOOC1D+UEVlx4KyitEdI8qryq8YUV5aVjqiqnr06BELF4yZv3DM/EULy+d3XNJx5Zql81f9K1X/lTotHau6OpdfHR49cvS/Uh1VoErUgRagMsBGAzYClaMqgCsYVgrlpYBVoWo4OxqwhVB3DJoPOU0XQV4OeQe6BOBKtAYthaNV/7ZW/13ttACsgmfciZajq1EY6o4E+He1zqH/87Nz5m31EldM/0gOykYhLs4VoVrIi3qE7FAfV9Ab84SOP8MVohMAhCvsiWeH9nH5XHbP2FCij8vtVbNK5foRHOU1SlgahnQ5wA6AgwA8mscFoVyB9CaAJMAOgIMAxwGA0ENKz4YBlgNsBThBz3DZXKAnHFLq8zkvXOuFoS5zbnQGYACAg/t0w7e60TSAeQCbAbYCCKweLVkOcBPAQYDP2JkE5+65uwzu3d1zJ8t6Fy8tZYfztcM5beyw97JWLZ86XcsbL9Sq1WjVRpdrxSMbtDy/WMvVaGmS5qK19FC9i3PBj3TBja+AFJPnmf+MENrGZaFuAMIJekmCU3vzYqVbD3LAjXKEw/CsQwOHONxjtZfWi2SAnEEqCpFPyWntDDnda7OXbq2fQt5DOwAOAnDkPfh7l7yLbiInaJ9DWgewFeAgwCsAZwAEcgL+/gp/75B34FXxNioBqAOYB7AV4CDAGQAjeRtShfyFEiGWUrwOgJC/QKqQt+BnvQWpTN4E7E3yJtzaqz2V1aX7GBIv0ZFQVEfcfh1RXaV95L96vi2EERWDJw0j6gCXg8ahMi6nJzoahp+np7Yz1Efe7w3HQ9vqR5E/om4AIKmQKgBhgGaAdoAVAAJgrwP2OkoCbAHYBtANAKMMUgUgTI4A/A7gdTQKIAHQDGAix3vga/rIKz2xhlC9i/yevITc0OPHyG9Z/jvyIsuPkhdY/jLkQciPkBd7giFUL8F5BNcokCuQl8B5A3m2N08NDdTbyUHouxCkJQB1ANMA5gFsBhDIQZLTc0VIhUYOoCPwMgmRHvQxyx9Dj5hQYnEoERsPAzBMk1jNBYBBsjW8NUYSsXvug0OaxO66GzCaxG7dBBhNYtetB4wmsaVrAaNJ7IrFgNEkNnseYDSJTZsJGCR95KG9efmhymlLcLheJtdAL10DvXQN9NI1iCfX0D/0LU/v7YGeoiLosfsT8cKiUHI/Tj6Dk5fg5CM42YGT63ByPU7W4uRcnIzjZAAngziZwMkDuAq6IglrnWGH1QkPTh7ByadxsgsnYzgZxck8nAzjykQfifRcWMayCSzrraeTDvILxgH1kUkEejQCYz4CNOEgpK8ADLCjBFQK52iVvUGa5/QW1WnHI2tKl8P0OQwXHobHcBh4wsNArkogbQd4BYCDYX0YGj8Mj+owOgRwBmCA0HXpX4FkYriOpjKkJQB1APMAbgI4AyCw2zkDQNBy/RZ3sBujN12i3/g0AJ4chr8c+IuQSCJbCShxZTK3OYDlIJ4WHAiSSuQCngepdpO9D1v3/N36zd+tyFxvJneRzZR0ky16vrnnWyDd+N6e2IFQfRb+BQoCf09dqcZwFPIq1MWOK1DARPNyFCBPQV7aE2iBy+SeWHFoP7bRq/aEvg2cDH0c6COAngocCL0R7uNxT+g1KHlqT+iPgdtDL5f0maDkmRgsOXtC+8Os6r5AVejpI6zqejhxf09oHc32hG4MTAotCbATHdqJuV1wlJBDl8RmhyZDe42BBaFEF7S5J1QXmBuq1WpV0Gv2hEbBLcQ1tAhutjDAvjQ3CCW7QhWXXlrZh69KFBvvMc4yTjOOMZYai40RY8iYbfQbnSbVpJhobDXRZDIJJt5EYKHhpLo1ccqQOQWFZgJPU57hCrWNYvwbJX3YRNAU1O3gmkjTjAbc1H1oIWpaEO7+ekZuHxanz+425DbgbrUJNc1s6K6KN/UZBy7prow3dRubL5+1E+O7WqG0m2zsw2jmrD48QItu83er46l/S2y/7Sd+mhfc9pPWVuRxra3z1Knj7NUTG8+TtOvpkB0bzzA8u6H7nqYZs3oqnnwyu6G1u5ThAwOAN3X/bEZ4zqx9+Av82YTGffhzmrXO2seNw19MuISWc+MaW1ub+nALq4fC+HOoB0Pnc1bPBG9pWg+FTUGt3v1avShcD/XyaAb1zGYUZfWiZjOrx2Nab2dX3oTGnXl5rI47jLpYnS53eGidI1GoE42yOq4kOsLqHHElaZ3ucaxKIABVggFWBftQgFUJYB+r0jJYpUSvcnumyu3smzg8WCeg1bGeSNexnoA68X/109EQj+Pesa0L50zoyJ3QnjuhA6C9+861V3m6kwvC4Z0LW+mJcDcXa1+w8Cqaz+/obs3taOxemNsY3jl2znlOz6Gnx+Y27kRzJsyctXNOoqOxZ2xi7ITc+Y2tvZOayyuHfdftme8qbz5PY820sXL6XZMqz3O6kp6eRL+rkn5XJf2uSYlJ7LsQG+rNs3aaUEPr+Dla3kskEYZtuz/S2uBSVoxjY3hsxLPOvx9Yl+1Iird2W3Ibuq0A9NSI+hH19BRMLXrKBsWyfsqzbmzEvx9v108pUGzPbUDx1Wu61iDPhM5G7b8LPlC0eg3tcC2Nd/2jD5yb0J2Y39gFq76m7qIZTd1102fP2mk0Qmk7/UndNekySZrQN3BIKxwJhTW0kOMyFWlZLS0zm/WKP3z+a/ScifuT5EAvTgTxatTVynUHm2YSoAgzZ8NvnTN71n5grOi7oqsVfmAXjuOudBv6bacjd8YR/c1pWL1Gx/S+WK3n2pVwSVe6SzIf2lnxTI+tZs2y7ozPmVVv48ZwJageeOdRkI+AfATkpZCXciUJNRbiSGXIbKoMSWJjyCg0htKttsbR/wJRrq47DQplbmRzdHJlYW0NZW5kb2JqDTMzIDAgb2JqDTw8L0FzY2VudCA3MjgvQXZnV2lkdGggMjc3L0NJRFNldCAzMSAwIFIvQ2FwSGVpZ2h0IDE0NjcvRGVzY2VudCAtMjEwL0ZsYWdzIDMyL0ZvbnRCQm94WzAuMCAtMjExLjAgMTAwMC4wIDkwNi4wXS9Gb250RmlsZTIgMzIgMCBSL0ZvbnROYW1lL1pETFVUQytBcmlhbC9JdGFsaWNBbmdsZSAwL0xlYWRpbmcgMTA4OC9NYXhXaWR0aCAyNzcvTWlzc2luZ1dpZHRoIDI3Ny9TdGVtSCAwL1N0ZW1WIDgwL1R5cGUvRm9udERlc2NyaXB0b3IvWEhlaWdodCAwPj4NZW5kb2JqDTM0IDAgb2JqDTw8L0Jhc2VGb250L1pETFVUQytBcmlhbC9DSURTeXN0ZW1JbmZvPDwvT3JkZXJpbmcoSWRlbnRpdHkpL1JlZ2lzdHJ5KEFkb2JlKS9TdXBwbGVtZW50IDA+Pi9DSURUb0dJRE1hcC9JZGVudGl0eS9EVyAxMDAwL0ZvbnREZXNjcmlwdG9yIDMzIDAgUi9TdWJ0eXBlL0NJREZvbnRUeXBlMi9UeXBlL0ZvbnQvV1sxWzU1Ni4wXTJbMjc3LjBdM1syMjIuMF00WzU1Ni4wXTVbNTU2LjBdNls1MDAuMF03WzIyMi4wXThbNTU2LjBdOVszMzMuMF0xMFs1NTYuMF0xMVs1NTYuMF0xMls1NTYuMF0xM1syNzcuMF0xNFs1NTYuMF0xNVsyNzcuMF0xNls1NTYuMF0xN1s1NTYuMF0xOFs1ODMuMF0xOVsyNzcuMF0yMFs3MjIuMF0yMVs3NzcuMF0yMls4MzMuMF0yM1syNzcuMF0yNFs3MjIuMF0yNVs3NzcuMF0yNls3MjIuMF0yN1s2NjYuMF0yOFsyNzcuMF0yOVs2MTAuMF0zMVs1NTYuMF0zMls4MzMuMF0zM1s1NTYuMF0zNFsyNzcuMF0zNVs1NTYuMF0zNls1NTYuMF0zN1szMzMuMF0zOFs1MDAuMF0zOVs1NTYuMF00MFs1NTYuMF00MVs2NjYuMF00MlsyNTkuMF00M1s1NTYuMF00NFs1NTYuMF00NVsyMjIuMF00NlszMzMuMF00N1s2NjYuMF00OFs2MTAuMF00OVs3MjIuMF01MFszMzMuMF01MVsyNzcuMF01Mls1MDAuMF01NFs1NTYuMF01NVsxMDE1LjBdNTZbNTU2LjBdNTdbMjc3LjBdNThbMjc3LjBdNTlbNTU2LjBdNjBbNTU2LjBdNjFbNTU2LjBdNjJbNzIyLjBdNjNbNjY2LjBdNjRbNjY2LjBdNjVbNjY2LjBdNjZbNTAwLjBdNjdbNzc3LjBdNjhbNTAwLjBdNjlbMjc3LjBdNzBbNTU2LjBdNzFbNTgzLjBdNzJbNTgzLjBdNzNbNTc2LjBdNzRbNTgzLjBdNzVbNjEwLjBdNzZbNTAwLjBdNzdbMTkwLjBdNzhbNTU2LjBdXT4+DWVuZG9iag0zNSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDExPj5zdHJlYW0NCnhe+w8BDwAjxQfaDQplbmRzdHJlYW0NZW5kb2JqDTM2IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTc5ODEvTGVuZ3RoMSAyNjgwND4+c3RyZWFtDQp4Xu28eXxUVZY4fu59e+37llSqKpVUliIkJJWEQCQvECIQkbCaoJGwgwskLIJ2C3FjVcENULGJG9C4UCQsCUsbl7ZbexyxXRrt7jHdjaK2jEw3Iq2k6nfuqwKxp2c+8/195zPff+YV9527nbuce86559x3CRAAMEIHcNA4YXJxqXP59XEA+B2G1tk3z2y7efItnwOQagDx29m3LAsmX33hSgB5KIDUOq9t/s2H86w7AczbsHzE/JtunXdddvUOAOcJgOFfLZg7c070liuPAkz8JbZXsQAzpBcTuQCTMAk5C25etnKgyDkP0zmY/vKmxbNngnTz3wAmWzB95uaZK9vkJzPzAaaw+sFFM2+e63z37YmYDgLQH7ctXroMx43PtO2svG3J3DZuQsWLmMY+rV8Dx71Hj4IAsvCYUIazyEhB7h2YR22yQPUST9nD98PgZB+svBZbUVh7U8aPCgL+kheEdxMTSZk0gnSpQJLJJAAfEQ6z3sCJby4dMjU6Ap2HKYzxceDpOMxYAir2X4q18yAfCmAQFMFgKIEhmBeDYVALI2EU1MFoqIexMA6ugvFwNUyARpiIRJqME58K02AmzILZMAfmwjyYDwtgIdwAN8HNsAgWQxu0Yy9LYRksh1tgJdwKn8HnbJz/T/r8n36W/I//JDBACLKRkj6k6VCogkooh2LwQBRXPow0HwZ+pHU+5CCHZIIbciEDssALESgDE1jABToQcS3suDZWqAAb8owCFHhwgAxm5Bc9rpcRCnHdgjjH/+Wk/4lnyf/47385qeR/Oem/5fc/z0mAe2CmFnZBJh/BNiF58mJILEyeZGUM0i9w3/WnQvrpgufhNySfBKGbfItjOU+8ZAiuOg/fYK97YQAewV6nwBZiw/G6cOXHEh7rROFe8njyluTncAU8CE8lD5E7k3uwfBO8DudxBP/CE5z31Vh/KnLI59wn0Jx8DEe/Fsc+HCYRF/LPB/j7GsfwEDwMPyM/Tp7XZngntleNPFibfDl5Aed4L79ZOKEcgAfgCBGTs5MLkVbZsIFGkx8kP0aaNcPT8DyOKUr6+DFI+RvhHthGvNzrGHsEnoEEMdAWbpTwEvY0Fvl2EayADbAH3iQ20iicEM4kf5Q8hfS244rMRC7+nJST8fRZ3pAckfwIroVe+CXOl/36+Gv5XcK1iZrkE8lXcO0OER05Sl4WSoX7B+5IPpl8EVc+git7Bc57GkrHXfAyvAH/Bn+hq5OrYQxKzgr4OfGTIIkgxT+gXrqKruLexbWshRYc7XLYAXFckcNwBI4hbX4L/fAJcZAMMo7MIg+Qv1ADnUPf5h7n9nPv8YT/KdI7jNxTiHL2LByEf4K34G0iYPslpJHcQBaTreQJ0k/j9Ev6DS/zd/Hf8QNCJNGf+C55dfJr5EgfyvZtsBpp+zR0w374Z3gf/gJ/hXPEQoaSBeRJEif95Euq0Gw6gbbRLfRZ+gJ3NfcA9zJfzo/kb+Tf4j8S1ggbpZlS4sLOxEOJFxLvJA8l30HeMWH7EdQgC+EO5Ipn4SV4F1v/EH4Pf2T8g+0PJ9PJ9djLUrKOPExeID8n75AvcJag/bLpcFqHvS6mS5BOd9KH6MPY+9v4O04/or+nf6ZfcwKXzVVw7dyTXJzr4Y5zn/IWPsIP5ofwE/jpfBJXplS4Upgs7BaeE14RzojV4hyxTfxMulO6W/6ngcKBf0lAYkEinuhG3pWRk25DSvwEnkK+349r8CZS9J9xxP1wFlfBR0IkD8ddRepJAxlPriHXkbnkTrKWPEi2kcfJU+RFnAHOgUo49iitpZPpTDqX3k3X0vvofvwdpm/QD+gJehpH7ubCXJQbwo3lpnPXcotwDsu4VdzdSNkHuD3c29y73CnuM+40rpqbz+KX87fxj/K7+P38O8JVws34e0p4SegT3hEuCBdEKvrETLFYvEHcLf5REqUKqVFaL70n/VVuI5mkEEcevFwlUi/KYBbdQx38anIaM/yER63yAERxHSajVPwVargErouJlePYnNTL2xmmqKItDXQZOQLl5OewWqQcs6/7oYv8jvbzr9Ir4H3SSrz8Lm6R8CYNwXOojTbTo/QIGQn7aTWdRrejSf4J2Q2fIL+vhIfJjWQpPEdOk2HkdlJJVsN71MVNJndDdfIpyhOFjCVnAEcAd/Bz4Hr4Tx9ShZ7S54mf8Eb+x6ifemALrujz8DH5KXxLhOSXqN041EYzUcvci/x+DzCt14Jythrl0Ysa5CbxbdhPRPSmKsUR/G1wBv4GnwuHkaNGoiY9lVjI/4T/U7IyWYQShlIGu1HuFsCVKDGfIJccwzRLXYeSrkNdUopS3QjTcYe8HbXeA8l4cnvyruStycXwK8T9lgwi35JOlIgexKiGX+JvE3xINqIcXgn/v57EHOiDL4iH5JJSlIfTwi3CZmGPsF/4mfCWOASpfTc8jhz9R+RmHc5gNrwDX8A3RMa18aINEMPxDsWxN8FNtJk7BqOID/fxd3EmlWgPpGayFFu5E6m3HeX5GMrGGdQT18HP4AShxI0zmo39y9hOA9J5BtbeiSt4F+nGnDmotQvhzzhvExlKl2F/Kra0BbVWH47pd/ApUjupjWsQ6oU6Mg3b+gaugTnYQwU0kn24AgdxL70a6rh/QnrnEAuMJNnkGcRrRQk14Z5aJfyJUBiUuDo5lC7kjuEek8T8Tty9MuAK0o6jMOM8BsBJJkB5YhKO4V3C8XHya20Uj9K5ybXcisRN8Cv4Ka6Jyt8i1fFL+Hv479SRU6eoNSOuqB4+rGpoZXmsrHRISfHgokHRwoL8vEhuTjg7FAxk+TMzfF6P2+V02G1Wi9lkNOh1iiyJAs9RAoNGh+tbg/FIa5yPhMeMKWLp8EzMmHlZRms8iFn1P6wTD7Zq1YI/rKlizXl/V1NN1VQv1SSWYDVUFw0Kjg4H42/VhYM9ZPrEJozfVxduDsZPa/HxWnyzFjdiPBRChOBoz4K6YJy0BkfH629ZsGF0ax02t0+vGxUeNVdXNAj26fQY1WMs7g637SPuEUSLUPfoYfsoyEYcVNwXrhsd94br2AjiXO7omXPijRObRtdlhELNRYPiZNTs8Kw4hEfGzVGtCozSuomLo+KS1k1wIZsNbAzuG9S34d4eC8xqjRrmhOfMvK4pzs1sZn1Yo9hvXdx920nP90ls3Daqae3lpRnchtGehUGW3LBhbTDeN7Hp8tIQezc3YxuIS3PrWzfUY9f3IhEbJgexN3pPc1Oc3INdBtlM2KxS85sbHs1yWm8IxpXwyPCCDTe04tL4NsRh0q2hLp9P7U32g290cMOUpnAoXpMRbp5Zl7nPARsm3drtVYPeH5YUDdpnsaYIu89kTkcMxssjcy+VaTGtOos1TLpEWcJGFB6LDBEPzg7iSJrCOKeh7DV3KGyYPRSr4dNMECs+B1dkYVwZ1brBMozlM/y4kGsJBzd8DcgB4dNf/jBnZjpHzLV8DSzK+OQSq2H5xXg8Go0XFjIWkUbhmuIYR2jp8qJBt/TQinCbJYgAyQeNSNuZzcOKkfyhEFvgjT0qzMJEvGNiUyodhFkZXaAWR5vjtJWV9F0scU5lJR0XSy6ht4aRk/drp0HOuBy59M9scdlHLxgWJ67/pHhuqrxhcrhh4vSm4OgNrWnaNkz5QSpVPvRSWToWt49q4jJoOkYzOK0UmfK6S5VZoskQ53Pxn6gx9Zw4h0ypZZBgfdzSOib1btaFQv8hTo8kX4bUkzzDsDTwPVp6lPFh0R+mh/8g/YPRGTZwOF4+QhumTN+wQfeDsnpUQBs21IeD9RtaN8zsSXbMCgct4Q29dBfdtaFtdOvFBe1JHt6YEa+/txknsYAMQ2alMHJfmKybuE8l6yZPb+q1oBu6bkpTFyV0VOvI5n05WNbUGwRQtVzKclkmSwRZAhoI8nkXlbX6Gb0qQIdWymsZWnp2DwEtT76YR2B2D03lWVIdRbSOVLQ0Z/fwqRL1Ym0e8+RUXkeqdn66towlFlZyGFCng1aYepjSGDWl6XJ20GSsuQjZi8DM5CnheuFdtLg/UK9eo6x3rHftgG3iL5T3uPf0X3NKrpJvyDcWOApcy4XlyhpBluyS2213uwtoIZcrSPnCo8JW5Q3u53qhhkzA7XaSBUg/bn4UepJ93VZPTIM6I0IyXXV7injZpJpsMVPDDDOZYCZm1emJmXtIvpptK9Jx5q9M0+Ar0JrylWSSTGdep0TMUkAqkTiph97bnbFqsid6teVsS/v401dbWs61jD999jTUDJyNtrSfjDLIIi1DSqCFtLS0EEHkw0GwWiAUdLvcQiQSzhatFldZaQVfQwIjE299mfhdYh25jcSIcfec0sRvfc/e8vSvftl5yx6ace2Zz8km9AYWkUd2XB+vX3L3F4lvE198uQVnNyn5Gf8YPwLdXS9sVcd8Rk7J39i/cfK/oJ8J1OYVvApttkyzT3M1e7bSbeI2eauhR3mf/lb4nfK+4ZRwSvzMaNkl/4r+k/iq/LpBWC6vF++WOWsPXdal07sRqA5eclRJvtaMtgyaYQqB19dUq82czbv93Hic9Oma0zjPdpxo+6gmVVlomWeb51ro4UlLM5u9PWarKCsFpwPC2TmRXAebdHmMEWDShoHt/0ZiiTe+fDDxzQYS3LJo0SOPLFq0hWbfS8QNiV989W+JV+9O7v7J7t2d23fvRj5ZhVb2NpxuHhneCwXJPrXFqqsRRNHgFF2GGBeTY55YuI6Olkd76sKGIFdcMFlpLego2FHwjLhL2mk4IB4wxAuOF/QXmKCguKARC14q+LhALFB9mbEaTHdohYIU4iWf36WRQQoxMmTxksVqzcvIzIzk6QiIZkvEZlWnl7dayWIrQYLVq2ZfRsSfiXmLM0kr8gzm7c+NRPJIDynoAshjHGhWahhUK3DceVg1T63FUI0hJy+Wpw67Ilac93bex3mcOS+Q15HHQV4wryQvmcfnefP/VJ3muCXR1FM93nLaMlB9rqU9Wo2gvYUBqKmuqa62aD+2MsRqqwIMQ0rIkmh7Cy5I1B5y4oK43BXa2+W0hqyxPLYeohaNXIyuItzGvnlbSuqfum75U/n+xCl/3sThCwYnTmXVVNQuKEqc4iMP/HTK1KlTZlxXt22gmc74yeDqMRu3JCitf3z6oPq7Hx24gCy6MXETvxXXzAKZ8Jg6eKh9jJ3aYlyVscoey6jjxhrH2usy/pahTBOn6Zpt01zTPM2Z56S/ZchIZR9bAUFysBVw6fVoNrpDsq8ti2RZC0wmc8RiYcRV9W3QgT15/TUp1kSZrEbCWE5e5FCNEjXVSANGAGRS4zxxnm4hsuk8z8JMkfEpIwpjUxTRcHYkzxoilzHqRiKWvXhDL6GJC71NmyYkThHX/fNm3blm9vx1fGR745zEvyQGEucSH9ZPHfic6+1+7onuXU/tQH4NJD+jDwhPoHC+pRYEIUjCugLzMNM4U7NZ8jrBw7mc4LbZHcRtow7i4RRJJxk8PYSoZnB3uuNurhVBn5tz9xC+y0kYIbrBKUqMICaDXinWFQMUkxmop7CGmu/hIm7bVGeNY4djr4NrdXQ4NjuOO844BHBYHEFHiYN3eH0rOy8yUkO8cnJDfDiq5F5wJPuGNlePv4A8dLal2nLWexI8jGhIR6x6ElnIWmbGhxGROMNWhwvpU+kWkVqRvEi5NVxeVp5rpbf16fMy88Z5Zv34qtuq9ModdxAfH+lPTLkzmpnxUWHZxNFDHiFv97/7TGI9rlgtqq885A0HZJKne8GSPK/W66seVR4zbrHsFnbpjihHjD0+WXaQMfRKsV43IWu38aB40PcL3S8NH+hOGM5L3xiNmeZMp5rhjzlVkzVmdr7kfNvJOTVhy6rRoMmNkN6nGswmW6Op1URNHhvBgoPejBgps2lbgz+Y2iKyC1IwWpSCnkwNqmaTOdbJjCELDnuGzcYWgtfbPGwhcvQShEixMzTBREy+4qwZWYuzdmTxWeaQrBrNMdnrX5jiy+gP9orTaKuoDo+a76jxqFlmfGVY8JVprWHC3VwzgOW9YMNBYA0bGwxW0iDWY7DrYlVcH00haAiABSjyrNzNQLxb0Y3QkrWhmiiw+iejuJotWvcmFalkYp2aWPe4KbprQGu0uHogGkVVU02sZWzN26ElituYGA7ialsARYULMRaosDOFIYlu+i3xVHy+N/HnexYSx7uniU0cULk7Z46cnsetnHZddTUhk4ofe/LAA79Hpzqa+EXi2O0bx5Cbbls9atRSJOxaAK5SUxO71fytAlFMZLIwT1gucMW2JtMCU5uN1ylmQ8BANxmSBlpjmGCghh66Qi2QJAI6joq6fFAsSonSpvCKb7Vth43OsK227bUdt/E2C0QIp6kKSjtIJ4qL11rTSzIhpS/SmhQXp/1ci3c84/xqpjRQRKpKU1qjHRribhSWchSWfbrSoagyQiFrSmm4JU1lWkknagZh1I11rc3XXHnF8EnFfGTrjXXlXw+u3ZP4N5zjAwB8M87RBTtUj2R326fLC2S+hye4cVnq5Drz5xZBZBzlt0omo2jQ63FmlERcoAZzYnuBJLERn4fxoys7J7bZ0+mhbZ4zHvqVh3h0+ojBxLYao9GgcSyidBrIGQMxeN01qb0Dt47Lprokek7L0DYNtl1Uaxt5C2lnU/t+H7Bq+0UWdfLNiVM5E6vGLouyeW58t+WxCQGa9fzcoY13dyUCqAn3j1pw949QQKagXM8UDoMZdf5mtcjWLDZf0u3bpEeV84rSltWRRYdxMcMwZ8w7jqszjHPWeR9VFIem8vU+TcPpJZMZp6xzF5iMEU3Vm83g24T63xJCsWqqvswSqR5/eqD6U0gt3KWJMF2/UFx4ua4PhcqRi7NR09tw6Ziid3+v6fmZie9q900/lPgu8UrXncQ7YCuuu23murvnz1m7/dpmkoe8ayLeh6nlQtueqxY9+8yhJ5mevw/nO5mP4MJuV93XWOdbtwicInrFalptbaAN1lNUMrMJWXm9C3ROh0OniHZHxOkENieTS1teF0m6iOs/WV5FvrSuMjkjE/mH63r5oqY2wL9b1pbUxCOorEMp9V1RwaLc1cOOLbxxz1XEG5hUM2ZJIfHumDrr+j1baGfC0z93+ITlJ0nfdx/hNK/j9pH7cVkFGKG61gjfCFREEb1F4EDgCBHOUkAZk1U9O2Kn5A/i+FGpjWb8ANSMP13FTBHNDmm3c+UhJ/dAOSkdjE1az59PoLENBhSPVqSinmxTN+ZLv+TpNqmX/I68L50xosnv4z1ivlgJQ+UxpJn8mCyXdBESlSrIMKmejJO26c+L5yUll49IhboYP0w3ir9a9yovX6Wbwjfr5vA361aS23UP81ukw7r3+d/pLuiMHC9Jis7FB/lCXRlfo6vnFSfv1Q3TXa27UbeLP8S/oTvHKxJ6i902T4zvSZ7odroZ7FedBmuM8DqJR0+HARkUmeOw5GBBUSzJERZVza6cGBehioNSRRD1+nTxGT1hUdWNxfoICA4AQRQEVGGyouhB6KE3d4llCgJVL8+dYNxh7DdyRo5l0zI9y7adSW1FQShBd2yu4TXc0b3alu5he4t3PO4yWgyKUxyAr7XC4Gi0Pbr29tfWDvakY7gibmYduqv2icw/O6ALKiFtgl0IcR9oRsaJMlemfQlhrzJCQnZ7CN8cZyCrEw+Qa46+TsYltpH1iV0nPqJhyiV+R3ISysA7ZGziEKqCsSgag1HnhaGUtKsLJJ+cKfhdvnEZYzLH5v7W8rFVqfDWe6+JzPPOj6yJPOh9yLfT15vxC98vMwyiaHS6RK8rTyxwNntX0DV0p3hAfF00vBT70EL9OaVDrIOMOWp0cCxHzc7Hl9cfW5xzIYfm1PuZpJTgnn2Fn4Df4o/7/+bn/f5BpAxUzDVDAIc2NcT2vRDb90Kqxxdjhv4BXjIYdYPYLotlg9K7rQaxxiAmxKpDnzUkIhco+cbmgGGHgQYMJIlaFuU4ZvBNiJFYK67O/SWEkLKC0Aw3+dhNJrhnuBejGectS5sCKKi4Pu2nW5hBEE2lTjKJPY3kRonFvTd6tiV60lZVjJt7anW6iv2kvfl0KtELOcm+Q2j2TMmZk0Nbos0tiIECxpks1dXM0mW2fjvJ04x8l5NzuNwhtNPyNA1QHquoqKyoTKk8IoqS6GTWLmZVlJO5yeiv3z7a08Bl5Ca+0FskbswzLc8cm/b4gz+/qnFxwxRyfcUXOZVNdVeNLrPo6R8HP/Zw8/pDiZ5777kqs9Ir19d3rZt+X0NmbjBz4ujhiV/bSj151cOnlUYqc+YiVUqQGyzIDYX0FbVPtIphOc9tdYe32bY5tuY9UqhIjnoHtR0x9pp+EfokfN54LlssME41zjU+ot9q25Xda5Bqw2pOXWR+9pzIWttax5rsu3KUyshosV4/zjjBXB8amS1l5+RFKg3lofLs8nB5jiTqBKsS8hjzDNnZ2WEpJ1sdtNSw0nGr85aC5YXrnHcXPuZ8pHB/9v6wsYNsct/rebTwp4XxQaI75FJD4ZhLzQzEAi7yMarmMjnUmLspl+aqHn8s18eYQnWjI9c4iJQMIsWDyKCsUImFWMpICNLOXur4QadBVVGMMfBGV/YwDriAy6VxQFppR9tZCu2t05BaYLVcJEQkLhLJrgjVh6aQZvccstB9juiIm/K+UDbNtxsNNN83gyd8fb6+0Ud89XapZqAF/zGRvhha2jN6ITv5q+78QmTxFMxGEe/OymHp/u5ATirt9WlpNQMjNxpJRXZ99jbjw9mvZb+XLYayDUae97F5HECzGcqYAd3tLqohaQtTS2fnxhhU/ehOA24CKmkkfCvpIGcIB8SCqVbCazXtLqyJfs544MkM/gxP2RRcKjbtKnOr2K5bxUbdanllzM0k3K3mFuAL2zW7A5ow8e6pPhW3SbOPNPqSPpqefDsTG+1hxzAt7exAZkkqmSJGqrA5JSHt+LS0aHZzTvINVdHbasz5+EI6fHnQWGVwGKpYtMtQhRT6Yp++SrONCeJDe4s9V3OB0HJAuUKmQ6liDrWQsoedaFbw7HsHE7gS4rMtmn1zZa7DOTbx/LWrPvrko/fyE99YZzQtLglmRsjLzU1nv/pwgBRHJ03NzywOOh3WhhHTHt1w9P6NQ0aMDLjCWc7MeeMa1jz46zgqrrUoRQ+nzasnmItwXh2ir6rMuDKD2pgbnTK0vpHEcn64cbi9PGM032BssI/OeBhtL53BhJszXO5a2/V6MxpZadfaUkC5iJkZJgby9451ysj6d261dviDppaeudUpQ0tgTnW0DM0LJIot7VU77ZfbWmuJ986uVxKJgd5r96m22NhbW+66e/7cNcLhgTMPJ04l/pY4k/jo2ubttPDZCW07njv45BM4lIcAyPM4dQ4kWNELCjJbDcqXqjQqtEOJK33KceUrRQgorcpqpRMzBE6UQOA5tCNVOA79iNmC0xcFUeJ1VIoQXhPNUE6M98ppc+qiTcx+yELVnGBhO2hKqy6J2nFSBMNDxIt2sJc/SPjEhe/G8RHNSPp+hJN7QcC2C9j4hEaBdghxoU84LnwlCAGhVVgtdGKGgIPh0MrnIgQujgS8/L8bSbrvslS/wuFv65mdnZiIFhPbXIvJ1eqsFf61fmozGNuGrDF2DOGDJEzDXAkpo2WcSkbRUdy15mZHc+60gmno3t1oPm89b7cNN5a5hueXDWow1rka8usGnTEMuHX343amNxj1hQZjnsnldhYZDcjMnhySFn/cRpkQm6yaY9mtN6QgKhYNhnNTcEgs5TwrzgxtT5whMKYLmPMYMOmKGO/pnZLHKxYW6CNo+SLPKV6vz7dpCBmC6qFH1UFZTsjmLblk6Z9N2/rMiTl5kQMHzqaPxC5ujaANTuu8SzHENJf3oq1TVcWCJFuqLzu0NC40L3QszJ1fMC+6sFg7D3ILLvfFLbEcRTjt9LrL0XQ20XAQpd1+2QnRraRW9udPW1SZazeu6vvg9lmEvPTzDiKNaDuyKfGXP164q3X+/esWzL2rPm+oMyvkGhK+/vHnD2x6n+iJ74VHLlx59PAN1b33m+hdP33iyZ8828k4/drETfwsXFsr+OEJtdJWTWPGmKM6cxytM9Y5xmXKbQHil9EebRaaddcYp9mb3c2+af6dup2Z55Vzxm8cBiuYMhileb0zJeWS2SJ60HHKshUQAhGrVZNyZRPuWb5AisTnLjs7O/t3R2fR9vTh2UJhoW6efaF7oXeeH4lFrKJGICsjkItRiGg00WyKCm5s5TMzDizfQLi+Gx6vJlzizD1z5q2/e+bMBxM3UdeVk9ftwI0BSGD6tU98W8/tf3rHU/G9j7+I3LINzeIwCpJC/lk1KZwoezm3zNtkyuxs6LbpazjGZNe2xBhUCydPiXGlkuyQJJmTKZU4hUe7GxO8inV4Fcv5UvFtgSAXblS9qr5R36rn2vQdetqp79PToL5ET/Wykm6UQdU0eXJMKSXMzu5DMUXEbt2Q5SkLDkVTO4NtwQ3mXDqliarm5wCGtYMZU6KdfZEvOdxdFVNeTA7ii436EJoEssrsgvSmNEqr1XFQXy536Mu1iV3hGxyTJ+NL4FxcKadyfD13j7xZ7pS75JOc+Br3tvyRzAW5YjnGDZcnyA9yO+RObq8c516S9ZImf2XlMariS2Lbu7G4NEaD7CU5yjFnK+qcwTE6BV9a7fqsIKbwJVNJ8lDOLQ2iedJwWiZdTVXpOjpNQocmQxpPR0uPSc9Jv6If0s/oKelvVJ9H86Vx0kppnfQ8FVGwllw8qY5GoSW9DaNooQ5j6hNf20iQNhF74jcD+4TDF4q4d5EDjl6ow8WfiltcDXK/F/6gTmwyN9uaXQvMC20LXbd7bvVupVsNr1te9/zG8oHnc/Fz+XP7587zon2ofahznG2cq97TbFhokIbZKl2VHm6FsMK8VlhjXu/dbdvl6rUddCkmzZzPiDF4wOaImcqMLMebFdOg2RozHiY8KuVlqs2qBxWrgor1oGwzGvWHUXZ4LAq6JcJy0dorNrKIMXUAmCGFHD/4SsIO/KJnT0fZ56GWk9HU1yGEzClvR61OUp+DUuJSKaQPJ5gs8UMSfzbNnrDw9tU3Ns5zEkf07FufJ/5MXKdf+YR+WTp5ygN7jm2/dnHxz14huI8RieTuQsXxCLrR5zXrIANWqLmi0Ovo9XBXCmS+8IFAbdZco8kEGZZcSqgZZFfeXomwde9W9DH2aUt1Bfwl/lZ/m7/DL/gt5qDG/VTj/cwhky/xPnJ+u2a1ajw/UI2eCr5Tc2JLHHS7mPGDvkU47KXaWUMMHZDwI+S3xDRp1Z5ZW6++4Y2Xn9p7y6jrx5R3Coddod/vXduz0Ooc+A3/SqJ18KzaxgVGHXaMj/ASzkcCHantBSl5QlUqq2JiPr5S7J1fHhPVfI29T6iNoTwsw1cBFPKFQr6u2DAUKoUaww1wA53LzRMWyPN1n3HmcSKhskI4naLwkkJwlhI64pKo8HxQEB2CIMo61ecfoWNd6H3+mC4XNY/IKz3kqGoSJSrwPAHZ4HajVUxnqvoA0e4WdhCO9NAcVQkopETpUKhymOYgw8xUlSDqHq/++tkXT0W859A+RZ994OrRc+s+vXhaM/60VaMlqhPms6cddgQSmiBrX0srk/1KTFMbzJBtiOsnN8SztGN8Lpnoknnd4WQCKXVhn8gPZU8zsllKEEMhDn/oxXOc8FLiZx0DB29NvE6Hk6rCN18n4xPdKIcbaHCgH2VwEDJSr0b4JWq4WCnhS4RGpQ2ntFmRRCLQXJ6jEsgKUoBfzdQqKVJ1ooREgNWMYTBp5UyNtI120M2Up1554PnU1BsmNu2jKvvcgKykfW9AApxMM5JmZ7WgfigPOXEr+Tgxnr8vcTX/yvnz343AUS0la+njtBO1cakaYi4GJZUAnAU1YAnHc3VC6liEQyPq2ZtYdydbxls+bYHi0y1DSpjptpTmk7XMdMMxbkHeOopTdEIIzqt3VpnHmq+RbtDfYNij7DJ1hg+aTig6URZ1btmlqzDVm+rNaDgoaAE4zA5LhanCfKV5uelWy7s6/UplpfcW/zplnXeNX1RcDsVgNk02LTfdbXrY9LRJMAWNBofRaDAbnEa3K9ducZBWR6eDOhwQDDFRRKF0gmxizJUHRouRGt/LyOsU42KfeFzkxbVtYRIMl6BBF3JeLpHZQ2Z/L5Ha8fXpsy2nL7KSJpVowA6k9iTcj1pMt1teI9b0J0HtiJQJa6kmq5LL5baHuME0HLZav5fY8Ba6+M/vd7zycuvtN3QnfvLBkinXz6v+7fs3VE8Yk7P/lHB4wpt3PvubzKFrnkv8kdQ81xwa2M5dndM0cty1BgFH2Zw8JZwS3tXU0VPq1K3CVnmbYZuJl4lkks2SJ8+zUllhk1ZYVzrX8Ovl9YY1pnts6x3rnOvc6zxrfAbJhlu6z2nzOXwep0+yFxkVb5HEod7SEdBZdEEdp2NqK1jiV9Nqq9MvBv1n/NRvyesEwg57SrTN+97uzFWvXvpsP14jV/ulL9ikhX3jsMcq2dlIWfpjPRCH7ZKR1zyq9IX567tJHbknsSpxLNGbWEWGfLpv359+f+hQP32vf1tbV3RYYlHiscQTicVkE1nwt0Qymbxw/jtk23vRLdivuQWLNbeguzQWE9LGMoNqjcMdA4E5Ch1Cf8pDaBPOCHyHgBxOOUC750MCEGcuTB+72sCYgDk0PCzih+y4eKp0ucOQ2nKZy3AvyddcBgLjkp/yf8HlGESOq1f0Wnv8B/NfH8RLdsnptrudnuhcYW7+MnGlcVn+h4YPwoZm3VTT1Ozm8ALDPNv80ML8+YNW+Nf4t4QMtrB2hBCIMajO9fpiE7Mnhl/OfjnMt2e3h+/IviP8h+w/hMWortCYk50TrjLGwg069DKyR4VvMM4N32q8LXu9cUP2Tt0u4+5su6JTjGK2GPbqvEZXtpQd1hl54p7mUb3B2GIPWezZ4aGew3QuZCCpDL6qQAbJKHJwMEY7bxjrC8ZSpw2tZDPpJHHSR2Tyr7zqq7LwhC8qVDxfJd3ErdrdMXeDlBfxDQ7kdVriFmppIF9ZU+LkLfp1endrmNy0D1A9jWeyhPs3wugSdrtDO1w4mYJLoifZeYJGY+0AIRvpkeEfgfQ4noZ/6rKzc4N+BJh6o8vGUsdVs63KGLRV6bRgZnmfqSYD5hmrdB4W7FXRy5/m9IGQc5humJGdajXoxhpHZdeHd+p+mq2Dlub0pps6j0gJLfuxU76yIP+DAwlNztlVlHEk6NuxdtMDV1wV6/3X1rWrv/opcRC3lDhhv/32O8YWDxpK4m8vvzcJLyW+SHxAfp/5wLpbJ8bGZtgGD59264ttr877y5vG9tnl2VWx3OJ5Nx/buOp3N6JZROAIvxv93HeRzUepdhK0OWMkmJUTa+QIU9GU6yHNqoLxT8CCXI375iGyCDX1pz9OWUtnT7dYmDy2tCP7RqPsqPnIBjI8cZrfTaKJ95PJ1Cdj7OBpEJlloELqTe5CKf/s+zQMUa20P3gmSIPBCcF0TNvJ0S8M6vPHRCkJ9tJyKAB2nNPS3l6Oo78xMZEuwMYtUK+a8s27OGYhgGIBm3yMZIMCBN9AH1Z1yl8Njwf5Ep7yPXRLt/XZGz1RtPNOD5w9zcZfw25faB/KwxFabrFXVJZR6nTY3C469+VHO2dPu7tv/fwrysOJiafIXz4nIUL7jyXeSVzzr88kdj8+DwcyCgeiagMZq3ryaJ5uPp2v20p30d0mSZEtgP9sFjYkQPdIG9J++a/C4wY2GNsNo9hgTg+c/OFY7CM4dAO4MpfN6ZAoN3py3bDMeetf2rprZMPziYldPzv/8fJ/JT8lxb9JZJ1/56vE2cR3KBQP4wbJvuRZkLyr1bJ8tKeudM/l5xqEQneVe4wLzXKXUOWuyFib8aiwRS8ErLkEqN2Wa7bI3n9nWto7QiQYKgnRkNUWhKClBAWQ7WLBH9qVLZcMywFtE7vI36FStCnZ6EX2C6MDgQ76CIoMz7aph6n/UOsdPa1FlfPG3zXrmYF3Sf7vf1w5ZkZ19U2TRxwQDmdGXkmc+ucDd3XObigM8K9cKDfZpv18z56D82ym1LdZ0YsTNVCPqtdzETmiR2uCfcfpUJXMYTFdcNhw5hP2d6eh+kzmYMzFl6jIuj8pX+p4XtHp7DSTtygBXZgO4oNKMS7cAn6ucoNuBV3JP6Ps0R1QDuvOKd/qXDv4zcoO3evKG7rf0BP8B8qHulP0M/4T5QudcYWyUncXvZe/S7lXt5lKTfq59AZ+vrJAdwu9lZfqaANfpzTorpGvUZp0kkdXbIrRYXxMGa6rMUkcNfCiouic1Me7FSmtOgKUR0NXMEhSqWgylGr2EpUbZWNMz17aLE165ouiY6pXU97pdtXCInoZhZcnVNKBzAyLmmp2kpJSTS2k+LTlvdMsI6MnOVwtwl6CvKwopRzv4Die6nW6Uo5iFD1rjjOgR27QocUtyQF0lXqIsZvdAD9Mh2pbInrd2lboRlddKJVUabVM5GOrcRWO6YN6A6qLoaoN90DmzwPz56E0YCAG1oyReeWWs+2no1FL9b9aqn1ey0D7QHu1z2NBQxozLCfbcfDarahqHO0PLeu0FW2fjGpcTvbv0weZydyiPSm3FaLtmt9KQuzwDznvAXKE6NDlOpo4nfh94k+Jf0HD2cN99m09f+d3q1jQTJ+bxSyUYifkE7N6+xr/2tBj8Jhju2u7W1xpud29IrhGt8a0zrLOsT5DFv1Kri/D4XeEvLk3um8DeRmQZmkButO3+m7NujW4QVpvXe9bE3xUeky/xfpT6aDrddcHLmtlRpN1obRQdxvcKokcuQqug5uAz3Fl5+XluCTgRBrJLDJzeT30qgORCdlFCk27uLSHTFbN3HuKEokEvHm0YW8hsaWF1ZYyqArVwtbCtsKOws5CMVh4ppAW4q5pIOwWRomBMzCDquDvDSoU3JMD1qpiqEGP1zKQSF1BS5+8aSdums3ZkutyS9r3qIvXIsGKcp1bkTa1nOxuZGUkr9IlDLm54+ZRqunQ5r2JFxN3oH81ltSTVeX5icNVVf0HDvzhD8+rVdNbJj94+OrB7zjC0o9qyP1kAZlPNiXaE4/+bPMiddTPfpT47sIA2mLO4aGflrIzWrRJc1DYvbBBHSrJkiJZ0MJXrpSvVKRrlGmWLZat1m3Ox127LIdcv3F+Ip4T9UaDARWblGtXDPqg8W3GvXSjmq1mNGa0ZnBtGR0ZNJhRktGZ0ZfBZxA0zoLeEm+fl/My/ea77MxI02+pAyP2uU+z1DVbzR6y4g596au8xUTTV6seIvl6+6Yfr+rwkfySO068+OsPVzn8yG6fHhs6/eb5W17kohcSifMfbWme+fjUVedweuwE4AxOTw+b1StkgZfkXNEWEEiJsFeggqBwPPM4dEquHmRJbODoGB3oid4XNJYYVSNn5JXLXQzD5cpZu7+Eblv12epL6tnKfAzNBEIh7vJXoQx3dPk0sE8zZZqxknaGPqQEZcgZSodH+JoLn9P+gSBXJhw+nzjyTaL9Gxz9Ezj6Z4UXQYArVF+jxKxfnssVQOYFH+5blw9NHNJ7+dASbEzjB9LGb5l2c+UJkk/7hRe/G8uafpBdwEHCuKBLjZpJgFSxw3HLSDLS+i/kb0SRBJeQQ5usC6wCIdTusNrsnIMS7e6Gn5NQvTucOheAXheRFe3ShkKSClH+o0sb4Ii42BW01KUNJznjJM7/+NLGJdNdu7pZVWV1a19z5Yv3Fq2pWzg/uKNpJc+tOzZz+wR/4lRw4hX1i8oS6JANfLJjTNu6TQMP0CG7ppfXrV8z8CVOmoApMZGfxEfATmL7bfkCsbNtzGMwx2SX0RyT2EtkL8GFeUxPqAHfsJggirxRbxItFOwib8fF4NDUE+2tFmLpIXtVm95sLDblQ9BZ4mx1cmyOTI1kR2La1G2ZWTEnOyKo4lSPN8a0eQ/JUxWqpZgRiCkbqQI1syKWtsQdr6WvKEbHD3jxjf/ShyTRaPuS8ZazJ5mNWJzS58RWlfJn2dF+lWTSDvaZUcf2p4a4ZXJDfNjE6U1dvAUOJ88ASZ7Zx1mIdiqSZlo0v43WGrvF7sWXzVMjsBsfmGCwC9Optprt2tUHycSFUblqZ3UmNErPk3Bi/ajcUdesbpx4tXdk+azrvXxkwET/coH2tsy6Itv6O+PSZrSH2VHDLFwGOwRhEJxQa1YUkgWmlYWf8ufQcAg5FTF/UCjXZQs4JzhpiXOvkzqdjnB2rs0uBx3MqMrIaxM7RCo25OftZbteSlUzLayGSgargxsHtw5uG9wxePPgzsFycHDJYDrYkY16yF5ip3YmLUX/0MpKHRf8vSQ7UYT9VWwBUZKdP5Dky24Upw6ezNqVuCDbMdk9Wsaj2llC6vRPSJlpFw8TOGsonYiEt9BxLz63dvriGWs2tzx5y7jEJwkjyX/lhcKrrmkYN+idPcTWGR05Wb31TeGw/7pHZ8x/Ppp3dPWcY+1GmfKvJ14QlGuurJuqCAO9iZWKoeXqkdcVIo8XoqfwleaAXKmdt3ejC6JdxjEwN4T5KBbtsmyzqqNAPoFFFsaQdOYB6uWffi7lhQy0nL3MCSFh3O+/2pf4kgxnXsh/6oMMQo/8ex+kpJtSknXRy0iZYj3JT/dnZen1ajRDNZizAlk1WVyWXjcGGbuZuSB6VFHTtUtQGapTyPcVxyT2EtlLZi+OXUNCqH23DKJ8PsYTEY00WWfQo+hRG+dTfLpsKNL/Qm8A5GDV5Q/GdCDoHeDV50KhPgbD9GtBSZ8j6ojRoLWlV9wxHr0dIoIO3Qa08qqi2rFRBoo46Hg92m04HxHjShU7KFc9mfkxvTGg7Rq8EWXcoqvRTdDOY0pUPU+r9HwNP4Hn0MArQbnrUM0GnGIQHXWOeL+/tBT1jD/dctoy0OLVRFxLa3qQSbetCuW7SvtcH21hV1BTp5gkZHezKyzsLtKhxBSS98thbtFkeZOEEki9gT8eGO0qKqJZ332E6uQNAPJHJCn7ZjxYzeCGElEcyuuUvRylYoQEhRLcFffKbz2n+XDswnP1ufSZ0MVPvW+kPvVyRgYv/FU7PUx/6iVebDhHdaINq6MRdtiUupXl5effcvn1N23vY99u08jh5CnuLdQHNpiu5iyUdxnpFGWestC40LLQeptlvUXSjdHfYS6S0AGlYAsyZ3mjamtzkBIHcei/CuiIzmsfSNsVzPhqZ99FUzvIwNmTqRt/aK6iVcVuIOTlulKf3ulOkheM/rH3wy8IcQvBklmzJ6Et0XpwVsfjf/1zcFVsQnsXjs6DPuWnyOIu6FFLK3hSyActQWsz3+ERZP4lD3W6rNRhc1lNdjNYTHaC7rxDkc16MkOf1FM92zB1IrGaU5catf9BYUFqsXtrot2hU8pq5Anof3ByvqXYOsNKrez6utFkj1DHDOh09bmoCznsoGKIubzulb10YeqmbrQ9dUP9Qkv12RZv6p4uO9/EwC57VJWmb6izy0/2Mu0AJH071+ksc4ZxAcKe7VWPLl+5NDJqxBXlv/514tR2PtK45u7JOa9ZqiY2/P7CIW4s++tJqKyn4OKIxNQNHJGZRWOr0tykKShyffIH5AP6If+hIDCXbKWwlWyhj/LbhB2yzIFeLJaZ29cqryCSF1xiAUTEsXCleA0yIPJckICD7aDcpS8NqIBmqXoR0FZDD4lQ4TCdCTyzG2woQ2Q138F/zPfzPN9D9KpuNdfBfcz1o3uqfb+q0qMGO0z0QNk3BnbtzCtd9o0B5avlbAsK1elL/s/pH3o/33+d7Ou2pL5LHlCMsSno9rVcvCnT0sK2VGhBwSPsvEI/cJbUkqVoZg8b+Ktw+LtX+Su048XliV7yLGH/h77mgCLrRZ3UQ7LUDHE7GYqu4BISkXIuExHDJRE5OXCaCcnZAe1smnkK9pC2f+RVVFSG7yXewuXTK6eOoeuI943b7msLLsucNRXlIoLask7oQ4VlhI/VKkPQWKUYvIaoYbLhRsMfDeJpIxF5F5/L5xvHGK817jIeMr5uVAiVwSAaJUGnN0pgMBiNPeRF1ZdyWZkDjTYw5XUgqcY+43FMHCH56PtSsv8g8DwiQA9p2i9sQhHsIVS1WaQd0ksSJ/nMNXQ1pdRrOkyuImM0lj3Zzr7/aZ852FnMWeRVbQdln4g1wNaCv93yGjJu2lnXFxmuMIw3vGX4vUHQTvfQE8WVYF9ESJmVsTGxErpqYDf98ZcHDybOJPaSvHPc0xeu/ybxIc0iXyeQFZJPJSaSndp5sxM2quNdUkQKuiukg7LQ4SYcL4DTYbQYLMrfX4zhneIMNOzuV8zEEaEWgQi+Tez+InEbyyzsLrnL5T5Mb4QQvWEf2rHa6nnHn/Sk7s6nnZqWizdntP818oPrM0yjOq2OlE6qvOju3Ee85VuXF84cOsQRNkcrbak7NZu/++5Xu643m8/wQm7sTu5r5K8yXHADLrif1KgzDngO+noz3uR/4TnuOe497pNHZYzKHOWf5n2cf8Szh9+ZKYu+IOSLlb4x/CjPKO8on5zjyfHm+DhXhJ/Gr/Nsz9ieud2/J3OPX7axa6JB/xD/Lf67/Zv9H/hl7Q6py+GM+anFYPazz0rambvKviWgqNhcMXRCnuymxGDuIdPUcMBQbKAGFfMNO+2CcsLlIhNwyL6A+YRlBfVmvfvKxUNOds+iml1igZqBaPtJpFU0RSw0laKp62h+tLysVWwMXWYNqCZLFS9bqgTZitBa9cOzYb2S4c2gGXbC/hYFo7qtKsU5DRObjkFGsh8yMfiT/emPgeiFW0MVNu16i+ZwS7kVOWWl2lcgkRcl3nAhz9L55c+iw+Y2Ny2QE595ifz6h+evHF+WOHeliwiJ7x4mym/31Vwz9fq5N/wo87M3v3hxdves2rONEZTKaclTvAkXyYQke0htWKlbp9tF9kjsm9oh5ZeKPM3a7Gr2TQvMty5wLfDND8hVtEqsUCqMY+lYcbRSb9yl/Iq+Ib6mvGb8kP5WfE95z2i1eIIeqrlZuUhgz07ZGDAXm6mZkdu8EwT/iQk84X3ZjhN6b+gipU+nLrSwW7XtLKQcqRZS6nZZLVLqO3tlhRtnz/4zpmbSV1gtkQgtfX/lps0r3v8g8S2+yxpd/tiEshQQ+rbtT8xItB7cQsaSneQnB7d8Xjvl5gQ+L6u1U25i3urLtbjqTwFwEaSBAtNU5Ub6I7qRchT1d0H3DO0GyvWHZEUgYFDgCGlCmhHaohoF4AN8kI+jpvfqDpNdpBMuWuznLv7fPrTXtS93oZBVlMorcirLuEji1GPvLCK05CQf3jw6mfPGGhzAVpSUu9n1GVii1uDGIgq5UlAukV+SP5b5YnmzTGUZUicBCshSjTgBfYtJHGo56ktdhfnhMYDuHx0DtFR///Vf+87479z8rdzpgeF0zsB25uI/e37gAfb/fS89M8zVXwOqVvb8sXSg9XIop/KZiZ3CwLc0InG1Ftclt8Mc+PtnOG3CjfsXMJP/E0yS/LAK4Ua6BwL8UqilVbgkfliLeQ9gmILhPnIKrsMyA4axGEowby3We4iFdJ1rsb1tWDZVmAaPYBwwbxC2uRTjW8QqaMa692LZOMw7ovWzB27EMArLHxb3wAOsDsYfYviI+wSGB7GeieFjvUKGg0GP8Te0fpdCGOMeYVoyienlmI7QquRTCMswTMPwFLax9ftpo/MMNB9n9zsc3QmkwHmkHpcOpwAUdEp0fQD6XYD7HoDxtwDmzwHsxQCOQgz/BOAcCuB2AHicAD4bQMZ4gEw/gB/91qxBGG4FCGD7wT8BhG4ECL8JkBPFsA4g14rhMYDIXQD5vwEobAOITgAYZMSwAKBoPsDgk+gPNWDYCzAEnZzS6zEcwnAWoOxBgBgyRjm2WYFzqZwMMBTHVfU2wLB3cVmnsL/RqXHBcOSJlRSHg1xpgWKYhjzRYP1aS+Pk0Mu+yCs5cJFvKJpdOek4muraXxpjD4/xCek4+6thS9NxEfNXYU3CK5gzBkU5Faeo0L5IxznMP5+O8zCGqOm4AC6yLh0XMf8nQ8qrSspnzplTNDtWObsoNqdqXtHQsticovLymaVzZw0tn11aNmfS3PnLb5q55L9S9b9SZ9rcJUsXLl4UHDJ4yH+lOgyBcqhCOS+HmShTc6AIZkMMKvFdhHAOls3D2FDce2NaablWsxTmwizMLcd6pVg2ByZhznxYDjdh6ZL/tlb/u9qZhjnsr+4thMWwCDemITAYw39X6xz8p0+tAaZwe9mPloMfAtyL3AtQjfCFbtEf6Kg1cs/DXgzI1PgOYujEwIHKPd8tGUvVHoQ2hwa7XNHS3mQfRoaVaflFD5d2HOWegxlQhtnPdU1l2c91q3WlGiwbnoLFQzTYJaeKJUdpoNaHaMUYKJjTsQkYNmHYgeElDCIO6Dn4GEMSA8ft5p7qqg9gC89iQ+ZaB/csioiK77cxJDFwOPpncS7PwlfpHPRjuKe7FQPr/mkNK4N7GrHM+LZg6MCwF8PbGARYjO8dGJIYOIw9hWVPAeWe4p7ssgQstTruJ7AaA+UeAzNh/8W6j9vWbdFo82i32V6q1lq4R6ARA4U4Nx76MFBs9gFEewAN4z6uoatoiEbChm6dqdSC9TfioDfiQDZil534JlpaxcDqb+y2u1jzd3WZrRrej7pKYqlIt8VT2ohUWAmEm8stgjAu6SqEWQhnI2RLPYubg94JG6fabbaUdmB/NVi9hnNCARbXci7koQBXx/kgQ6u2vMuU6md5V35hKc54FOfRqpg5I7JhgJM5qas0EDzCqRrx13Ureja+dV0WZ+kx7h5OAgfW6sBa7oD5GKfDldVpM5nSrRhLN9cauCk4zSlIlgCOkSCVF2kNLerChmqt3GguEx3/AHcjbpdOhPVclgZ3cU9CPcInuiOZgb4j3EMa1oOsUex+RIq1RnQbTaV9tQrHLmvFuftxAe7XOt/cHRlaCrURLh9KMFCk8WqMrdaYfgPGNuCqbcCV2oArtQEHtYHt/dx6LGH/V7yYuw3auBWwGcMOjDO2cnYhQXu1SE5+aS/n5TxIGMsRJCXBXF+3YmIj83TZ7Fo1T7fBVFpzjFuKfL4U21S5Zd1uT+niI1yhNpVB3Z4MhtDWhex6jHOnlgYRXWxJjnGZSAhGGD+X1eUMxGsDmGaMHEDz7U16nBGJvkvfZ8vN/hKfBn+Vhm+l4T+nYLKPHk8JBf01g/21mfQTbGwG/T3swBilR+irqJgC9CPaw0ZBP6S9UIPwBKbnIOxFWIbwcFfol4Ee2tONAMf+eJfRxSZLX+2KFqcjgdx0xJ2RjthcpbW59BX6MmRiE79BmIPwZdoH2QhfQuhB2EeXwS8RHkCtNRzh/jR8jR5lLE4P0YOoBQO0u8vEhhDvkhjY2yUy8GIXpFKNxYGj9EX6HPiw6gtdER/m7u6O5ATMR7A9Qp+ly7r8AVutjj5JmshZrNQJJxgEG32qq5I1srnraDDQSzfTzaqnUs1Vi9SdXEluSVHJTi6YGywKVgZ3Bmst9H5UIDsoyi9a2xtRiwcpcg8GFcNmur6Lr4zXDuCc2LwodOC7U4u14rtNiwG+LZdKz2ixGnoPTMBAsY1VGFZj6MBwB+78m+ltGH6E4ccYbtdylmFYjmEFapM2xGhDjDbEaNMw2hCjDTHaEKNNw2jTel+OgWG0IkYrYrQiRquG0YoYrYjRihitGgYbbytitGoYjYjRiBiNiNGoYTQiRiNiNCJGo4bRiBiNiNGoYaiIoSKGihiqhqEihooYKmKoGoaKGCpiqBpGCWKUIEYJYpRoGCWIUYIYJYhRomGUIEYJYpRoGEHECCJGEDGCGkYQMYKIEUSMoIYRRIwgYgQ1DAtiWBDDghgWDcOCGBbEsCCGRcOwaOuzHAPD6EeMfsToR4x+DaMfMfoRox8x+jWMfsToR4x+umIfd7z254hyHFGOI8pxDeU4ohxHlOOIclxDOY4oxxHleHrqyzRiUGSbVRhWY+jAwHD7ELcPcfsQt0/D7dPYazkGhhtHjDhixBEjrmHEESOOGHHEiGsYccSII0Zcw+hEjE7E6ESMTg2jEzE6EaMTMTo1jE6NcZdjYBj/50z5f7w09A7SJONeSztIgQZXw5caXAUnNHg77NPgj2GnBn8Ed2rwNqjU4AqIaBDb0+AyCMikK1BprnWhCpiAYQaGxRh2YGBG0ksYJC32NoaPMSRpuZrNm6UJ0g5pr/SSJOyV+iVqRr91h7hXfEkU9or9Ig3WZlCjpkfZ15RN2ns1vr/CgJsIvmu0WA2NYb8x1LPl+IvRmGo9HfyqkLxdSF4qJHsLyaZCUqvQKwmvabogVFIcOGlSDZERgRMYKiN5I1Az3X/wS3egK1IR6CFHU6BAjSL8EsM+DDsx3ImhEkMphiIMuRgCWl4h1m9Ss9NNHsWQhyGEIci6AJcLjUebVVZ7qZHs7P65Edj18668fMQ70pVXgqCnK28CgkNdebMCtQo5CHnMKiIHcOWeQ7i3K3ASi19Igee7AkcQ7O4KxBC0dOUNRnBtV95bgVojmYp+MkOdkoaTcd4MTuoKTMNqE7sCBQiiXXkRVrsQO8rF0gLSBCcR5qaxclI9hbsCwxFkdwWqWG0Z8tjCExGKtOEJGBjkunFAX/WSJp6o+sDpwEOBLxH9z0hYZI8Pgz08grdz2fGaLnC06CdYuTbQVatj9XF/2JeGcQYPBHbmrg88jm2R3IOBRwODA/cX9ciYfR+Oe73WRVfgzmAPfU61BzoCJYFlRScDSwPjAjMDkwItuZjfFbgucJQNE5pJE33uYKARGxyLs8jtClyZ26MNsT5wa0AN5AWqgkcZfWFoqt3KoqOMAlCa6n0Q0rcwt4fx+NTKHmJVC6Uz0mbpWmmkNFwKS9lSluSXHLJNtsgm2SDrZFkWZV6mMsgO9rEyynxXh8g+mYDIszevxS2UvZmri64qJTKFcRC3cw20YfJI0hDvmw0Ns4Lxc5PDPUQ3cXpcCI8kcVsDNEwZGR8abeiRkpPildGGuNR4bdM+Qu5vxtw4XddDYEpTD0myrHsy2J+G3EfgnvsyeoEQ7z33NTeDx3VLjafGNsJaVV/3D16t6fdll1Y9l0f98S0Nk5vie/zN8VIWSfqbG+J3sD8c2UvN1Di6rpeaGGhu6uXbqHn0JJbPt9U1Y7WTWjXkZhNWgzwGsJo8EoKsGuqTkawarlGqXgTRsV6IAaynM0JEqxfRGbV6PGH19p0Ijq7bFwxqdXIBTmh1TuTCZXWQYxC3bl8kotUKB0kTq0WawkFtYAVaQ4EAVikKaFUI2nVaQwGidRYv/r5KbrpK+aUq5VpfHPm+TiBVx5F/sY4jH+tE/y+fuSOjpHvI8lWvsr/F2RoePRdDa3zjLQs88Y5ZweC+VcvTf6Qz0jpr9gIGZ86NLw/PrYuvCtcF9w159R8Uv8qKh4Tr9sGro6c07XtVnVvXNUQdMjo8s665u6a6qfYHfa2/1FdT9T9orJo11sT6qqn9B8W1rLiG9VXL+qplfdWoNVpfoxcyvm9s2ifDSHabQ4PdVK9DHm7NCDWPdFnaRjCG7h0e8qzKOMwD2Q36aHPcEB4ZN2JgRUW1RbWsCOWMFZnYH1xNF3lWDQ9lHCa700UWzLaGR8JF0gKrxP4mUEM8NHl6E2OVuDrzH6/ZUvZoxR4YvbAO/2F6mRbwd3lNWPoPn2X/6Fm+fPlS9loeXQrQEC+c3BCvYNcxJAm7aq1rxrzBF/M4Tsvbpyije5J9WBjFQZBlrDsWixJ2j11lf11fop1ip0SZq7Cs2+cvXXwMd/DVGNCPoyu6ijX3ma7ozs5l/suy7uLyFER3lcEuX6iUfSGpRFQGc1NQtRZhZHPu5qLNlZ25nUWdlSL7xrsTMwM72VbaVbyTg2XRpRcJgdFlzZC6Xo/9PdmV6dc67mSRaLQ5ulS7DXBpOb5/SBp+T9il6VaXas0vi6YXJJW/NN0IrkSq9+UX0ZankbTC5RpSqpFU6tLr+2fZctYUoydq6f8PQej5kw0KZW5kc3RyZWFtDWVuZG9iag0zNyAwIG9iag08PC9Bc2NlbnQgNzI4L0F2Z1dpZHRoIDI3Ny9DSURTZXQgMzUgMCBSL0NhcEhlaWdodCAxNDY2L0Rlc2NlbnQgLTIxMC9GbGFncyAzMi9Gb250QkJveFswLjAgLTIxMS4wIDEwMDAuMCA5MDYuMF0vRm9udEZpbGUyIDM2IDAgUi9Gb250TmFtZS9ZSUNHR0wrQXJpYWwvSXRhbGljQW5nbGUgMC9MZWFkaW5nIDEwODgvTWF4V2lkdGggMjc3L01pc3NpbmdXaWR0aCAyNzcvU3RlbUggMC9TdGVtViA4MC9UeXBlL0ZvbnREZXNjcmlwdG9yL1hIZWlnaHQgMD4+DWVuZG9iag0zOCAwIG9iag08PC9CYXNlRm9udC9ZSUNHR0wrQXJpYWwvQ0lEU3lzdGVtSW5mbzw8L09yZGVyaW5nKElkZW50aXR5KS9SZWdpc3RyeShBZG9iZSkvU3VwcGxlbWVudCAwPj4vQ0lEVG9HSURNYXAvSWRlbnRpdHkvRFcgMTAwMC9Gb250RGVzY3JpcHRvciAzNyAwIFIvU3VidHlwZS9DSURGb250VHlwZTIvVHlwZS9Gb250L1dbMVs3MjIuMF0yWzYxMC4wXTNbODg5LjBdNFs2MTAuMF01WzMzMy4wXTZbNTU2LjBdN1syNzcuMF04WzM4OS4wXTlbNjEwLjBdMTBbNjEwLjBdMTFbNjEwLjBdMTJbMjM3LjBdMTNbNTU2LjBdMTRbNTU2LjBdMTVbNTU2LjBdMTZbNjEwLjBdMTdbMjc3LjBdMThbMjc3LjBdMTlbNjEwLjBdMjBbNjEwLjBdMjFbNzIyLjBdMjJbNTU2LjBdMjNbNjY2LjBdMjRbNzIyLjBdMjVbNjEwLjBdMjZbMzMzLjBdMjdbNzIyLjBdMjhbNzc3LjBdMjlbMjc3LjBdMzBbNjY2LjBdMzJbNTU2LjBdMzNbMzMzLjBdMzRbMzMzLjBdMzVbNzIyLjBdMzZbODMzLjBdMzdbNzc3LjBdMzhbNzIyLjBdMzlbNjY2LjBdNDBbNjEwLjBdNDFbNjEwLjBdNDJbNTU2LjBdNDNbNzIyLjBdNDVbNTU2LjBdNDZbNTU2LjBdNDdbMzMzLjBdNDhbMjc3LjBdNDlbNTU2LjBdNTBbMzMzLjBdNTFbNjY2LjBdNTJbMjc3LjBdNTNbNTU2LjBdNTRbMjc3LjBdNTVbNTU2LjBdNTZbNTU2LjBdNTdbNTU2LjBdNThbNjEwLjBdXT4+DWVuZG9iag0zOSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDExPj5zdHJlYW0NCnhe+///AQAF3gLfDQplbmRzdHJlYW0NZW5kb2JqDTQwIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTY3MDkvTGVuZ3RoMSAyNjMyOD4+c3RyZWFtDQp4Xu28eXhbxbk4PHPO0TlaraN9tXRkSbZkyfsWOSI6jpcktkNMVjvB2I6TkEDASxbWELcQQhxKzFIolJLQNkALvZEVJygsxXADhUIgvaUUuIWkvSkFituUG/j1lsT63hnJIbm/fvfpH/eP73uenuOZ952Z98x23nmXmWMhjBDSoRHEoo5FS8oqbQOdWxFCv4HQ239N36CL8cgI4ThCzO39WzdL+WuYXyPEHkVIvG3d4JXXXNPlWoKQeT5C6q4rN96w7grTXT9CyPNDhKo/Xb+2b01k67znEFoyBvXVrocM4e5zZyD9KqQD66/ZfH0DZl6E9GeQbt840N+HGOM8hJbOgnTHNX3XDwrzHNDe0jsgLV3bd83aDz+NT0H6CejPzYMDmzZDv+FaESDlg8NrBw9W3nM3pJsQ0t+LWLYGjyEFUioeUlTBKIJZyO5D6xgjVjAMzyo4BcNyJ1FpZhJdvwpqUZH6li5slJCMpMxZxZ3TLbhK8OFnZYQzmQw8fZ+inbSGLBCzueCm84jQp5ACDKcRh96EdCHQcYiHuBRVo8WoD/WjtehKtAFdhTaia9AAGkab0Ga0FV1H6v6H6f6Rq/AfupVIg/KgzyokIgZ6zyEt0iMjMiABZo4H3lBDXf8czf93R4MUd0FoR14IbvY+5EIo81sIpyB8PN0KPHw18k9flTnJmoD4J7mAUBDdj/aiADqNK9BLaBK1osdQA+pA96F56C10AFq+Ab8ObfpRE3oCBbEX+tCCbFiBHkTvocth1L9HJ1EItaEPsRHqaUaDyIpimU8gbkN3ZI4AlRo1on9Bz+CNeAkqA3w+E8URaHkPLDcbCmWOZd6F1PfQ73EgM47mA/YRjK4IbUd3wzivQj/PnIWeBtBq9Di+GX+CfKgX7eaqudHM1Wg2OoR+hdsAW4huULyrOgRv4270A2zDk5kTmT+gn3IY3tN29E10B/Q4hSaZUrZRsQ/eYyG6BF0K73Etugm9h024gpUzRZm5mQch93H0ORNhXmEF6EcELUA96FvoUZiNd9Ap9AXW4Br8Pfwk3L/Af1K8C31rQ1vQjSA/vwez9zh6Ch3BFbiCsTE2mC0bCqNlULYH7Yf2D6LjuA134Un8IrtfUT6dyJgzlswfgGeKUSf0cC96Edo4g8uBBlpgC9jNnIfbrKg89w0Y4Rr0MDqOfgH9+BDm/Qv0V1wM92+ZW5jtmRWZJzK/h74okRfNQpehlcCTwI3o+/BWX0JH0V/wV4wKKN/iXlbcqDiduQfmthDNhb4vAuolUPdueEsplIb7HRilAUswiln4UrwYX4n34PtxGr+H32N4xscMMZ+ySfZ19jdcrUKRqYearMgD7frRCrQe3sAtMNv3wHifQC+j17AFF+ISGNE78PyXzGymCe4fMG8xH7I72D3cWcXt0yen/zj9VWYUOLoJ+K4TZvPHMAt/xlboQxhfhTfh/4CejzETbB4rsn62hm1gl7Jd7B3sfeyr7JvcMPck975igaJP8aTQN33t9C8ybZnbYC4wrA8PcFIU1mwd8M864KaroX+DcA+jm9E30Ci6C/jlHrQPPQnjfgG9hn6FPkCfwRtA2Ad93gCtXwNctwPfBfeD+Cn8In4Zv4Z/i78kN1MAd4ipZRJMI9PCXMnsgPs+5jjzDvMx62b72e3sCNyPsIfZ9zjEcVxGUQn3fMVuxeP860JImC+sVr5xdupc8bmucx9Oo2nn9Krp+6dfnP5DZnnmBuh/EJWAxLkZ7YRePgg8uB/uHwMnHkavoDfQr2lfP8cMVgDH27EfuCEKby2B5+EFcC/El8G9DO4VeCXcfXg1Xg/3djyCv4lvxbfhb+Fv0/s7MLb9+Ef4MNxP42fg/hU+gT/Cn+LPGWBihgVuDjJFTBkTg5E2MvOYRcxiuK9kBuAeZIaZrfCGHmcOMkeYd1gTG2RL2D52iH2Q/Rf2JfZt9r84hotyZVycW85dyd3KvcX9gnuX+0rhVTQr1iseUbzEu/hqfhl/Ff8d/gD/MX9W4IUOYbVws/C2kFEGQVr9DMZ96CL5Wca/hTcpzNz1zAlYF3Z2ULETL4MZ45ml7Eb2LvbfFOvwaVbC7+NRdgN7deYHbAvzV3YAL2dewAWsV1HPrkN3ogx+kvktc4b5A2fBS5lPcIi7Gz/NDLCNDE/l6i85C3er4mOwNX6N6plteJJ5mb2VvTXzPKpXPIJPKB5hfoEk7iRjQidgVe9kHoCH3mQ2MLtRJ1et+AptgHn/keJ6mO85zB24mH2bewT9nvUz/4lP4/tBahzDrVyAuYKJ4SdB4p7DHjSFh9Ag/jaS8bP4A7AiMH6CfRy3M1p4W0lGh+vAuDjG+vDbrBp1kT7iQsaCO5jTzDL2Of442DsYpMS/oRsxi8uBd2auaXQtrID7mCKQac0gTX6JK5EdPQDy/sz0c0RiK95V7AY+e5SNgoYrR93M66ge1sbv4e5Et6NK9Azw4B2onPkOujkzgteA3F8I8pNBaXwVKsMakJY26Nt20BdWpgBkYQ+0+leQ/z8Hqd+G/4SuwxKsrEkU4kjJnVwzSKZekL+74V6DuiH1MLqHP6T4JVqEbaCipelHgMt/g64AnfMf0L4TxaF/K9GjXBR6LYFkHoInHp6eD3aaDD18HTNoG/R5DqzzDm4+SN77M1fBCDeAjmoHnfga2pB5ADXCu1ucuTWzG/VkHs1cDlp8SeYJkL9bMylUi3YqupjlighXDTL2NXwU9NG/490gt+ej90EeBbEd7LtPQVIiNEfxLBrlfg2yM5G5M/MrsAVDqABmaDVo0VNgE/wJ5m0+O4mqpi9lxjMt7CBoqBPosszjGS9Wo/WZjSB5n0P7BQXInhHkUewH3t3NrWPKob9hZMVlkHu5Yi/7a/Yv3CD65/XP65/XP69/Xv+8/nn9/++ywm0De8sOVowLfNgwWBzF4JkQ+74MbJtqsD3qwHOLgf0yG+ycS8CKmQt2TwtYE+1gZy2Cewncy8DH6gLP+3Kwl7rBMuoBH3YN3YtYD3bDBvBvrgXPbwh8P+L9XQf20C1gkY2Ar/NNsJB2wj0K3uxd4PffD5bRA2A/7QMf8QdgrT0FVs5B8CzS6Aj6KfhCL1K/8WXwNH4GFtzP0etgi72B3gT/89/QL8H3eB/9O9hmH6ITYF2dBPvsI3nFjs2bhocGB669ZuPVV21Yf+W6tau7ly1ddKmcmHNJfHZ9bFZdbU11VWVFeVlpSTRSHA4VFQYD/gKf5PXku11Oh91mNZuMBlGfp9Nq1CqlwCs4lsEo2uxv6ZWShb1JrtA/f34JSfv7IKPvgozepARZLRfTJKVeSiZdTCkD5br/RilnKeXzlFiU4iheEpWa/VLyWJNfSuOVl3UC/q0mf5eUnKL4QoqPUVwHuM8HD0jN9vVNUhL3Ss3Jlq3rR5t7m6C6cY260d+4Vl0SReNqDaAawJI2/+A4ts3BFGFszfXjDFLqoFNJp7+pOenwN5EeJNlgc9+aZMdlnc1NLp+vqySaxI39/tVJ5J+b1EcoCWqkzST5xqRAm5E2kNGg3dJ4dHL0zrSIVvdGtGv8a/ou70yyfV2kDUME2m1K2m48Zf86CZUbGzt3XljqYkeb7Rskkhwd3Skl913WeWGpj8RdXVBHkgm29I62QMN3whS2LZGgLWZHV2cS74AGJTIOMqbs6Nb6m0lO71VSUuWf618/elUvvBjnaBItvsGXcjrlI5mTyNksjS7t9PuSCZe/q6/JPW5Go4tvOOiQJcfFJSXRcdGQndbxPH0O0eouRNaeL6MYJSdY2+Lz84pJj/wLgB2SUr8EPen0w5hmkWjtLDTaPwvI4OrC8FRyDbyPDUlVY++oWA/5Ink+qQiKfmn0CwTv3z/12cU5fbkcPih+gQhKuOQ8o0H5DJ6MRJLFxYRBhEZ4o9DHOTRdUxLdmmaS/kFRAgDThzpgbvu66stg8n0+8np3p2W0GhLJkcs6s2kJrXalkFwW6UoyvaRkcqbEsoyUjMyUnH+81w98PEE3tC1JZeH5P71oNTWvr09i6/9QvDZb3rbE33bZyk6pebQ3N7dtSy9KZctnnS/LYThbABOe5IIwUwv8wHqLV3aSDPhTBFv8zRt658NSgz4mTY2drIvpymKMi6VVAf9efr5mkujUkrq4IE/5f01aUAID0xwstSTF3vnZuEvt8/2DD6Uzp8lTFHz9WG5MyfrIxenZF6Uv6p52lIUOc4VM29KVo6Pqi8paQFiNjrb4pZbR3tG+dGZktV8S/aNH2E62c3SwuXfm9aczz+x2JVvu7IJBrMf1JVE/KRkdXTOO2ODSzqTsGscUqWvc3ZVcFOnyJ1dH/D5/51poZLweaX1LexsBY9DccT++47JxGd+xZGXnEREh6Y6lnSkGM429c7vGA1DWeURCSKa5DMklmSQhkQS4+bCWUoyS0ruOyAiN0FKOZtB0fxojmqecycOoP81k88RsQ4W0IRkxUMJlS+QZag7ylNm8kSx1KEethBKRlDyDQGsgWpi9xiGxtFNW18n18mx5DpNgYEZIVgpyngHa2RgdnIMT2DUOdS6m2Wk8Mj5bdh2hNS3OUY4AJckbOZ8HPSdkF1QE7WUHvuzrESxb2XlwDoL6aQwUc8lF5CV04sKVQMULWQVUlvaDAlsHkCzhXj+san/rOHNphEJM4Wirv3kNUJAAGqIGeuWT1nQRKj/hDvKG/1+J8AVERO7RykfF2TMpnEtBAv5Gk1denFx/PtlCAijUYGl2gQA/U970Ja9yJTd2Rc6T9CVHVkujwMT1hJPr6cPzSOiFhT0vOdLfR9Y4LPp+P2S0QobUudrl64IKiV4ZJWq+vw8e4wrPt5S8NnJRlcD8eCk0zQTJcJIjHVJvl9QLiwVf1gkLVUoqAErrQNf7+8gC6ciOpwNkFYC+0SXwLIIX0eVKCiCx1vWt9ZPlnSQvNjv7WdnUmkRLOpPINTrqH01i6GKwBYih+sIkX7iAAPgbjPj71hIzZB2xQtZmNSR0l84Oqc3V7Pd1AQkTpHMJEwcctZpE/aPEyOnujcBMGEaNo1JsFDi7GxYlV9i/vBcWsCRKLRJ91X0uSMEkLCCpLqgoS6gKEkJ4nv4VJq+JjHcLwa9z6N9AJEuspLVSnZfsmCER6B8gQ5EkY5sFhWTwmMjjrHQmk6cILoDplYGrXORpKckszUnK7PMLyKOumReWfQxy6NKk6hRkTxDf0XHhkr88aWpbvMoFE1tC7GcG+RFSrFe0oxCqZhYmd0Q65VTArtczy4JaEu8swMYdhS/7Xy5hFwQeL2HsXlvpugCrwqpgYXAe6sQDzEDgJnwTs8m7SdpacH1wFO+UvlPyJH4y+HThcyWZgIWXbsN3Bm4reiiwH/+QeSxwoOSFknfL/1ySKdEZkRU7GWPIWe6sqC+tL18X2FCmLlYybje2eF16XwEKhlxI6XXl+fxWr8vt88tMNBgIFDDYzDA48BSIR6E4vF9IZyZlG+muIAodQq/Ajgn7BEZArqfc1Wl8t6yvDOXnuxl9Xh7GSGn0AX2qs4YAuXlRDfId8DGLfPt8jO+QWIvl2sHa47VsbbWSN5mYZUo6D0qtTgdxgdWiFUVmmYVmWpwk0/JITd8R7ED2yKXimUgkEl94jsRi9/CZ7qFIpLHzCCpjSz5xUTDVhRJxEW6Ip6bEKWOse7gscg4yHE5xamdeqT2yTTyKjTGnPRIRp7A4GdkpKrYdrSi3N94gu0sqPH5vsMRfVoUrPBCVFkSrkD9QLlVWYRQR4xEMTX/jG3h4qBtBAG17BAUzJ1PaGAadmjLHQunMycPmGCM6CHr6kBgrF/UxRJ+LoEgX7o5EXKlAlEsLn8iqjdGo3o2VMInC2dRGd2Va+BMAV5r93eGNbiak1YuApjbqlcieiFRWJqCOhMEYK4tUllcAC2LeX1BYZDDbrFVVFl9NVSV4KobqokK/v8ZXabVazLyArVYbrrRWVYIPU+gvEBTrp++frqmSdB7RXdhec+7ZquVBi7toYRX+07vH9vzgSWzvHR04e4nJrXrp5b231vczNzIYT28d8UaDwVnezexGgiV+tGVbunD6pts7tcx9+Ilvbt9rAk5vz5xil7BJZEb57ATh9HGGqq+Q0mq2IBgLswzlUZBHX3aepRyUqITK4Vl6TAzsMmEyAxXhG4PBABjSuIIGAQHbMYQJJ8jTBDlE6AQunXmHPgHIz582GgGp0GhQYioSORqJdCemyFRFuru7pzDADyKTZccmK8pd4zztV75lBLzIJGJJF2TyMQTpRLZFJWX5gCjyy0RBEpICi4DtR4DrOeEe7vtcimNJUwIMLZ05IxfqdPwys9nrgXESFEar5+loAeRZSVZentdDXx30IzJJsWPHj0Ffu492d0cqaV+hp8egf7LD2GPvdvSiXvM7rMIhuWM2CFbZHfOSXqkbW6uV3kZddy1JHgyFqmn2kuLSahfvUHWarrD22FbaVzkFzKp4QaXUKiwL+F3MnfxO7ai4I/8HzJP2Q6a3mff074tnmP9kTcZeoVc5CKPbpXpReFV/WlByWNDdxrCqZ8CT4TMn5dZaVQszT7XIu5RZqlrNDDO7TLscD5p+qPqhOq08pEqqf8b8gTmpPaM2K48LGAnHBWaIQDJ3RFQkBV7YxplRudVCumoyxow9lu2WvZYTFs5icf2Sw/AGj8PyAfBxykTAu/J8Y4zM8eUuTN6I8IbSGnLF9FY8YN1u3WNlrWfM5hElLleOKZly5R7lCSUrKmUljESZVJ5U8sof51k4tIvwFRuVjeV5cl5HHovyxDwpjz2dh/NIT1Qwl3mNnsa2rHAZGh5eeG4oLp7rHuoGMAXyRZyCdzRMWCoybIBX1NiZGrDg7q5IHITKme7uoeFYRTnuRrNmoaFu3Ng5wSPMMENdQ8OR7IWGqZQQoDWNP6aVS2I6CEoiIkMxIQt4AlzZlCtblkupsyl1NqWiKTlPFbOAgHFIhpgOAoqAeEGRCy5QUK5DgqAxWFBa+P2hjRaLxuBKC3+c2GgQNFxa6U1thHUCMiURIYxIuBEEiom3EUFRZ+NBrjA11caqSqsl6CssKgTJwb+P16zZuXJHidfy8+/s/+NfDj/0yrmd+AmF6OivXXIrM/uNzZv7rzfv+i3G7/0RC6//uL4zMEv+BqyqS6Zb2H9nD6DZaAHqYs9RFfhNo7XjgcIHa1lUIq5ithZvXcKgYr6UX7xb4hJ1i1YN1G0pHFy1h9ujuNV2m31PzeicW5v3tN2+6Nu2b9sfXJTmjigmbBP216pfa5tcdXzVyVWnV7mckqVKrDHXelcpHle21iZcyMrW+lpdyNH49d6MymQyq5QjQWwMpjMfThhBdATJGjJrEwTKGqMmsTd4IPhCkA2m8SOHOiMjPgxq7ENZR2iNe0GTveBjfblnKIRHfEAr28dacasMua0yZLVGiThq7TBjcxorZdOAEm9XAmKAapQ1/IONuDHNVshaR6u6zIE7HCMOxvE882+IRyp2IYpDkZoXHJfhy0BDLPwpWw4iygNxDC1ky2WvWI4HyveU7y1ny+1EJJZriaQqr4mVsiNL8VIyNh3oT0B+PiGaKfLhBCEB5LSs1oFUWhr0hnCIDNpqc1bvCeFFocHQZOh4iAvlEUooOjNBlDAgf5KNRCmHtkirylfJq/bBnCtWkUfdGm31qrw997fgFpE81FIhWbHeOmh9C9ZnOvO5bCDPWbVElltpH61p5nnZ9GACJyrK2Q6W6WAxYkWWYclUOvKrKYRaWdI8MQ8I8jQZI7th5apn8PXIh9Xju0B5f0kYHZbf1PA5ikxFhk+JkaEvaSIyTBZsZEg8BRZD9zAYArl1fO4jsqoT4tQwLHdQDMMioQdiWNgTb/lO+BhY2sNnpkBNR0hO8EQQcoaJRWEw2mKwUkjABMJfRTkYDTe2rahvDtS48212rCgMVlZUVVRXsHxD4aLC0mBx4fLgUjd2z/a4UVvNQgnNxQkJXaJIuFFHyUI3WhxZKuEme4sbLyta4cbLV+TXu4DcNRu1V7RKuK21phZcSAmczTlc3I0vLbvMjZaEL5NQs63RjeiiB6uEdG8mypoaM1cxWCvkwsPdRD4NUWkkq0tF4NEa0RgrBYYYNxIREulyjSvNaeFLObgRWBUYtkeJFylxQonLlNirxHolNrJKXq5tjSKXozEtnDi00eFo5eMU44XLonoQKVVZkUKnxyke67miO3dFQMLgwsKa6tqqShtIFhvYJwJIGj+xU/wFRTxvMUMmuWkJZAFxXS3c9ClcAAS2rCVTVIj5C1OQrlm68ti+W3tfiuSxvILVR66bdXR/07yo11fuHnzzku6Bqx7+6sUdbRpDjdBTHYlhS+uapuqO9tXNVdN/LSuvX/P8xJNV1Q/9Fl8avrfrjqOyglfZnGoFP39w5LC5MGY2SALHKlS6wcVD/fesqKy124NzVf3eCq//Cmbn1hsfWTF3+Ma9K+ee/UZVZ7A8MGf7/GqrleNB95DPTwXFXUiDCpiBr42iIygAyyefmEFGnZIAnc9O1oqP+gY+k51VwbqjKwCQkxOEREXMHVIMyJuHCbVKZ59ZJ4D8jlLZCTmhAuSdQ4TKLoEVKdsW+QZ820F4FQwAN/XymJcJFVE9T5MK+ALehMoS78BSONYtfpC1mSKRY9lYPPoKcFoE7GQcmTGgdJKRLGkfjUk9E21tOaShIYvIjro6fpnMY8Tv4xnSKEKSr0AwkeF9KbvJkypVwK9jCKZjiL2koyYUGdlpKrMA+XKCFJCcp0mZ3R7wZ22pyDEIWWMK+v7BscSxbqp4STcjYEiNBXBvYDAwFtgXOB1QSIGOACOTKEDETGVlNYWz6rOwpDwL/UEK5VKHs9oe9phaC3Rhj7HV7ytyNEgeX5PWoTWNwVBiCBVoBZNRPQbuWoxIrlRjDQGyPlHDXq3V6hy6gF2OxOwkz1lbXz1mxx123GsftI/Z99lP2xX2lD/1A3tE/JJ2e4p4LiCwpobBiYF7ahiGJn4xdRZ/kRsSXBhsEzwMCv4I4pUVT8vQCcFgMlNHwaSmjkIi4Zwiq60yu7TI6jEZzFYrcRIqa7M+AnEGioI4XDx7dnFxfPYtjoqG6cbGUpdK8DjdoTxsVtxFCuLFxbOnfeek5TF3IOCML8N9345KDn1gEHhoTeYU8yvQ7BXcVReY+0VVMmGnKlmjYZYxmHI1plyN9S6nskhL8ot8esKmpExPDOhKUq6vEJRFeh9njCjwDQq8UYEVwTKMcbHguM6D+z3YE5ScuNc56GScRjDzwXCe6u4uAwigG6RzgrAsMOyxt4+JbwNWUR45z6yVPn2Rkiu2eoylCqa4QshW4zC2KfDVipsUjCJYLDR58BrPZg/jCRo1mPTwc9lJ+E2vr6p0KvMIqiwyElBUVFWZZbvI0Sw8Skz5bhLEo0e7E+JRI1EU0Cli0IdVUUeUMRpLZU0sGtLE7OYu7crC74r3BRRqQR1Sh3urBqtGqnh9VRpL8k4w7V/XvZ53NHA0+Gv/O4H3oh9xH/k/CnwS1RgT0e7otSXbonvwHmYPO2IZcY64Rty7SvaU6vRYz6hZlZZ3q6OvFrzmV7pZq9notuY7wq7og6oH1d+V7vXfG9AYI7pQtDW6qKqn6vrw9dHb857wH6j6mP3IrQ0rKzzoecaDvbgMMziNIyn0fGkaO2VDsd3jeN7lcXqdWHRKMHOk0PG8lRQWGI2wgjWcvogChQf/DJWWFVcgRCbVeYvDYU+zLbLZWkYmlnnDiLGRqNo/E0uKNcuaQT3u1Q/qx/SsPo1rZUeR01EKCkcZ3VuEe4sGi0aKWKmovIgpegbcxUosjWfNdVgzC6eGz1Bz/RwxzDM+MMxjZaDhUhkMKFH5p6B8KkFX1ilxiuhwTKJGUIIBvz+g05h1Os3OvNJI3jbxaJcdiZ+B8h/G4tSZqSxO0SwTTZRKKl01ePFU77tDYa8kGnjBa/C5MR9WupEkgpoXQgo3pjY51b0YeiarvhK+FL80fBXiurvwMBpCJNOxF+9l9rJ7NQ/pxixjzjHXmPvBggf8e0u03V3dEaKriQ0ia8r8ZYHd0e8GvhtVdHcR9W0ISY6YKuSIYVkdYyC4sj6Ck0pcdawUsqI0qGJa0WNM5EkkIjsUrhgFjlgg62n5s0AL4LApFrWbsnUZs3XpwdSRjdCEMRaVjOSZ06A0gEwfY0UdtKMjFZyWjTpoRwc0EOwGGi7yR/6vC+amC3WDEJN1DFPqdFpLKwSHuliRFj6a2FgsGD2ApDYacz5Kgm56GKiTgg1+6o4Q7W+z5WwHIsz8hiprbp8jUJQzM6g7w4z5Cq+7vGW55O255/Xntyzd6LPYdD6f+5HVzSv6pj8sKfnuTbULqwyiUcsemH713qtaS2aFwqXz+r+/7UGP2onn3XnXZbHmK8bqYyuGvmPT59lB8pkzf2Hi3IvIxYQukHzBfNkIki9fJmJNo7UTD0BrMWGFiaKmPCIXTenMX6l6NhHNTRS2icwg3fUyaZRRvdXMpbErhUBVJo6dO36sbOpoVhNHPpgUXym7WKo5bFmrmsaWC3B4ix9T7emcQRyAyGaCDWqwRu/Clg1mvAD8E9KcDAwMbWtcWEE1sUJJFK6CamKFiVgiJJf0lGpiQP5GNbHJlO/OaeIPINANjcS5493dkyKYDN0zOguYAdSVDjrQoI314B6GSeQ/aHjQ8YLlBWva8bFD2JuPdznxIu0iXY+2R/eFXcHbLfYiO2u12B1OFpPI7NqHWUt5rrdsOcNgXltDOm19y3LC8mcLa1lrdr2BNGn8mRyVtFhbWpafzGfyEcYcpwiYO0x4xISRSTQlTZOm46aTJt7U635yV079En+e3N1nuom7cKY7jhLnTpFtRHEKik5hgy2GIBhBolNTGizqYfC0XYddGGQb5tLCZxMbMa9XppWq1EZ9jnepFUz5tsriByVMOLKKONhg1Br8NbXEvsWt77xTFfLNMRT5R5pKO4vvrttUYgtzL07/suXcv3TNCYdW91f19DPrfdYN8wvXAv/pwKp8GjRvCL9/4UZbMdW8vNdmKOIIixXZvdhArUsDTRt4rRZi74xr5yWWFSn2Eh+P+mpeM2FVL2VVyD0rayghFlm71fEs+ztkR4VgTOYtKhoo2l7EFoUEu5YVgFPB+oJ5O0d2tmI5fqUsMUksR/GoCJbjea71k+oK4dkB1XYVo4IK7Dz0lHKbgSOcRvr4twmSBuRTynMEeZqUeb3F4a95DuoHy+/YsW6w/gzUJXPJAxIj6SuZSr3MyPpvcoJcjHuKsTfssRcVGMIe2+3+oiKpodBT1ITUmmKDWRIxZx8hRpwIbNPFskiw29Q9PAbDlS/1FuNiZAh4vV4Jj0hjEgNiXkpKk9JxSSH1hh+7dkYZxReKwCjDp4ay5hv4mFPdBlvWWUQXmHHDQ1T0pax2B1htExvt6pA2rTQdvJoNCcSDAq4h+7vYUls1Y8GBfOMFstGbteGIVwRW3IwR177phrr51QH/CovRUlJu0s2dMx1pKXCoFTq/01ukxhb2wJtvNkaLapvN4SumF7QXuQKBgFX0Gzpw/75L3MSaY9CCzBS7C3iqEl3C7r6Aq6SETFgkQXnL4hJKg0piwQXpHm4QaauI+NIQrqmyUsMvu9dAkTOyhbBPFaWtigkUCiWlRLdIKniktAp5uHC0vForq6BSrZyfT2IDkZzpzNuyhxBptdx2O7bTXDulsItBjxCPcqgMVDvZ6s2yA9h+58hkvx05BiyY9Vwik5PAJUfFt7NyUx7QuEerGOOSWmyUvLGRxBOqw2rWGDFuQ9uqbke7Nbtr+HyjtV5MjCQ4lbtd0c43S80F7fVyYle+Up0nSKhgAW5TL9AsqGmra6xfcMkKzZWaHarb1Ldp9Eutt1oZb6InwfQqq1B1vDRcUv0sdiEt0mYmD4MuBtNPS32B+hpR26FlZIh6taxEwVYtp43byc5nWBNbZO+xD9jZMvt2O2O/xStiMuLyuBxnYNiDJSMlTEkNzBuxqwycpnSyBJf0BlGVTqutroaJP0vlddWz+EoUQEHSYl4MBb3BkeBYkJODp4PMSBAH6Z5N8FmmEQnIAlrfG7Ok8ZWyx1UWqxDkvJgkdAgjAisK+LSAOwQsNM5pPM/tw5GFYBhFxHNkEyYSPxfJis84CFOQnGfOneoWp4bAhQHjLGKIZd2ysqwASLFaDEsArLGYYWYXZV7NbLdfYaqbVTuL4VVKtZLhfQVSAcPXaGISMuSb3Mho0nt1blzgn62IudEsZbWEa6o1RrfoxnkFENXzcTcxO+J0EyS7GRIpLi6m2x9gTg2BzCaGVyphBOMQd2e3ZicqYKTAkSdTIgWH82J1EoydGEZaAk6CJxOzS5qYDYKbcLtTE1PDq6wLEagGqAaoAqj6v8weYuW4DtntnEdbnRY+PrRRqy33iIBNbIT3GU4rdRMbyzVcnOoMbsbeuXBXNsgLWR+uDnRF9hCHt9hm/Dpi5IAVRL07IhYs2SMheIZsp1RVMvO+Fai9pOcmT/j1z1YsSQQLmbLCYFly742XznYb1Ta9qLXEB9dV1OMHoouals9qv+0ag+ObVzVWNF2/PLBrXUFBtL60srpk+VjYOzeyY/q1W2ebBV181v1N9+LuuCPaG5vfQ9RR5pRigr0PRbPbu1nBcbjQ5zHkMVGy95CHVIV2JRcKenk9j8CwSSTKymwx8dxxuCZx2flDmSOoEIyEJurku6m/RWM75VRlNrYXqjgUopXfEMVRtAU4WbMlhEOabO3RaInPV1qSMxlJW4nuBNnRoI0ZqEtG341r3EglkTtRYy0CmW4IFkmlPaUbVIOlnwQ/Cf01+NeQlhCkTDWU7lWXt9pXWhpeU5vvcHhdfrGUUxfmF0YLY4XLbI/bHrc/XqjUBOsCdUWLUDteKCxQzgu0FC0MLQzfIYyII4ZvBe8I3REeKX1IvI8QB58VjwSPhF4ofTX4aui94Huh46VepODg7XI2VVAoUoX4cI2tUWw0dCgWC8vti8O7NHvEO+y7HLv8dwTvKBwpte1U3W7bWcjqVF34OvE6A6dSKQsLi4JBNRbAixNtBo8o+X0eCYWjHqRX53n0XofHA5r09oPKUBHw9jZZtgcDklJQqoRAOGQOh0OFRYXBonKlyqxUqsAIc1gC6qBZrQ76A4Fyu8NstzvChX4H6EeVUlDDe3gWf4Yk5MGfHfRivYGkRJQHJpharxdF0JkSYkgmRlEgwYi3P4uvQkGkxI/J+pAMnQ0EQhrprH6tGhzO8YlJtDbsJ1vmFtlV1uHA+xz4ecdbjhMO1nFPoMwO1t/Tkj4I4hAHc1vFwWexiAqRBSSXVlaX9RRiuXCkkCkEO3BCta2oTPkMiGAlWI1qCQymkdDpEEP2vQ/Bo6F9AhF4ro4wHgljFBbDUlgOJ8OT4eNhIdxbct44nDoDUs7hnDp3CjzCIfsZ55SD7B8POSEDiu2nnGAxkjCVO352ErMxESeW5IxczOJTWSd0pyLrcdITaSVBFDPITE4kAt4oOaH+n2NBVMaVcXIG1T2Eu1E3JoIWhBuItkOFolmbIF4bOa0wERmXH7NdAMwEnE7ZYkECLDQ1bomd30Huoh4arDg2xOQZPD4FIsv56Y1ePeKDIQ3d7q2qitgqYUTkAMlnoduyJhPZki2qgaSQTROvLJvGfhb7MXCpDo/U+AxHX662F1njeGK+x6w8/qK5KIZ9K8LTb4Z/P/1FcPr9/Flx9r4g53F7o+f+gn+yM27LY4NB1ib6zZZzn+OvaiWThwkGdRvO/pFZcO5plllQpQNWuztzCg+gl5AGzabnTW4k8xpWVsn1NSo5UdOjwntVB8Dy3KG96kbyhunmG7guIIdSiKfjIpL3gv0zjMrkhtLShoaXaFxaJiMm0z/dgvco9kAzYXz6ApNJEzJRH9DkJducZyaIcaSacfdUM/uzKqLqTdlt3OwWsJpk62B5TtNHAPlsxjz/zYzB/q6sonY64sNFRLRqQ5DBLAuFra43RbCHjpV9EJkS3zmW270FnUshsNMrMLrDDzsx78ARIs4SdTW6SErXXStHOiJjkSfynsjfF+ElSIxEWBFyjkdYJxETDUWeUJODDAkcPqeq2OGSwlrBmsZ5sk5ESCtAy/q9JmwiaylenN0NBYXOlkZsNqdWm9vc5ejmrpJu7oI1PSZhvYR7pX3SaYmVJEICAukLMDaBQEoVR37hI1ujkUvP0GMeYlwT3X6p2Ly26aOFZyJTw+JUN3E3E1nVkeSPuSbotuzUcBdZezEDNb2NkRiitjc1M0S3J0+fH3TrvW7syXORIxQ880UH+KlDoK0nrFYxzKeVFYdlhMOC6EoLp1MbRT3VzQnnVE4v/7fd1Qv0MfHxLtpkDUXi8UhxPD7y6r5VnRU+p8vQ57OXWr/eat1Di4sj8Wnp7Lo/nprr91fqhBXBFXczdz4Q8eW2Ww2ZU+wUaFmJ+fQCLatSIaeRN/8UXDMDBAkCw/5unCjZqanPPkuUGWMX6Fe5wq5WuZQqVYEPntOYrWTazSbeUEy9LiPP0BxwrSWKSKSeY5Gv/7JnX2UfHBM/oJ8qqIxL1J32VSCdgTVTmpoCwll9lhqzw+z0qwrUPoNkDNglh+SsV8XU9caYvcZR72xVLlA1qZvtzY4Fzg3Kh5UPqr7nfMi1t+BH6AnlftX3Hd93PuH6qfIQmOaH7U87nnE+65os+JX9S/WX9q+cJXtVuIBu3/dWUxipyEJPOAvnzcvCoqIs9Puz0GCgUJYd7mp9wc1oGA8zg4qbpW8odhj2FKjqldXqanvM9Qo/6XvXKdyh3mXf6WDrjPPtjMlu9piQS/Igo9rgMYL6lKMqp0OyOxzlKrVZpVK7nM6ASgkY/fqfU4L2NRmNGNSd06EBpZUvG3vUWFQH1HvVh9VvqxXqbSoXWS6izJftUx5RvqlkldtUji1O4i9ISAX91RurVensqSiBqcoaAp7W1iDVJMiuNH7hsFiARwqyswFUBB7Wm6p9RG05xEhkaPgMOceMOM/ZPwJ91Z3TW93D9qmsh0rVEtnY2JnTRkQJEeTvqR6qYsgXV9kLNA1UjokJfUgtWXUJJVjMTwNUBTTkxONkyhRTE+tZbYopJVPMBSH3FRSe0SwqJzLyTo1kMLOIpScYwG+wzGyVdMsvq1Kym31Uh5AVldUqQlaJgKmLD7iLwpZfvWNTagqqcaTa7HdPPxuePmINeQ2VoDwKJX/5NM/oZuXnqfSaYJAzeFrO/olV1JaJKiX4vRJC7BHFeqRGOsxSbRGy6rAeNetkPSvrcbEWWwTM8JhVKXjMaTU6xGl1HA++bBq7ZaOgNAuCUsmC4aZVIq8O657FD8MwNHivrFNg8GV4XqngwIl9Fi9ALFgi62SNSqVn8V72ADn4xv9HtuMELHAnIvvg+/Qn9ayel8HdcuQ9g+8CJqIu11Bc7B4C32rhGfJpykfiOfCyErGynGlxbjhuyAk8eJcc+cYNUL1eX1GOhuFNDQ27DmmBL3Ug2GyyeqOg1uk40i2YbljUZaDFK7Mzji1+g9/gq8FVADB75PD+cy8xW67dPx3AZ+6afgivG2G/efZO5tFzxPK/BCFGr7gLjK+nLjzctGW+zB5umrU8FjDVbphuQWG6BYXBC/6cHltqyfYOydLOnF9qySknUXGAfHiIPKNVPA9STQlBQCZQeRqTWVaRyi2QUZb4IFIJRlXuuJIeCB4Vj4qvXLDfVGSiR5RmuvtpMpOfvxEw3W3CVDVhqppIp7InjtrsBhlFsieOWq3Navj6xBFaTRD5Rw4Znx6zTdpO21gbWYWJlmoC5frY7GpsS+nW1HbYsGzrsPXaBm1jtn1AKGjDHqG1AIc9fJHfXKRrMHnMTdAlgVcjHNBpc9Vk9wlqZlePaXGHFvdqB7Vj2n3a01qFNmW94MwwTvgA1vLX20vdeAiTJUYPCScsSCEo6dIScoeDdDPyotPAGT11k6N63nQiUerM89qdIQM2KO76qmH5rHx68sfK353nFP1EE7WAJmplDyAfU0DeekrJ4ZnNIsbJ061snn7AydMNH94a1KuEXt+gjyFfzBwi792Xn868Tb/dA+Tnh4m5k1/Bgv1CPt3rThzNvs5jR4nmMvrJXGwqLqlGfvLZm023QsG4TUu5JYol/FKh09XpFq5UbFWMoBHfhOtl6bh0Ev1eoarD8/By+zJ3j7/X3uveah92jxrvMo0ZxuyP4R8yB/wH8Yv4Z8LPHJ8oT7k/lc5gO8+0GlcYd3t3SyP+037BIOHnMieRBMEL0gzlI7LbUi76cK9vxMcgn+iTfB0+Mq4x3z5f0jfpO+476Tvt0/nW5Z/QY/3PrEGVkE/0ojlGgDzLGINBanxveLV4kXaPltGWifTbw140iMZQEk2ik0hFMhj0403OW51MhxPvdWJnGmtl42lyii7yEl/Oy7yCbyxoPMLcnZUNw0MLp7qHh84NdZ8CX4V+AAnaf4ju05wy5laBekl+f/6mfPbefIy6h7rAC541axaehYeo00APmy7vnECinRwBnT5siilEkXzWOpkSyTbI5LiY3d3AILzxkOtpvV7l87Eqa1r4dGKjSmDz00p3aiP79XdluQOb3NdkaGYzs4jIbbqLYc7uWbCtwXdvffhjjCd2/ktFdLbHoPH756y55LJHd62+tK4aX37oXzF/4l2ct2dhYVmhZavX07r60R9+1Vh6A0xTM7DiEWBFPcpnSi4wwd0geagQoXyopXyoFcnGpdbJkeVNCgkim0gmR8k4W1CpEYMgVcCszHFg1nz+2oBSkXJC5yQPu4hwcHJmKkzMWpEKDZFKDI7uixKU4zxabfbrT5iSiEhkiHgsQhshNlSzccSCH7cetr6MX1MdzX9PxRv/oMbzVc3WFZYd+E7VLv17LsErV9Zw9KvPvV78iuU1JyN78QLlTG+MHFkjEaMmsYjDMoePk7iD6+UGuTEuyfHcZ1ryWZqs3Qtcd/6DR7KHRz5hjLQlQ0vakh2XrRzXehaMe7kFi1d2Pk92LREHwZuZBFbpaux8DjnZSsQhM1v5ifiJ64IkSOCu3IDAyq7F+cZgXiETdBeqg3yhQW+WUD52StiqAswuAGbSiRJ2sRBZNDYJORQQZbnr/EV37YAtwa3FjZ2yYQuzhb9RfWPejcbrrVvsW9zK7i5gXXIgqnKLhpgLgoU4sJrs50wg/caRSLkTCUpbWvhjaqMyx53Ufqenh7nvjGprbQXEdzXmvihi0PFbrt761va3brxy2xtLaq6eu/ebfbdsmMceeGTngZvOjuzf/ZNb/uu6hsQjN786/eG+fz1zZy8x0BHiy4EXV3DKCzjR1iUT6dZFd9FtueOYZe3lM4cw5UQDEm4kObKeCMfyCKWKVNS1zFC1zFCRHNlHqFoa5jVQugaqWRuoZm1opwc47TPPtc8c8bTPVADI32QHoW1Xk2raI/TxCH08Uke5lmTUieSxOrILryHP1blJxZD+VPYS0jqGljOkjrqLzpfI1mm2Dqmc0ED6pWwdUjGpA9LvyxpCKjG58rOg1KEeyeooq2yeT/xaad7SZTKhKVuGFy0bWLZ9GbtsOT+vwh6MaoR4VJFdo2Vl5NypG/zbc5Pkmjl5Ou/4XoTmbAOIwUCIUPgK/abp6wPVOFQPtWsEhbB02XLBXjHPQE0Eg0TPpaQIT5Z4hOZF6hpoqoGmGtolckJFvVeps44c85Lsuux5L0U+p6V1dZ3t5ESVZLbPmByA/JWWtrd3deYsDcP5GKRFNsAQEB3zsUSCbCWBuk/q2pZ2vgA6+WMQhh+jMgjlmY8POe0Ou90+K3uBre2uFo53/dnKjoDy7+oFMRLR4bEuLCmlsMeeZs5OFNSFPRWAyJqC9rBnXis9KUuzeRP+SNhTnmZ1E/6GsKcFEHmOf1nRwoalnmVNynDdQjkWDimREJy3fAV5McGoVq0ReE4hzGupKLfb1F02m1M0BHzlEh6UkhIjpXGNrK8Ll0YCs8rr8GBdso6pI3nWhSsaAu3t3oUdC5mRhWMLGbRQXMgsJF6N2Vq9sLezK82sPOh7bDs4VGt20J2B86duZ8gB7qksiF9KtgjAKiJXgv4tpLtxua8/cvsBWZ6g8spcENDqdUF/YUDrc+M8fUFe0A02FDk/oHsDiHyOQT9XUC8XmivLHFbFvPl0J6zCPk8dVMTTSvXBjRpF9viuMrsnRg2t2rpacopny8Zkoz53hlc1c4hHdCEvCLavTbLz2fTM7+99tlWFO9YYS9ZXLb/ZcuVdbQuGfFaduvaS6bhpts+m5lxFy2uubmcYS33LdEV7TKPwRRfV1iwpcVS0Tc9OVDrpvkORHpsjzGdr9IXFa3qub2tbVn/z9NblktUbCNjoyeDoYKlcM18TmW67ohQyAwHDYsirkPOjddOWlbWuQMA1exm+4oFodn8C5X5Hkl49+vgX5EfdyPW7ynO9F0JlNp8//wTEgm+6meLqzMNoDfrvl4npREixHPnZb6F2DqFLmBiKs/loDUAz82OkY4AIyhYofkbxu5lYph/oDBAkoLkEyloAb+ZjREjPXMynxA9ASJNBKO/foZlfIWRdhpD9R9ngPoWQbwuE3yAUaEWo6FGEQh8iVPw2QiU9CJX9kfxWKB2FCcZ0PbTsAZNEpL/qhBSf6O+laYS06P7zYw2gmXEzYGcEcjgLWCSHc4AvyuEKpEGbcjgP+beQX+nkVJAzH30/hzMoL/vrnYCzkP/XHM6h+VjO4QpkxXfkcB7yH6mojVVVl68rL6me1ddXUl1XW12yuiK2rqS2pm7drLpYRXV/1brFa6/csrFv+B8h/Udolq8d3rRh4FqporTiHyFHFagWxVAVqgYTeR2EEsBmoT64S+gv49VCXIJWA10MyksgXQO564CmDnIqoLQfnl6HFtPfmdiCNsKTw/9rtf5v1bMcekd+hXMDGkDXIglKSiH8b9XOov/xalCjpeyfmZ+Ab+Nl/8ROoTjAqRSf702znx1ki72JBgt7CvWyn6C97O/RCQgcEiFHBCwBYRDwDARFZpL97cHm5ko5DTBSSmEqFK48QgpSTnfl8+xvmadQEbEl2RMpq4uWfJiaOzeH1M7KIgeLSypPNKjZD9GfITDsh+wJFMo+dTBUWnm6QQcZmL0F6TFGXrSP/QAlITBIZt8/GCis3PsC+waU/5x9DQQJeey1lM5QCRX+jH0aGWF4h9lDuZJDB/MMlahhE0gHjCYhPg7hJITTEDg0wD6OtkPYA+EABA7pIfZCKIOwiOSwT7JPQj/3w/N6iMsgDEDYA4GDmf0x5F9NYvYJ9ipUAM/eyd6HLAB3s/dS+EOAToDfh3wPwEfZeyncm0t/FyApfyiX/yCkrQC/k4MPQL4L4P3011O97Ldz6a3sFvrc5hzcx25KebxigwfKJQjlEFjA7gPsPpi6+winQIzZW9mNtKVxgJUAr8lCmK5tKZ+fvqNtB22Oyn0wpdtg6rfBzG2DmdtGPAX25hmam7M0JezNQHMz0NwMNDfDrJSzm6C9TUQuQixCkCCwMO+bYN5JfhLiSQjHaf5tEI9B2EdS7HUwj2Ho1S72qlTIC0x25cGYXJl4ll0HUy2z6w468iv3fJ1SqQkjAszLQT2hXUtL1x5UaUnu2oPO/CwEqqsb8th+dBMEBryafhSAUA2hCQLH9qcCZd5n2EvRNUok53m3M9vZ7dx2BVfehI0vgCfUAVrAi4xsCYor0WFvTxzX7djXsINdTSQ4xCKEQQhjEDgYLdlBk9grIPTAvPRAp66AfAQxgpQI4TjgJwEqIKUHOj3Q6SFXD7l6yEUQk5IOCL0QBnOl/PmSmWcI/WlSAqEISvMgNw9GeRLi0wSD0AopHaR0kNIB1XHmLPRQhFiC0AGBpXknIcD7g3imrDxX3guBp+WnKc1MmUyeBdsyWjQZxskw3hfGY2EsxxMNlXIBREajccee9gPtL7S/1c71tA+0b29n68hOWCpSXklhQZDAQymHs7JO3zCbOQA964F4L4QTEFjkhbgMQgLCAASOOQCxF6RbGYQEhEUQeiAo4ImfkDULsTdXRvL30jKCkXLmonIWxvBUqr5qUcNCkGM9EPZCYKHup6D8KUqdxQ7Q/CTEJ2n+ohz9PprvhXjmGZY+Q2THylzshZCA0ANhEIICvcWuALm7gtQPsRfCIIQDEDh2Jdwr2BXMT+B+inmKjcq6CosXWa0g2o0GpdggMlp4qTr8BI2/Q+NdNE7QOCDnteq+bNX9tFV3e6uuCBAmhBqg4D4a+2RNg26iQbeoQRdu0EFtNuQDA8tCY57E+I80vpTGUdns0/2XT/efPt1ffLrv+XRDPt0lPvKcG5aFjjHTWENifD+NW2lcKGu8ule8uhVeXZ1X16DDj2BoHc2lsYfGLhLjzyf0TXqkehZ/jpqgJpyKh71pBlGAM6l4A4DpVHwegHOp+CMA/paK3+t9Dv8XptoCf5kKnPI2WPAZvIAj6f/Mwb/gBehJgKcBXgnwMRTHQYA/TMW/Qeh/AM8/BOnvowIloX8UddDn9uIFNP97ueceTkVXQ6vfTUVvgFYfQlHa6gOp6CnIvTcV3QXgnlR0I4A9qSDp4FWpeLG3wUC+02IIbT8KMqQn7bkW50PNGwHOyz7cnIqSp5pIA2ncmPJXACgivXwO+1EHbc6b8tNB5iM/rcKN/LTTLhSkMA/raed1qIBCZcr/DaiFnwie8v6f+LNk4OgLrE894v2P52B8yyH5O7wg9aT3F0fIdKW8b0XTOHjY+6b/We/LgTRenvJORtNKKHghmmbwIe84THISaBl82HsgeqX3J35aut8PpfCq98ZLvN/1r/Q+GIR0yvuN6HOkG+gaGPFyKO6KzvG2x5/0tgTTGIrlODQmq731/mFvDLJnpfGCg096KwJp0pVyqOPJw95iaLHQD12Z8NYsW1b3DFMDhv0WOSpsFlYLy4XLhNlClVAiSEK+4BbMSqNSVOYptUq1UqnklZySAZ/ETI6qIsQ2N/Mi/RFmjsQcxUWGxMSUJz+rgpUMrJ6kiW1j2pbMxUljG2pbOjdZF2lLC5nFyVmRtqSyY1XnOMZ3dUEqydyRxmhpJ7AoydrhIr9TdQRhXLbjWy4Cb97xra4u3Jac7Edtq6Xkl0tgJOrLViYV/rl2ZN2asCeMcwyxlqa/E/Xm4sjXlz1y4WXPn5u8v21JZ6rmxz/On9uVrKR4JgN4W3Ie+aGrI8wQM9DcdIQZJKCr8wi+kRlqXkzy8Y1NXefJUAEzCGQoTgAhO4gKCBkqwAcpWTslA34taG4aLyjIEr2EFxAi4KOXKNGV2boC0ATU1UEAkDEeFKB1BRgPIQPGyFamv7AyLcJ6Wplei2hlbkI0HgwCSTRISMbrgkAwHqyjxU9+XewPZrvThYK0nSDuou1g/DVNKEsDzJCjYZRAE/nfvNbOjfzjFz7Y95s1/eTnxnr9zWsh9CZ3b11vJz9FI42v+U3ud8gKe1f3ryewb23yN/61Tck1/iZpvK//7xT3k+I+f9M46m9e2jneL69tSvXJfc3+vqaug49tb2y7qK1d59tq3P53KttOKmskbT3W9neK20jxY6StNtJWG2nrMfkx2lbb4rm4raNzXInmkn9nofAgo1HDsuh1+brmWsXBOXSNzPbZb3E9wyHQX5pIV1Lrn5vUQSBFJQ0lDaQIFikpyiM/KJcrst8y2+d6Bj+RKxIh2+CfC+61vXlD0/m/TZs2bd5Eoi1bIhBv3mKnmZth8fqWtCVbyO9fxZPx5qTc29RFN6WBsFOu7fH3BHtCPfu5Af9AcCA0sJ9b5F8UXBRatJ9L+BPBRCixnyvzlwXLQmX7Oa/fG/SGvPu5LfTqauyUxRfib8WZgfj2+J743viBuCKbbXyh4K0CpqdgoGB7wZ6CvQUHCnhScHnnYTm+t+DPBewW4ES8Ga7mJtrdLQDhjyQ3byED2QS9C/SqBlUjKlZUSapylazqUCkG2O3sHpb1smVsgl3E9rAKcqIj1FeR84IWvr5qTLNPk9RMao5rFEl+kj/On+RP84rsKVMH38sP8iP8GL+PV43xYwLTqxnUjGhYUSNpyjWypkOj8AoYwdg2QSBztGWLSxYFvsmrUTd5WabJq1I2ecn0dUW2RBo7GwpQP9jHGGz5EmSC4IdQBWEJBAX6V4h/CeE/IPwnBA7dCvG9EH4A4SDJYUvYkmb7hiYyB13011/sbOXB8prKWWmAfeuycMnKLGy+NAvjDZV2gKlElbpBD6Y6Rs9A/HMI70P4FMLfICjYSraSVr4luwa7NqFNEQzDIicKm0m0KbKZ/tgCJryzeVMkgjbR/2+BjM2b6LHrxasY4U1b0KZNCLgLABDR3E3ksS0EzlxQQM8/0P8D1JutVw0KZW5kc3RyZWFtDWVuZG9iag00MSAwIG9iag08PC9Bc2NlbnQgNjkzL0F2Z1dpZHRoIDI1MC9DSURTZXQgMzkgMCBSL0NhcEhlaWdodCAxMzU2L0Rlc2NlbnQgLTIxNS9GbGFncyAzMi9Gb250QkJveFswLjAgLTIxNi4wIDEwMDAuMCA4OTIuMF0vRm9udEZpbGUyIDQwIDAgUi9Gb250TmFtZS9IUEpNVlUrVGltZXMjMjBOZXcjMjBSb21hbi9JdGFsaWNBbmdsZSAwL0xlYWRpbmcgMTA1OS9NYXhXaWR0aCAyNTAvTWlzc2luZ1dpZHRoIDI1MC9TdGVtSCAwL1N0ZW1WIDgwL1R5cGUvRm9udERlc2NyaXB0b3IvWEhlaWdodCAwPj4NZW5kb2JqDTQyIDAgb2JqDTw8L0Jhc2VGb250L0hQSk1WVStUaW1lcyMyME5ldyMyMFJvbWFuL0NJRFN5c3RlbUluZm88PC9PcmRlcmluZyhJZGVudGl0eSkvUmVnaXN0cnkoQWRvYmUpL1N1cHBsZW1lbnQgMD4+L0NJRFRvR0lETWFwL0lkZW50aXR5L0RXIDEwMDAvRm9udERlc2NyaXB0b3IgNDEgMCBSL1N1YnR5cGUvQ0lERm9udFR5cGUyL1R5cGUvRm9udC9XWzFbNjY2LjBdMls0NDMuMF0zWzUwMC4wXTRbMjc3LjBdNVszODkuMF02WzI3Ny4wXTdbMzMzLjBdOFsyNTAuMF05WzQ0My4wXTEwWzcyMi4wXTExWzI1MC4wXTEyWzI3Ny4wXTEzWzUwMC4wXTE0WzUwMC4wXTE1WzI3Ny4wXTE2WzQ0My4wXTE3WzUwMC4wXTE4Wzc3Ny4wXV0+Pg1lbmRvYmoNMSAwIG9iag08PC9CbGVlZEJveFswIDAgNTk0LjcyIDc5Ml0vQ29udGVudHMgMiAwIFIvQ3JvcEJveFswIDAgNTk0LjcyIDc5Ml0vTWVkaWFCb3hbMCAwIDU5NC43MiA3OTJdL1BhcmVudCA2IDAgUi9SZXNvdXJjZXMgMTMgMCBSL1JvdGF0ZSAwL1RyaW1Cb3hbMCAwIDU5NC43MiA3OTJdL1R5cGUvUGFnZT4+DWVuZG9iag0yIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggNDk5Mz4+c3RyZWFtDQp4Xu1d62/cNhJX3NgGbNip83CS5rWO0yR9mCH1oCRc20OaXgtccQXuGuA+nPuh6dXoh70AbXMo7r+/4VMkJUrUrmTvJmrj3SWXrxkOZ34cjri/7u2QGYb/T9hbXsazn/6zt6NzyYykKMXy1fkKEfbOMp999fPZj/+dv/nmtx//N/vp970dPPv9p9d7O1++hO++JjM6e3lmdMQqZogkyewlVP7X0+iL6Ek0i4ooiU5fRRvR6Rv2vhmdPo0+Z8mn0d9YxlfRZSjFv0kh+9NoG6qdwN9n8OlrKApfpR/9MHv5172dv0DPf7dGm2YxKhI60Ihv8RFvRA/h789swA9gVCLrSrQhB/Hs68RtKE1QXthN3YTGbkcfwN+d6G50L7qva9eGkVNESGpXV51VhXLoIrYLXY9uRIe8p5u8rztuJUYgiVHSXaXOWV5XC8iynL0ELHwPZnoz2oJphSkF5oIMvI522cvpWXT6G0ufRfvA6d3ofXiF/APIu8qKnMHLbqcQDDfc04+EaHLBhamHCXwAYrAN44e/Vp7FBFExiOZBVt8vO8jrwE+1tp6K903I2oZ1lHJWP67GD8w8grcZ5APnU8HrR8DgR+3EFKhoJUZ/vywxh4KYNzD8x7DoT8TQmaDCXGgaYLwgCccgH0xkuODwj0eQz/42omuqTty9GNgiIAb3ODNTeLvbWDdHSeZdn5xbGJEidYtUnLV49OJ7xqPvX3wHhX+ANv69t4NwCf8Vsz/YN1mJMDQGbWU0Q6DCZcZ8b+d73qA9I0L2afAKILE9IXhWoLxOHxs89MJmO50RAtwrjCHJjLnOAA6UIkPUcNNVhX/u7bxuGCURo7RKZzQByumsZAvnt5/3ds448YKSZFbYhMiqBUxFbGofEK1N0C6H8HoE4vQQBG1LyNshVzrbUp52mRBcE98dRls2HxS3ExCFglGXl7kyoHiG4iJh3ImzBMVpLtLzKl2iQmRg86Mq1c4RWa5qyuKFMbQTRNIYxDElfGAsE95OeIZ4lSNKirKegc0EbwnSqkWe+KVxpE3SzMb7h+oaYYwzxRzeOM/Q0lyjQHBIkADTKr7EJk24Gr4obCRzaAGLj8AoNXa8OBW4okB05oxftfOPb76Uyw3F8Jday64mrDCZJJ/liMS5ktUbADjuw//3QCLvg9xeZsrsgJvNI56xJUT0oVdxxxkFojOveBLQgpRU4qnSA4hn1ZRPPHFNNI1pVNVrGdhMDDubulV7PsMn7BZXHK9gXq7A/1veaUloieI49k9LSUFZltW0yPQQ06KbWmxaypyP3MrABZHTosY97LTIPv1qQg3CGDgRlszRE47uE8qhWVfkhqIbVOvJphfQGSRABLdAS3DE9LnA1RzIsK3XE5ZmkFBsvuQ+K4Ei22InxsAiK8Zw7ae8Db/8cpuXYETz0t00CpUNKykF2xuos2VpN42NzwOLlGzUnoRm3WmTKQffqI1kq3yU5mccsjrxzGmmE96I2aeoSDXQvA3zf7VT7TRTJNeutZCXpchuplHdVAqkbeGunrC0LklrUg5hUTFfxonegykHQPuir9pMUJqWdqO7gFQvARjg2x5nW+wMhgBmpsS/F7FXdZogQhJ3VSuwGaMyp/zLE92Lf6pYrSyx0xa05NB40MmSXXZByooOn3pyYTKv4CRx9XEUUyGbDtFS9rS1aSmxK+IMNz6GrmirkeYFrYv0EZV1wXuwFKu1tN2papunpUnVLjctViPD6Fk28twj8cXgSlb01g3xAqTKWbmqpg+yaug4/PrVjddWsN/3kqWoiJMmbf2r4nyWozSmhvNFZsx1BoV+RYao4aarCiHOF1l6EecLTVGFTW8yV8or4cB7w/5taf8L7Ju2uP+FfxWDYdsP8LpQMIlFNnldegnl5HWpKfWRvC4+8Zy8LuZsLmKFl/K6eKdl8rpg23ZNXpfV87rkFOVU+wxtlU3eHq+LTaYc/Fp7XZopmrwuvYTlbfW6FCAjmExeFxcmr7jXxZ62Ni213PbeamTyunSp2uZpmbwutbmYvC6SFIIxKkmjuv5VsZ5gUHLEjMNROXMjDCbhEXx6vuoZVZ0Q34sqvojzhRDMjYsk6hjM4CEYrPdERMumTaNtj9giLXPDcak3SbRANE2qTZJMFwTRTG6NzM/9tklVY0m+hHeFtVPGeT0Dq0QOG8BxhE/21LKmqu7bt02cjRJiweeMDLU1MhSA7KN7tFAwL7N2FTAil3EfDgsZMUYcsBmSpc30eTCf9dnHEFq7ztvRx7C33PLiz6QCrtueQiXKKsN6T7hheXjcQeWE3WyuG2coz4uODhKCylKHEsJ+d4PvdKW7FymH8IHw+17xNFLAW9zRU5qiNC5VocRuublKhkHb0I52AekVVPvjj4ElMnBZeaz5tn6fs8zoqg5OSB5rF12zagU4kZeF5X9i6WFUa9VYP9WKXRMe1zMqSJUOv0pUJ20oRfW8DgpVDDZIn64Ge4PV6cXxdzBH3oc8mlzu7l+DDoQXBOv6i0hGh/d+UKVVLW94Cllq+RobUAmqpwQ1U4rEJfWBx+4fc1VdVuWOReJuc/O25vaMwdbc16D9o+h59Cy6Ht2Bz19w8/AcOoJuYhjOJcap6/DxCL69J3L5Mxz7UOYYxviIJZ/Bx10o4hmYreg9A7MV/elZiG73NGXr9lEfTGFb04Suu/aP4+QCtD/rFS2t/Z09glQk4wM+Z4MwGYjZBRiIcAtwgy37z7ga2OYPTyVcu2/CMn8c/Uk8NPVZ9MB+2OoE8tn3T7hFEKpjy6rLHnX0KHtYmlX3UO4Jf+zJOCpSsDjYcy20PCiauqXx7iziEpHK5sAw9kHDbbBB7HMCDsQRqwS+VwT0/YjtEF5xj4IepI/LSQa6p8vqpCAVxn7hTD7ctQvK+X3+YBczdBvKJMI3/IVZa2n9Dgz7KL/1GJs0R0WnsclShCtjw56bI8K8s+cA+VOhwKkH6mG1DbCIl/ljY9tcIB7pB4l2+Xc3og+iT+D1RXQLrGjc3CVNEK26fB7dhCqfgOW8BUaXNUCibz0VS1TUTV7NMjRLS04Rrkzht+LYcosfXZ4scngCq5BmTqvcSB7wqWRP6O1DxoFLCuWnPgXbKjU54xyjKnxVZQocazrQX0lf1ap4SSY/1N7IHA62i/gCYAkOM5khfqhbsJA3VVgUj+jrdoJ41+xKwuAVAVqhULdYiRU74dhfBudvkKMjZM0eAwDZ5kYY1uwhC2CB5CVYyo/4U/N3AN7cgL9Uu0UbcB2s4SRx2t2QARd+uElwBkSVdrUMeqfC3Yx4sCW0sR3lUQF/pX8EhIUmF05bzdv0EPBd28c7pZshtVvIAtJHokkYwTEHPsc8fkRg6x4o1uvLWQBVfwj4k7u4vhPEPmQ4/pBfpoD4EeEDua95zIPUNqKYg1fTx8UB8EwUZMD3sgqz+VC0hSbIvT6QW4wmFHIrP9ZkwIvxDPhKAsLJtpNR+TuYbR/BebPAscWozpsFjjDOxZLYlraHJWk2jYGWxDaZQ1kSu9VwS0IxiutG0ee9icFgxXnTJRge701WIkpKYTzMz/0MSdVYktDZ2+y+YTyS6hc+prBqBh+t6KJ7rFAup2SdnDfGiH0Gw7DVgg9O8vw5/2UPz81ldqLBNOL7MrKlhxPHv3Q9GHCYpVs11nfplmsFArMVWLhiqEHrtlwhnBewbC+Ku4OhPOHBIbBk9wWEOYbNOXtk9RYgjdvWLaNOYzlgjTJvcJp0uW5Kdl9VMoznJgWS8qTZcwP/rgjkuNHikxFHRQsgU9cnsw/jFtdGbgzik5nAqVl5TcGp9HNMNg6NaeNWDzxN1i8dkbuDWb/JxzGZkcvr4uNIkgwQ1xShYmszWryzESqG2SMANDAtzIzz4b7otsuWBHjMVzqwNtyi3IeVf42plX1+O7g2J1ejGQ9/99/woPwh/mU+nYl1oqw1WeThB1/mGl/RB6eCl/jF8X4wwBgW8OLHiAW7+6lcwGlCcMxV+CBekyxDMc2avSZDxrsI38oU7zLFu9gV39l4l8m2xyPadmzBxRV5EH8xs++g4XM0/Q4eJpP5n/xFdfs5+YuiVfMX+a8lSmMAYt7boLWNEhf3s19ga7zXlPsQUsvJxNJD3Guqm1rqNmTh8qD1DGwm0ChaUjXe4ddhNzHB1PfY83EHS95CE58TSQZenCDTIMs+u1S+QYpP5bszJGroNBMYaRBGvLRV9rqwS+cJAPwT8SyuuvTKvHHcvg4L8H132AsjzL/QuMU1kCBPDrHMVEsL3x6Mi1oaG58HFkPZaAuc4gX6rqjVoKOP+MHWfMaFbDOyrlJq+cEIv3DR6XZqa2rGuZ16lTRdAzkha6ZxC0K886P5NAJZqvFFl9BdBk2vicVzANo54J4t9TNGhX3dsomGmo7cQLljtUc3P/dbSaox2FPlSwOidb/AkLNRrh3gSDnGtlH20T1aZrzLHsZmtY/lDGoCEZysYabHmRxHnmS/Y+3r2Q9XH6oIZnEXE9tNH7g/HMMc56A3CUqEGihhWLCRE+m5TrNp5WlZ3k3r8u3qwCqdgAHEKQw7rd/cWnMtyJrOM7X8WjLmK+C+AXErmf/Eock9sW2zQxcp4I3JHYwOZk1mzHVGTHjBuarhpqsK7QyxSpMUaKwxxLevb5WFhgsst6NnLrU2dYzclB1wJCa9MqcisMaBGo/aSbaLE8B1ZRn7iO53cZ1q2vYtGReV1f+95tf/+t1MouKxTrKXR9rT5L81qPESUEvIYorijDCuUwJagKiMuc5IEkRFhvRROemqQoiQydJZzjfYQwiZ7TOrXQEKbzPOys265NkkcwWPYUQmE1RORXWNLTXGtfPBLl6WjAWDyJ0amMWPsGvzdkGa+MEk33fXDh79vG+8+9USMChCC25r0lKMT2TMdQasbSwypGPRSVcVQgRMlk6zwQTMvtKwJmDsqkVgak24bHK5WiuEKGl6VE5FcY0lNaa188AuPqBwqYFZvAgTrtPq8LuPbDXf/+uP7/HvKTxngMPsKVRjffcUNdfJuZxC1fwnQ5wP5iuxkxCD7buRWFHWB+8jLo73QXokZJPQK/ZnKRgd5zz03sCVMmccIB2nKEtDtxZNiHnwcJ1hkCIpQNASE/mpnFGwIslBsce92GhjoHMMMRoGKfFAsjwxkYLMGQUrkYwtcNqLwzYQGOek2uIOQKW4UI+usE24zJjrDGARNXnhpqsKIbyRpTNgMC56scY+hW47UbcIhJ5yOf1lgrKCqJy5kaMfWZN13LSuEUKiLE1KjBKa1n4oybfN4MGHzUfmPnztcIhCGwGxZoo94nAfesyBVmaPKFg1nTGvMgpEJDdklVqGrtLBH6s4k/ViGBitGrYY0BKoYEkIO4QSHFDyIHMMCamArLS0TrqqESIhsvRCEgI90x4hfOsN39+iq9dXyxW9GMJvPGM7F5TfeMQ2IX2hBRYP81sK9pMCFaB0Ddgvc8aB/QRwR1osAfu1U3iQOMSBML8EoAbmVyB1FMy/ACQ9j+BJG7BnqBDckQhUZswrjJoo2iWodNJVhRDeyNILQNLwIE8bc6cokdMv4YXMmRs5sMItlO2mdY0QEmXphQDHeQSk2pC02pNIBFptMWSGsQeRIapuRvCuxCo+PCQNjp196zYtnXG+GahnWi2f1jjfLAZLnnkiW6Y4Xx9MmuJ8Q6JEyFrG+d5kNpiFhzGctyXsb4XyrlmxIM6ky5he/6Iqp5hekw8te6d3Iqb3Dt9EMDgHUnaFbzautsiXCuttka8prNd1OUxhvY3LptHl8I6F9WYJ7NpA7BrBzxTW24V/prDeKaw3HUSevL5U6W5ScbYyZEzHzcq0jqsVxZ1kYJStWbg53C9cIy0S1aeJVCF8etwqQ9Plku2ypZ1Qq3Q5eDyfxYiwiKtdrraPewZc9XKqxrANz00PqcwYxaUaJ6juC/Q5dnpEJN+OPuZenpoI2dRB4ZK5bczIEZlRkVejv8ahdoLt4kzv4XQYOVItW6SzyIVnsA17zkMg2A9mfxp9zn8pNeEXFYNcnb7qkhi/B9kxBzJEz48P1uGMDxdTiN5yqCD8AG8NWB+MCS6O90H6Isz+TiF6U4jeFKI3hei9ayF6Xmmxz5L073B6QKl3JFMoXGgonN9SmYFmfhCqAs3WG4ROgWY7ozlHFsCpjV7fc8GqjU7fCa8KLTAFmgWB1ynQbDYFml1QoJn/cVsrjGthYDUFdIUGdPWEuJ3hUpTEqKTV/RiOa5UHbFHQXRlXmhnNUBmrjHmVAVpDqERZw03rCh1+VbN0RhOwktQ9dPcYFtVxjFKibcBNYUiuiHtNDrgvvnY4asJOfjLKRs9mowY6Mwq94CosTKWBh7kgF1ufe4FOo7HUipLrRJ0OrmF8i2H4VgYuZCgI66ZMRwoNU137gY3RfS/8CVwpstJK50RFt8QgLiNRJPvtJkgW7ANAV3qihKgZVPkQ6KpPlMRS+oAxFxe+6PNFkR78FLX5Zp5wVNx1AY+mJ8OoKEyCZIYmwaXQ5UA7TVZpAjAuHeikSzZsbwXsi3fsX5XcjUa4dce/Z2g3mylFNCZNZtPZnqb8iJkFLZQ6Zq1TxHHJ/hPbMAKGnVDD+sqMubsRaz5bJTNqDz4DrBEDyWx3kSQV5909VZblCIyhXWwjeli/DptpqqxwWzy2eQL//g9ZknKSDQplbmRzdHJlYW0NZW5kb2JqDTMgMCBvYmoNPDwvQmxlZWRCb3hbMCAwIDU5NC43MiA3OTJdL0NvbnRlbnRzIDQgMCBSL0Nyb3BCb3hbMCAwIDU5NC43MiA3OTJdL01lZGlhQm94WzAgMCA1OTQuNzIgNzkyXS9QYXJlbnQgNiAwIFIvUmVzb3VyY2VzIDEzIDAgUi9Sb3RhdGUgMC9UcmltQm94WzAgMCA1OTQuNzIgNzkyXS9UeXBlL1BhZ2U+Pg1lbmRvYmoNNCAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDIyMTY+PnN0cmVhbQ0KeF7tW2tv1EYUnWyTrLTRhizlVUKLw4aXIBPP+F0BFYSCVFSkFqR+aPgAlKgf0kgFKtR/33NnxvbYXq93Ey/Z0CTy2nM9jztn7tw5c23/3e8Jx8X/Fp2iRDpv/+r3MqlwhM991/yWbnFBZxJuP3639/qf/Y9P37/+13n7od9znQ9vD/q9Ry9x74lwQuflntUQFQy48DznJQr/fos9YDeZw2Lmsd03rMN2P9J5ie3eYvcpeYv9TILHbBG51B0f4rusi2JbOO7h6gmy4pZ/+5Xz8qd+70e0/EtBWz+QPPbCljS+pDTusGs4fiCFr0IrLTrDOkaJ7SdeuSLf41FcrOoiKvuGXcaxzq6wb9l3WemKGlHIhfCLxdPG8kwRmpDFTOfYeXZBtXRRtbVeLkQdFJJ7zUWqyKqymYEcFdkFQPgVRnqJLWNYMaQAFzZwwFboZ3eP7b6n9B5bBdIrbA2/kA8gO0tZ9vCz0mgE7am7e1ubpjJcDD0G8CrMoAv9cYzFTAoeaiVGK5nfP6qS54BnOrdu6fMSRF3MI19BfSPXH2Bu4ORADuR9jfUmAN4c35mYx2M7k90/amcu6M58hPo3MOm3tOpkqBiLrA/QF5YwhH2QySjDUZcbkNPRYV+nZWTzZKBJICz0FJg+TldGlo24F9TOT4WWy0Xsl7PkyBYw2nlBGL3YeY7Mr1DHH/0edxP8xc4nuhMk3EVlqCsIAw4XbgT7/d4LVWFxRLTth6M8uge9Y2eLC1+kt1yHy9ijykUYw7H4Or2fpxMea4FrX6a5fuv3DkaMudBjbvLlVcHg37/r9/bKSpNO0skUIyFOWlP9azRKZFgVuHZC1YR0WqNK/DlS01HIk76f0qa567pBCo6qXAky5G3YTR+Fy10ZqF5sWUuva/fLtbuAwQyjMX1SY2K64R6+Q67dGd1mfWf0cFhdUb3Qd91xI6RLZGkyGF93JeGRNR7tDo5utdSd8X7Ic+KiH/K4FJETcSGjfOVe1XRkAKc0gFtaJbe0xM7UekoRSdWpuimWRJi5+QzTyTYmWFpT3fxyK3PLtkFdupx2reuWDdBUWj+ZdIZp59J89KPYFQ+TTcoxJhHyxEssm9DpVowirerQVpErnkEoUjyN3q0DSm02WYawFRepVZwUzzSiO5NYerlHpmjd+GQ4zaBbaeVte9wr5G+/1n52AKq3qpwv7RhrXa7mNDSGNZwm9L0Cp6F0KLkfmDllX083v/LK0I+j0pqoKrAoQDCjgTQtNdGaoHm+KRjNjMK1J9qaUpZ7MG00a4uMQdIwnWaIsjsNwtpGLI3ruJblm01uO/05wKc2W5/zF2nOL2OyX6CLgQkNYKv/Jg2UmCZ+ffrItMAlDt+0VKpbwCH42darW6qjrGa5cMKDUKSFv4c2cETblVpqNKHdbam/tBEEXMV6h7RRVZvNq3pn7rC7JiiWR0LSIEctiDLgURSXOzqak9Jo1rlILORRYpNSnW7HReaVTeciK6xOVgU5D/Hbt/a0kXFLd9rySXCMWtmJ/OJ8wDuxWzw+fBvcweQucMjWVbCbg/B02R3yDDfYzXJgaZx/o2kP8LIsMU4Es4x4BMdjJPu5RAqVdT8tU07nJcZP9EJuIX0eQLmIMMhnexr5GwlE0TVu6Bgv/N+QLbA14DFQ4TwIKKKHWwldq5815E20aKBPC9ndvSxydwj/mQEpQy4DoYCMA+4nmWQ/l3geD7VElymn8xKTAGlyi5h89lQ4eoInSRaVvM52dEj0uQ6ZX2MPNGQcOF7AuqMjnTdUILvDJI4d9gjXtCLlT13UiuTo7BSOXUzDsddRH29C2ItxkmMRRpYw1lMMK6VMUsF+JvBDOIogx7OczgtMgq/JHcCrQbNp8PV97kMd05nlFIr7+vkFhdN99ZDqqkVc6oAJXGwcwkk5Sq1K6EUcZjHsy6TJPR2wUqziTCHwTJBHPIbFBoILkRDmsDIvygT7uSDmgRakRSqCrEgD6oXshGHFqifyolUETMUFCJTvWNDegLzDivWwqHYwQo9iOI00iuI4XniyaZSU3jHQKGqVH5lGlTbNZkWe/Q6otGM+ZVrOSWZaC2AUa3pbt6we4artVtcwsDaZl4jhmQKbeRnJbJiXCLCkxEdgXsS69jQcRLw2AcmGelg/Bes6aId1BVwY1mX8npFYbtXzeVRgXaV0XmISEE1ukXg8iEU5YD4F7dIIdpjQb6t0YFGLdOHBuOhYVDxLwNjW2SVcb5pH17RQddhDdh6r+B387uDuOljZQ3YR6TtsG+kH6q5gz5ogHk27pmYXRcLzjKbMouI9XTCfKrcQPIRx53wugiCx6ZkRWPxNF6kIJmZ0hey+y11PtkQujGYFBAy5WMPEoD0J/EjTQIymeeVMHnGiZvqhwtz0eDHxTkqce14irF9uDNvmd+qhvv308zOhr5ttgV7MNcNrKc7tsLPwofwLD3BP9o7finrER69wjXi37xAEojSNTNi71mXO5YZtTrYEk27KwrlwmJPvuEr74Xl8rDCxuzw+7CciVZO4xE3834SHWIcHWIOvULGrLAR+E/9DHOujiZP4XwbCh+xY4+CgEUIKK6htBDOJgoc+T9zpQKyNgq8CJK7eI17CstelFclJ16YmhKaKY5PnEJG98UklM4lki0TyJJwKo+K2prJlTb/KMB9pqNfEIZvRZvU0FH703eqYUPimtv8FFfTaaBqMKUPhp9Qqnh21cgs7nzl52+dwrKu0sfuMzKu0tROn7KshFg5voQSSTm+wiRvox5z0fpbKsKzY2Z02KNkJj5DjYhMXG+w0RD4NJztmvjEnwXEwQt+OdBvBzILjLbKN2ti4fmA0UHRjmH1OOCXzK2caEx0vrUfqg7eIwpEgQ4aTNDpd9Z1dov2ucNFkSMNjvrMzgornHR0DrHzZGAQ+l3CH5EXyTw2H5Y4GQYQpVcqlvjyu5KR1Ka6rMEflPxiZk/INCmVuZHN0cmVhbQ1lbmRvYmoNNSAwIG9iag08PC9OdW1zWzA8PC9TL0Q+PjI8PC9TL0QvU3QgMz4+XT4+DWVuZG9iag02IDAgb2JqDTw8L0NvdW50IDMvS2lkc1sxMiAwIFIgMSAwIFIgMyAwIFJdL1R5cGUvUGFnZXM+Pg1lbmRvYmoNNyAwIG9iag08PC9MZW5ndGggMzc0Ny9TdWJ0eXBlL1hNTC9UeXBlL01ldGFkYXRhPj5zdHJlYW0NCjw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDkuMS1jMDAxIDc5LjY3NWQwZjcsIDIwMjMvMDYvMTEtMTk6MjE6MTYgICAgICAgICI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6cGRmYWlkPSJodHRwOi8vd3d3LmFpaW0ub3JnL3BkZmEvbnMvaWQvIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOnBkZj0iaHR0cDovL25zLmFkb2JlLmNvbS9wZGYvMS4zLyIKICAgICAgICAgICAgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iPgogICAgICAgICA8ZGM6Zm9ybWF0PmFwcGxpY2F0aW9uL3BkZjwvZGM6Zm9ybWF0PgogICAgICAgICA8ZGM6dGl0bGU+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPnRpdGxlPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkFsdD4KICAgICAgICAgPC9kYzp0aXRsZT4KICAgICAgICAgPGRjOmNyZWF0b3I+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpPmF1dGhvcjwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwvZGM6Y3JlYXRvcj4KICAgICAgICAgPGRjOmRlc2NyaXB0aW9uPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij5zdWJqZWN0PC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkFsdD4KICAgICAgICAgPC9kYzpkZXNjcmlwdGlvbj4KICAgICAgICAgPHBkZmFpZDpwYXJ0PjE8L3BkZmFpZDpwYXJ0PgogICAgICAgICA8cGRmYWlkOmNvbmZvcm1hbmNlPkI8L3BkZmFpZDpjb25mb3JtYW5jZT4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BcGFjaGUgRk9QIFZlcnNpb24gMi44PC94bXA6Q3JlYXRvclRvb2w+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDI0LTA0LTAzVDEwOjM0OjM3WjwveG1wOkNyZWF0ZURhdGU+CiAgICAgICAgIDx4bXA6TW9kaWZ5RGF0ZT4yMDI0LTA0LTAzVDEyOjM2OjExKzAyOjAwPC94bXA6TW9kaWZ5RGF0ZT4KICAgICAgICAgPHhtcDpNZXRhZGF0YURhdGU+MjAyNC0wNC0wM1QxMjozNjoxMSswMjowMDwveG1wOk1ldGFkYXRhRGF0ZT4KICAgICAgICAgPHBkZjpQcm9kdWNlcj5BcGFjaGUgRk9QIFZlcnNpb24gMi44PC9wZGY6UHJvZHVjZXI+CiAgICAgICAgIDx4bXBNTTpEb2N1bWVudElEPnV1aWQ6YWJhNGY3YTMtNTI1Yi00MDIxLThmYmQtOTY1MTFlMDJkZTVhPC94bXBNTTpEb2N1bWVudElEPgogICAgICAgICA8eG1wTU06SW5zdGFuY2VJRD51dWlkOmMyNDdjMjhhLTM2YzgtNGI3MS1hNzgyLWMwZWMzYTMyY2JhMDwveG1wTU06SW5zdGFuY2VJRD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/Pg0KZW5kc3RyZWFtDWVuZG9iag04IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjU5NC9OIDM+PnN0cmVhbQ0KeF6dlmdUU9kWx8+9N71QkhCKlNBrqAIBpPcmRYogCiEJEEqIIQF7QUQFRhQVaYoggwIOODoCMlZEsTAgqNidIIOIOg6OYkPlJbLW6JvX5s3/w72/tc/e555dzloXAFJACF+QDSsBkCUQiyL9vRgL4+IZ2H4AAzzAABsA2JwcYegCvyggU6CvNyNH5gT+Sa+HASR/X2MGhDMY4P+TMkcoEgMAhcvYjsvL4ci4QMaZeWKh3D4pY1pyhpxhlJxFsgPKWE3OqbNs8dlnlj3kzM0ScGUsP7OQm8WVc4+MN+dKeDJGQmRcmMvn5cn4uowNMiVZfBm/lcdm8dg5AKBIcruYx0mTsbWMSaKoSG8ZzwMAR0r9ipO/YjFvmVielHe2cLmIn5omZphwTBk2Tk4sRgAvL5MnFjPD2ZwMtojL8M7OErIFywGYzfmzKPLaMmRFdrBxcnBg2lrafKnTf1/8i5L3dpZeRnzuGUTv+2L7d37Z9QCwpmS12fbFllwJQMdGANTufLEZ7ANAUda39oGv8qHL5yVNLBY6W1nl5eVZ8nkcS3lB/9D/dPgL+up7lvLt/igPw4eXwpZkihnyunGyM7MlIkaOkM3hMZh/HuK/HfiVvjqHRSQvhSfiCWQRMbIp4wtSZe0WcPlifraAwRf8pyb+zbA/aXauZaI2fAK0REugNEADyK99AEUlAiRhr2wF+qNvIfgYIL95sTrjs3P/WdC/7gqXyh85/NTPcd6RUQyORJQ7uya/lgANCEAR0IA60Ab6wAQwgS1wBC7AA/iCIBAGokAcWAI4IA1kARHIA6vAelAIisE2sAtUgVrQAJpAKzgCOsAJcBZcAFfAVXAD3AVSMAaegknwGkxDEISFyBAVUod0IEPIHLKFWJAb5AuFQJFQHJQEpUICSAKtgjZAxVAZVAXVQU3Q99Bx6Cx0CRqEbkMj0AT0O/QeRmASTIO1YCPYCmbBnnAwHAUvhlPhpfAKuADeClfA9fAhuB0+C1+Bb8BS+Ck8hQCEiNARXYSJsBBvJAyJR1IQEbIGKULKkXqkFelCepFriBR5hrxDYVBUFAPFRLmgAlDRKA5qKWoNqgRVhTqIakf1oK6hRlCTqE9oMloTbY52RgeiF6JT0XnoQnQ5uhF9DH0efQM9hn6NwWDoGGOMIyYAE4dJx6zElGD2YNowZzCDmFHMFBaLVceaY12xYVg2VowtxFZiD2FPY4ewY9i3OCJOB2eL88PF4wS4fFw5rhl3CjeEG8dN45XwhnhnfBiei1+OL8U34LvwA/gx/DRBmWBMcCVEEdIJ6wkVhFbCecI9wksikahHdCJGEPnEdcQK4mHiReII8R2JQjIjeZMSSBLSVtIB0hnSbdJLMplsRPYgx5PF5K3kJvI58gPyWwWqgqVCoAJXYa1CtUK7wpDCc0W8oqGip+ISxRWK5YpHFQcUnynhlYyUvJXYSmuUqpWOK91UmlKmKtsohylnKZcoNytfUn5MwVKMKL4ULqWAsp9yjjJKRaj6VG8qh7qB2kA9Tx2jYWjGtEBaOq2Y9h2tnzapQlGZqxKjskylWuWkipSO0I3ogfRMein9CH2Y/l5VS9VTlae6RbVVdUj1jdocNQ81nlqRWpvaDbX36gx1X/UM9e3qHer3NVAaZhoRGnkaezXOazybQ5vjMoczp2jOkTl3NGFNM81IzZWa+zX7NKe0tLX8tYRalVrntJ5p07U9tNO1d2qf0p7Qoeq46fB1duqc1nnCUGF4MjIZFYwexqSupm6ArkS3Trdfd1rPWC9aL1+vTe++PkGfpZ+iv1O/W3/SQMcg1GCVQYvBHUO8IcswzXC3Ya/hGyNjo1ijTUYdRo+N1YwDjVcYtxjfMyGbuJssNak3uW6KMWWZZpjuMb1qBpvZm6WZVZsNmMPmDuZ88z3mgxZoCycLgUW9xU0mienJzGW2MEcs6ZYhlvmWHZbPrQys4q22W/VafbK2t860brC+a0OxCbLJt+my+d3WzJZjW2173Y5s52e31q7T7sVc87m8uXvn3rKn2ofab7Lvtv/o4Oggcmh1mHA0cExyrHG8yaKxwlklrItOaCcvp7VOJ5zeOTs4i52POP/mwnTJcGl2eTzPeB5vXsO8UVc9V7ZrnavUjeGW5LbPTequ6852r3d/6KHvwfVo9Bj3NPVM9zzk+dzL2kvkdczrjbez92rvMz6Ij79PkU+/L8U32rfK94Gfnl+qX4vfpL+9/0r/MwHogOCA7QE3A7UCOYFNgZNBjkGrg3qCScELgquCH4aYhYhCukLh0KDQHaH35hvOF8zvCANhgWE7wu6HG4cvDf8xAhMRHlEd8SjSJnJVZO8C6oLEBc0LXkd5RZVG3Y02iZZEd8coxiTENMW8ifWJLYuVLrRauHrhlTiNOH5cZzw2Pia+MX5qke+iXYvGEuwTChOGFxsvXrb40hKNJZlLTiYqJrITjyahk2KTmpM+sMPY9eyp5MDkmuRJjjdnN+cp14O7kzvBc+WV8cZTXFPKUh6nuqbuSJ1Ic08rT3vG9+ZX8V+kB6TXpr/JCMs4kDGTGZvZloXLSso6LqAIMgQ92drZy7IHhebCQqF0qfPSXUsnRcGixhwoZ3FOp5gm+5nqk5hINkpGct1yq3Pf5sXkHV2mvEywrG+52fIty8dX+K34diVqJWdl9yrdVetXjaz2XF23BlqTvKZ7rf7agrVj6/zXHVxPWJ+x/qd86/yy/FcbYjd0FWgVrCsY3ei/saVQoVBUeHOTy6bazajN/M39W+y2VG75VMQtulxsXVxe/KGEU3L5G5tvKr6Z2Zqytb/UoXTvNsw2wbbh7e7bD5Ypl60oG90RuqN9J2Nn0c5XuxJ3XSqfW167m7BbsltaEVLRWWlQua3yQ1Va1Y1qr+q2Gs2aLTVv9nD3DO312Ntaq1VbXPt+H3/frTr/uvZ6o/ry/Zj9ufsfNcQ09H7L+rapUaOxuPHjAcEB6cHIgz1Njk1NzZrNpS1wi6Rl4lDCoavf+XzX2cpsrWujtxUfBoclh598n/T98JHgI91HWUdbfzD8oeYY9VhRO9S+vH2yI61D2hnXOXg86Hh3l0vXsR8tfzxwQvdE9UmVk6WnCKcKTs2cXnF66ozwzLOzqWdHuxO7755beO56T0RP//ng8xcv+F041+vZe/qi68UTl5wvHb/MutxxxeFKe59937Gf7H861u/Q3z7gONB51elq1+C8wVND7kNnr/lcu3A98PqVG/NvDA5HD9+6mXBTeot76/HtzNsv7uTemb677h76XtF9pfvlDzQf1P9s+nOb1EF6csRnpO/hgod3RzmjT3/J+eXDWMEj8qPycZ3xpse2j09M+E1cfbLoydhT4dPpZ4W/Kv9a89zk+Q+/efzWN7lwcuyF6MXM7yUv1V8eeDX3VfdU+NSD11mvp98UvVV/e/Ad613v+9j349N5H7AfKj6afuz6FPzp3kzWzMw/APeE8/sNCmVuZHN0cmVhbQ1lbmRvYmoNOSAwIG9iag08PC9BdXRob3IoYXV0aG9yKS9DcmVhdGlvbkRhdGUoRDoyMDI0MDQwMzEwMzQzN1opL0NyZWF0b3IoQXBhY2hlIEZPUCBWZXJzaW9uIDIuOCkvTW9kRGF0ZShEOjIwMjQwNDAzMTIzNjExKzAyJzAwJykvUHJvZHVjZXIoQXBhY2hlIEZPUCBWZXJzaW9uIDIuOCkvU3ViamVjdChzdWJqZWN0KS9UaXRsZSh0aXRsZSk+Pg1lbmRvYmoNeHJlZg0KMCAxMA0KMDAwMDAwMDAwMCA2NTUzNSBmDQowMDAwMDg3OTgxIDAwMDAwIG4NCjAwMDAwODgxNjMgMDAwMDAgbg0KMDAwMDA5MzIyNiAwMDAwMCBuDQowMDAwMDkzNDA4IDAwMDAwIG4NCjAwMDAwOTU2OTQgMDAwMDAgbg0KMDAwMDA5NTc0NCAwMDAwMCBuDQowMDAwMDk1ODA4IDAwMDAwIG4NCjAwMDAwOTk2MzIgMDAwMDAgbg0KMDAwMDEwMjMwMCAwMDAwMCBuDQp0cmFpbGVyDQo8PC9TaXplIDEwL0lEWzw0RTU0NUE1MTMxNDk1ODU1NDQ1MjUwMzE0RDQxNEE1QT48NzE1REY4QTU3OUYwNDk0M0JFNEQ4MTU5Qjg2OENDN0U+XT4+DQpzdGFydHhyZWYNCjExNg0KJSVFT0YNCg==
                  </value>
                </observationMedia>
              </component>
            </organizer>
          </entry>
        </section>
      </component>
  
    </structuredBody>
  </component>
</ClinicalDocument>
```

