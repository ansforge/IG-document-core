# null - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## : null - JSON Representation

[Raw json](Binary-BIO-CR-BIO-2024.01-Microbiologie-V1.json) | [Download](Binary-BIO-CR-BIO-2024.01-Microbiologie-V1.json)

