# Mapping Métier/CDA/FHIR : "Système / Structure Auteur" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Système / Structure Auteur"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingSystemeFHIR.xml.md) 
*  [JSON](ConceptMap-mappingSystemeFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Système / Structure Auteur" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingSystemeFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-02 | *Computable Name*:Mapping Métier/CDA/FHIR : "Système / Structure Auteur" |

 
Ce ConceptMap de l’élément SystemeStructureAuteur présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "SystemeStructureAuteur" et l’élément CDA "assignedAuthor"
* Mapping 2 : entre l’élément CDA "assignedAuthor" et le profil FHIR "FrDeviceDocument"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Systeme` to [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md)

* **Source Code**: Systeme.identificationAuteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor
* **Source Code**: Systeme.identificationAuteur.identifiantAuteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.id
* **Source Code**: Systeme.identificationAuteur.professionSavoirFaireRole
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.code
* **Source Code**: Systeme.identificationAuteur.systeme
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedAuthoringDevice
* **Source Code**: Systeme.identificationAuteur.systeme.nomModeleSysteme
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedAuthoringDevice.manufacturerModelName
* **Source Code**: Systeme.identificationAuteur.systeme.nomSysteme
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.assignedAuthoringDevice.softwareName
* **Source Code**: Systeme.identificationAuteur.structure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization
* **Source Code**: Systeme.identificationAuteur.structure.identifiantStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.id
* **Source Code**: Systeme.identificationAuteur.structure.nomStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.name
* **Source Code**: Systeme.identificationAuteur.structure.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.addr
* **Source Code**: Systeme.identificationAuteur.structure.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: assignedAuthor.representedOrganization.telecom

-------

**Group 2**Mapping from [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md) to `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-device-document`

* **Source Code**: assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device
  * **Commentaire**: 
* **Source Code**: assignedAuthor.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.identifier
  * **Commentaire**: 
* **Source Code**: assignedAuthor.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.type
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedAuthoringDevice.manufacturerModelName
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.deviceName.name
  * **Commentaire**: 
* **Source Code**: assignedAuthor.assignedAuthoringDevice.softwareName
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.deviceName.type
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.owner.organization
  * **Commentaire**: Device.owner.organization.resolve().ofType(Organization)
* **Source Code**: assignedAuthor.representedOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.owner.organization.identifier
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.owner.organization.name
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.owner.organization.address
  * **Commentaire**: 
* **Source Code**: assignedAuthor.representedOrganization.telecomm
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Device.owner.organization.telecom
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingStructureConservationCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingSystemeFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

