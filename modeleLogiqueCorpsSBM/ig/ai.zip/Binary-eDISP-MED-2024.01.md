# eDISP-MED-2024.01 - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eDISP-MED-2024.01**

## Example Binary: eDISP-MED-2024.01

```

<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="../FeuilleDeStyle/CDA-FO.xsl"?>
<?oxygen SCHSchema="../schematrons/profils/IHE.sch"?>
<?oxygen SCHSchema="../schematrons/profils/structurationMinimale/ASIP-STRUCT-MIN-StrucMin.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_ModelesDeContenusCDA.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_Modeles_ANS.sch"?>
<?oxygen SCHSchema="../schematrons/profils/terminologies/schematron/terminologie.sch"?> 
<?oxygen SCHSchema="../schematrons/CI-SIS_eDISP-MED_2024.01.sch"?>

<!-- 
    **********************************************************************************************************
    Document : eDispensation de médicaments (eDISP-MED_2024.01)
    Auteur : ANS
    **********************************************************************************************************
    format HL7 - CDA Release 2 - selon schéma XML (CDA.xsd) du standard ANSI/HL7 CDA, R2-2005 4/21/2005
    **********************************************************************************************************
    Notes:
    17/06/2024 : Création exemple
    21/08/2025 : MAJ des références entre parties narratives et entrées
    **********************************************************************************************************
-->

<ClinicalDocument xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="urn:hl7-org:v3 ../infrastructure/cda/CDA_extended.xsd" xmlns="urn:hl7-org:v3" xmlns:pharm="urn:ihe:pharm:medication">
    
    <!-- 
    ********************************************************
    *              En-tête du document                     *
    ********************************************************
    -->
    <!-- Périmètre d'utilisation -->
    <realmCode code="FR"/>
    <!-- Référence au standard CDA R2 -->
    <typeId root="2.16.840.1.113883.1.3" extension="POCD_HD000040"/>
    <!-- Conformité spécifications HL7 France -->
    <templateId root="2.16.840.1.113883.2.8.2.1"/>
    <!-- Conformité spécifications au CI-SIS -->
    <templateId root="1.2.250.1.213.1.1.1.1"/>
    <!-- Conformité au volet IHE PCC -->
    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.1"/>
    <!-- Conformité au Volet Community Dispense (IHE PHARM DIS) -->
    <templateId root="1.3.6.1.4.1.19376.1.9.1.1.3"/>
    <!-- Conformité au modèle de document eDISP-MED_2024.01 -->
    <templateId root="1.2.250.1.213.1.1.1.54" extension="2024.01"/>  
    <!-- Identifiant du document CDA -->
    <id root="1.2.250.1.213.1.1.1.54.2024.1.1"/>
    <!-- Type de document -->
    <code code="60593-1" displayName="Dispensation médicamenteuse" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
    <!-- Titre du document -->
    <title>Dispensation médicamenteuse</title>
    <!-- Date de création du document = Date de rédaction de la prescription -->
    <effectiveTime value="20241225093000+0100"/>
    <!-- Niveau de confidentialité du document -->
    <confidentialityCode code="N" codeSystem="2.16.840.1.113883.5.25" displayName="Normal"/>
    <!-- Langue du document -->
    <languageCode code="fr-FR"/>
    <!-- Identifiant commun à toutes les versions successives du document -->
    <setId root="1.2.250.1.213.1.1.1.54.2024.1"/>
    <!-- Numéro de la version du présent document (entier positif) -->
    <versionNumber value="1"/>
    <!-- [1..1] Patient -->
    <recordTarget>
        <patientRole>
            <!-- INS-NIR de production : 1.2.250.1.213.1.4.8 -->
            <id extension="277076322082910" root="1.2.250.1.213.1.4.8"/>
            <!-- IPP du patient dans l'établissement avec root = l'OID de l'ES -->
            <id extension="1234567890121" root="1.2.3.4.567.8.9.10"/>
            <!-- Adresse du patient -->
            <addr>
                <houseNumber>28</houseNumber>
                <streetName>Avenue de Breteuil</streetName>
                <unitID>Escalier A</unitID>
                <postalCode>75007</postalCode>
                <city>PARIS</city>
                <country>FRANCE</country>
            </addr>
            <!-- Coordonnées télécom du patient -->
            <telecom value="tel:0144534551" use="H"/>
            <telecom value="tel:0647151010" use="MC"/>
            <telecom value="mailto:277076322082910@patient.mssante.fr"/>
            <!-- Identité du patient -->
            <patient classCode="PSN">
                <name>
                    <given qualifier="BR">RUTH</given>
                    <given>ISABELLE</given>
                    <family qualifier="BR">NESSI</family>
                    <family qualifier="CL">DECOURCY</family>
                </name>
                <administrativeGenderCode code="F" displayName="Féminin" codeSystem="2.16.840.1.113883.5.1"/>
                <birthTime value="19770714"/>
                <!-- Représentant du patient -->
                <guardian>
                    <addr use="H">
                        <houseNumber>28</houseNumber>
                        <streetNameType>Av</streetNameType>
                        <streetName>de Breteuil</streetName>
                        <additionalLocator nullFlavor="NA"/>
                        <postalCode>75007</postalCode>
                        <city>PARIS</city>
                        <country>FRANCE</country>
                    </addr>
                    <telecom value="tel:0147150000" use="H"/>
                    <guardianPerson>
                        <name>
                            <prefix>MME</prefix>
                            <family>NESSI</family>
                            <given>Jeanne</given>
                        </name>
                    </guardianPerson>
                </guardian>
                <!-- Lieu de naissance du patient -->
                <birthplace>
                    <place>
                        <addr>
                            <county>51215</county>
                            <city>DOMPREMY</city>
                        </addr>
                    </place>
                </birthplace>
            </patient>
        </patientRole>
    </recordTarget>
    
    <!-- [1..1] Auteur du document : Dossier Pharmaceutique -->
    <author>
        <!-- [1..1] Date et heure de création du document par le DP -->
        <time value="20241225093000+0100"/>
        <!-- [1..1] Identification de l'auteur -->
        <assignedAuthor>
            <!-- Identifiant du DP -->
            <id root="1.2.250.1.71.4.2.1" extension="578435954900010/1.2.250.1.176.1"/> 
            <code code="DISPOSITIF" displayName="Dispositif médical" codeSystem="1.2.250.1.213.1.1.4.6"/>
            <!-- Système : DP -->
            <assignedAuthoringDevice>
                <!-- Identifiant du DP -->
                <manufacturerModelName>.</manufacturerModelName>
                <softwareName>Dossier Pharmaceutique</softwareName>
            </assignedAuthoringDevice>
            <!-- Structure : CNOP -->
            <representedOrganization>
                <!-- Identifiant du CNOP -->
                <id root="1.2.250.1.71.4.2.2" extension="378435954900010"/>
                <name>CONSEIL NATIONAL ORDRE DES PHARMACIENS</name>
            </representedOrganization>
        </assignedAuthor>
    </author>
    
    <!-- [1..1] Auteur du document : Pharmacien dispensateur -->
    <author>
        <!-- [1..1] Date et heure de création du document par le DP -->
        <time value="20241225093000+0100"/>
        <!-- [1..1] Identification de l'auteur -->
        <assignedAuthor>
            <!-- Identifiant du Pharmacien dispensateur -->
            <id root="1.2.250.1.71.4.2.1" extension="807505123456"/> 
            <code code="G15_21" displayName="Pharmacien" codeSystem="1.2.250.1.213.1.1.4.5"/>
            <assignedPerson>
                <name>
                    <prefix>M</prefix>
                    <given>Pierre</given>
                    <family>DELIVE</family>
                    <suffix>PG</suffix>
                </name>
            </assignedPerson>
            <!-- Structure : Pharmacie -->
            <representedOrganization>
                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                <name>Pharmacie du village</name>
                <!-- [0..*] Coordonnées Télécom Structure -->
                <telecom value="tel:0142726071" use="WP"/>
                <!-- [0..*] Adresse Structure -->
                <addr>
                    <houseNumber>26</houseNumber>
                    <streetName>Rue Temple</streetName>
                    <postalCode>75004</postalCode>
                    <city>Paris</city>
                </addr>
                <!-- Cadre d'exercice : Valeur issue du JDV_J04-XdsPracticeSettingCode-CISIS (1.2.250.1.213.1.1.5.467) -->
                <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
                    codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="practiceSettingCode"/>
            </representedOrganization>
        </assignedAuthor>
    </author>
    
    <!-- [1..1] Structure chargée de la conservation du document : CONSEIL NATIONAL ORDRE DES PHARMACIENS -->
    <custodian>
        <assignedCustodian>
            <representedCustodianOrganization>
                <!-- Identifiant du DP -->
                <id root="1.2.250.1.71.4.2.2" extension="378435954900010"/>
                <!-- Nom de l'organisation -->
                <name>CONSEIL NATIONAL ORDRE DES PHARMACIENS</name>                  
            </representedCustodianOrganization>
        </assignedCustodian>
    </custodian>
    
    <!-- [1..1] Responsable du document : Dossier Pharmaceutique -->
    <legalAuthenticator>
        <!-- Date et heure de la prise de responsabilité -->
        <time value="20241225093000+0100"/>
        <signatureCode code="S"/>
        <assignedEntity>
            <!-- Identifiant du responsable : Dossier Pharmaceutique -->
            <id root="1.2.250.1.71.4.2.1" extension="578435954900010/1.2.250.1.176.1"/>          
            <!-- Responsable : Dossier Pharmaceutique -->
            <assignedPerson>
                <name>
                    <family>Dossier pharmaceutique</family>
                    <given>.</given>
                </name>
            </assignedPerson>
            <!-- Structure : CONSEIL NATIONAL ORDRE DES PHARMACIENS --> 
            <representedOrganization>
                <id root="1.2.250.1.71.4.2.2" extension="378435954900010"/>
                <name>CONSEIL NATIONAL ORDRE DES PHARMACIENS</name>        
            </representedOrganization>
        </assignedEntity>
    </legalAuthenticator>
    
    <!-- [0..1] Participant : prescripteur -->
    <participant typeCode="REF">
        <!-- Date de la prescription -->
        <time>
            <low value="20211201093000+0100"/>
        </time>       
        <associatedEntity classCode="PROV">
            <!-- [1..1] PS identifié par son N°RPPS -->
            <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
            <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
            <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
                codeSystem="1.2.250.1.213.1.1.4.5"/>
            <!-- [0..*] Adresse du PS -->
            <addr>
                <houseNumber>25</houseNumber>
                <streetName>Rue Berthollet</streetName>
                <postalCode>75005</postalCode>
                <city>PARIS</city>
            </addr>
            <!-- [0..*] Télécom du PS -->
            <telecom value="tel:0158432300" use="WP"/>
            <!-- [0..1] Identité du PS -->
            <associatedPerson>
                <name>
                    <prefix>M</prefix>
                    <given>Romain</given>
                    <family>PIOU</family>
                    <suffix>DR</suffix>
                </name>
            </associatedPerson>
            <!-- [1..1] Organisation de rattachement du PS -->
            <scopingOrganization>
                <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                <!-- [1..1] Nom de l'organisation de rattachement du PS -->
                <name>Cabinet du DR Pierre JOLI</name>        
                <!-- [0..*] Télécom du PS -->
                <telecom value="tel:0158432300" use="WP"/>
                <!-- [0..*] Adresse du PS -->
                <addr>
                    <houseNumber>25</houseNumber>
                    <streetName>Rue Berthollet</streetName>
                    <postalCode>75005</postalCode>
                    <city>PARIS</city>
                </addr>
            </scopingOrganization>
        </associatedEntity>    
    </participant>
    
    <!-- [0..1] Participant : prescripteur remplacé -->
    <participant typeCode="REF">
        <functionCode code="353" displayName="Membre de l'équipe de soins" codeSystem="1.2.250.1.213.1.6.1.107"/>
        <time nullFlavor="UNK"/>      
        <associatedEntity classCode="PROV">
            <!-- [1..1] PS identifié par son N°RPPS -->
            <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
            <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
            <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
                codeSystem="1.2.250.1.213.1.1.4.5"/>
            <!-- [0..*] Adresse du PS -->
            <addr>
                <houseNumber>25</houseNumber>
                <streetName>Rue Berthollet</streetName>
                <postalCode>75005</postalCode>
                <city>PARIS</city>
            </addr>
            <!-- [0..*] Télécom du PS -->
            <telecom value="tel:0158432300" use="WP"/>
            <!-- [0..1] Identité du PS -->
            <associatedPerson>
                <name>
                    <prefix>M</prefix>          
                    <given>Pierre</given>
                    <family>JOLI</family>
                    <suffix>DR</suffix>
                </name>
            </associatedPerson>
            <!-- [1..1] Organisation de rattachement du PS -->
            <scopingOrganization>
                <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                <!-- [1..1] Nom de l'organisation de rattachement du PS -->
                <name>Cabinet du DR Pierre JOLI</name>        
                <!-- [0..*] Télécom du PS -->
                <telecom value="tel:0158432300" use="WP"/>
                <!-- [0..*] Adresse du PS -->
                <addr>
                    <houseNumber>25</houseNumber>
                    <streetName>Rue Berthollet</streetName>
                    <postalCode>75005</postalCode>
                    <city>PARIS</city>
                </addr>
            </scopingOrganization>
        </associatedEntity>    
    </participant>
    
    <!-- [0..*] Association du document à une prescription -->
    <inFulfillmentOf>
        <order>   
            <!-- Identifiant <id> de la prescription CDA -->
            <id root="1.2.250.1.213.1.1.1.39.1.1"/>
        </order>
    </inFulfillmentOf>
    
    <!-- [1..1] Evènement documenté : dispensation -->
    <documentationOf>
        <serviceEvent>    
            <!-- Identifiant EPU de la dispensation et/ou autre identifiant (LAD, DP) -->
            <id root="FC146494-9805-11ED-A8FC-0242AC120002"/>
            <!-- Code évènement documenté -->
            <code code="60593-1" displayName="Dispensation médicamenteuse" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
            <!-- Date et heure de la dispensation -->
            <effectiveTime>
                <low value="20241225090000+0100"/>        
            </effectiveTime>      
            <!-- Pharmacien dispensateur -->
            <performer typeCode="PRF">
                <assignedEntity>
                    <!-- Pharmacien identifié par son N°RPPS -->
                    <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
                    <!-- [1..1] Profession / spécialité du PS : Valeur issue du JDV_J01-XdsAuthorSpecialty-CISIS (1.2.250.1.213.1.1.5.461) -->
                    <code code="G15_21/A" displayName="Pharmacien titulaire d'officine" codeSystem="1.2.250.1.213.1.1.4.5"/>
                    <!-- Adresse du pharmacien -->
                    <addr>
                        <houseNumber>26</houseNumber>
                        <streetName>Rue Temple</streetName>
                        <postalCode>75004</postalCode>
                        <city>Paris</city>
                    </addr>
                    <!-- Coordonnées télécom du pharmacien-->
                    <telecom value="tel:0142726071" use="WP"/>
                    <!-- Identité du pharmacien -->
                    <assignedPerson>
                        <name>
                            <prefix>M</prefix>
                            <given>Pierre</given>
                            <family>DELIVE</family>
                            <suffix>PG</suffix>
                        </name>
                    </assignedPerson>
                    <!-- Structure : Pharmacie -->
                    <representedOrganization>
                        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                        <name>Pharmacie du village</name>
                        <!-- [0..*] Coordonnées Télécom Structure -->
                        <telecom value="tel:0142726071" use="WP"/>
                        <!-- [0..*] Adresse Structure -->
                        <addr>
                            <houseNumber>26</houseNumber>
                            <streetName>Rue Temple</streetName>
                            <postalCode>75004</postalCode>
                            <city>Paris</city>
                        </addr>
                        <!-- Cadre d'exercice : Valeur issue du JDV_J04-XdsPracticeSettingCode-CISIS (1.2.250.1.213.1.1.5.467) -->
                        <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
                            codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="practiceSettingCode"/>
                    </representedOrganization>
                </assignedEntity>
            </performer>
        </serviceEvent>
    </documentationOf>
        
    <!-- [1..1] Contexte de la prise en charge -->
    <componentOf>
        <encompassingEncounter>
            <!-- Type de prise en charge : Valeur issue du JDV_J142-TypeRencontre-CISIS (1.2.250.1.213.1.1.5.589) -->
            <code code="AMB" displayName="Ambulatoire (hors établissement)" codeSystem="2.16.840.1.113883.5.4"/>
            <!-- Date et heure de la dispensation -->
            <effectiveTime>
                <high value="20241225090000+0100"/>
            </effectiveTime>
            <!-- Responsable de la prise en charge : Pharmacien -->
            <responsibleParty>
                <assignedEntity>
                    <!-- Pharmacien identifié par son N°RPPS -->
                    <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
                    <!-- [1..1] Profession / spécialité du PS : Valeur issue du JDV_J01-XdsAuthorSpecialty-CISIS (1.2.250.1.213.1.1.5.461) -->
                    <code code="G15_21/A" displayName="Pharmacien titulaire d'officine" codeSystem="1.2.250.1.213.1.1.4.5"/>
                    <!-- Adresse du pharmacien -->
                    <addr>
                        <houseNumber>26</houseNumber>
                        <streetName>Rue Temple</streetName>
                        <postalCode>75004</postalCode>
                        <city>Paris</city>
                    </addr>
                    <!-- Coordonnées télécom du pharmacien-->
                    <telecom value="tel:0142726071" use="WP"/>
                    <!-- Identité du pharmacien -->
                    <assignedPerson>
                        <name>
                            <prefix>M</prefix>
                            <given>Pierre</given>
                            <family>DELIVE</family>
                            <suffix>PG</suffix>
                        </name>
                    </assignedPerson>
                    <!-- Structure : Pharmacie -->
                    <representedOrganization>
                        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                        <name>Pharmacie du village</name>
                        <!-- [0..*] Coordonnées Télécom Structure -->
                        <telecom value="tel:0142726071" use="WP"/>
                        <!-- [0..*] Adresse Structure -->
                        <addr>
                            <houseNumber>26</houseNumber>
                            <streetName>Rue Temple</streetName>
                            <postalCode>75004</postalCode>
                            <city>Paris</city>
                        </addr>
                        <!-- Cadre d'exercice : Valeur issue du JDV_J04-XdsPracticeSettingCode-CISIS (1.2.250.1.213.1.1.5.467) -->
                        <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
                            codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="practiceSettingCode"/>
                    </representedOrganization>
                </assignedEntity>
            </responsibleParty>
            <!-- Lieu de la prise en charge : Pharmacie -->
            <location>
                <healthCareFacility>
                    <!-- Modalité d’exercice : Valeur issue du JDV_J02-XdsHealthcareFacilityTypeCode-CISIS (1.2.250.1.213.1.1.5.466) -->
                    <code code="SA33" displayName="Pharmacie d'officine" codeSystem="1.2.250.1.71.4.2.4"/>
                    <location>
                        <name>Pharmacie du Temple</name>   
                        <addr>
                            <houseNumber>26</houseNumber>
                            <streetName>rue du Temple</streetName>
                            <postalCode>75004</postalCode>
                            <city>Paris</city>
                        </addr>
                    </location>
                </healthCareFacility>
            </location>
        </encompassingEncounter>
    </componentOf>
    
    <!--*********************************-->
    <!--   Corps structuré du document   -->
    <!--*********************************-->
    <component>
        <structuredBody>
            
            <!-- [1..1] Section FR-Dispensation-medicaments -->
            <component>
                <section classCode="DOCSECT" moodCode="EVN">
                    <!-- Conformité Dispense Section (IHE PHARM DIS) -->
                    <templateId root="1.3.6.1.4.1.19376.1.9.1.2.3"/>
                    <!-- Conformité Medication section (CCD) -->
                    <templateId root="2.16.840.1.113883.10.20.1.8"/>
                    <!-- Conformité FR-Dispensation-medicaments (CI-SIS) -->
                    <templateId root="1.2.250.1.213.1.1.2.236"/>
                    <id root="F28128CA-1D38-11EC-9621-0242AC130002"/>
                    <code code="60590-7" displayName="Médicaments délivrés"
                        codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                    <title>Médicaments délivrés</title>
                    <!-- Bloc narratif de la section (dispensations de médicaments sous forme textuelle) -->
                    <text>
                        <!-- Médicament 1 -->
                        <table border="0">
                            <thead>
                              <tr>
                                <th>Durée du traitement</th>
                                <th>Médicament</th>
                                <th>Quantité délivrée</th>
                                <th>Fréquence d'administration</th>                                  
                                <th>Dose</th>
                                <th>Rythme d'administration</th>
                                <th>Voie d'administration</th>
                                <th>Substitution</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr ID="med-001">                                  
                                <td><content ID="med-001-duree">du 25/01/2023 au 27/01/2023</content></td>
                                <td><content ID="med-001-delivre">PARACETAMOL VIATRIS 500 mg, comprimé plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)</content></td>
                                <td>2 Boites</td>                                  
                                <td><content ID="med-001-frequence">4 fois/j à partir du 25/01/2021 pendant 2 jours</content></td>
                                <td><content ID="med-001-dose-min">1 cp</content> à <content ID="med-001-dose-max">1 cp</content></td>
                                <td><content ID="med-001-rate-min">1500 mg/j</content> à <content ID="med-001-rate-max">3000 mg/j</content></td> 
                                <td><content ID="med-001-voie">Voie orale</content></td>                    
                                <td><content ID="med-001-substitution">Substitution par un produit générique</content></td>
                              </tr>
                              <tr>
                                <td colspan="1">Instruction au patient</td>                  
                                <td colspan="7"><content ID="med-001-instruction-patient">A prendre au cours d'un repas</content></td>
                              </tr>
                              <tr>
                                <td colspan="1">Notes du dispensateur</td>                  
                                <td colspan="7"><content ID="med-001-notes-dispensateur">J'ai averti le patient de ne pas prendre un autre médicament contenant du paracetamol.</content></td>
                              </tr>  
                            </tbody>
                        </table>
                        <br/>                        
                        <!-- Médicament 2 -->
                        <table border="0">
                            <thead>
                                <tr>
                                    <th>Durée du traitement</th>
                                    <th>Médicament</th>
                                    <th>Quantité délivrée</th>
                                    <th>Fréquence d'administration</th>                                  
                                    <th>Dose</th>
                                    <th>Rythme d'administration</th>
                                    <th>Voie d'administration</th>
                                    <th>Substitution</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr ID="med-002">                                  
                                    <td>du 25/01/2023 au 27/01/2023</td>
                                    <td><content ID="med-002-delivre">Préparation magistrale :<br/>- 30g de diprosone<br/>- 70g de Cérat Frais de Galien</content></td>
                                    <td>1 Récipient</td>
                                    <td></td>
                                    <td></td>
                                    <td></td> 
                                    <td></td>                    
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="1">Instruction au patient</td>                  
                                    <td colspan="7"><content ID="med-002-instruction-patient">Diminuer la posologie progressivement une fois la poussée traitée. Par exemple en appliquant la préparation une fois par jour pendant 5 jours, puis 1 jour sur 2 pendant 5 jours environ avant d’arrêter.</content></td>
                                </tr>
                                <tr>
                                    <td colspan="1">Notes du dispensateur</td>                  
                                    <td colspan="7"><content ID="med-002-notes-dispensateur">Préparation remise dans un flacon</content></td>
                                </tr>  
                            </tbody>
                        </table>
                    </text>
                    <!-- [1..1] Dispensateur -->
                    <author>
                        <!-- [1..1] Horodatage de la validation par l'auteur -->
                        <time value="20211201093000+0100"/>
                        <!-- [1..1] Identification de l'auteur -->
                        <assignedAuthor classCode="ASSIGNED">
                            <!-- [1..1] Identifiant de l'auteur (Id RPPS du PS obligatoire pour les PS) -->
                            <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
                            <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
                            <code code="G15_21" displayName="Pharmacien" codeSystem="1.2.250.1.213.1.1.4.5"/>
                            <!-- [0..*] Adresse du PS -->
                            <addr>
                                <houseNumber>26</houseNumber>
                                <streetName>rue du Temple</streetName>
                                <postalCode>75004</postalCode>
                                <city>Paris</city>
                            </addr>
                            <!-- [0..*] Télécom du PS -->
                            <telecom value="tel:0158432300" use="WP"/>
                            <!-- [0..1] Identité du PS -->
                            <assignedPerson>
                                <name>
                                    <prefix>M</prefix>
                                    <given>Pierre</given>
                                    <family>DELIVE</family>
                                    <suffix>PG</suffix>
                                </name>
                            </assignedPerson>
                            <!-- [1..1] Organisation de rattachement du PS : pharmacie -->
                            <representedOrganization>
                                <!-- [1..1] Identifiant de la pharmacie (FINESS) -->
                                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                                <!-- [1..1] Nom de la pharmacie -->
                                <name>Pharmacie du village</name>        
                                <!-- [0..*] Télécom de la pharmacie -->
                                <telecom value="tel:0142726071" use="WP"/>
                                <!-- [0..*] Adresse de la pharmacie -->
                                <addr>
                                    <houseNumber>26</houseNumber>
                                    <streetName>rue du Temple</streetName>
                                    <postalCode>75004</postalCode>
                                    <city>Paris</city>
                                </addr>
                            </representedOrganization>
                        </assignedAuthor>
                    </author>
                    
                    <!-- [1..*] FR-Traitement-dispense 1-->
                    <entry>
                        <supply classCode="SPLY" moodCode="EVN">
                            <!-- Conformité Supply Activity (CCD) -->
                            <templateId root="2.16.840.1.113883.10.20.1.34"/>
                            <!-- Conformité Supply Entry (IHE PCC) -->
                            <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.3"/>
                            <!-- Conformité DispenseItemEntry (IHE PHARM DIS) -->
                            <templateId root="1.3.6.1.4.1.19376.1.9.1.3.4"/>
                            <!-- Conformité FR-Traitement-dispense(CI-SIS) -->
                            <templateId root="1.2.250.1.213.1.1.3.204"/>
                            <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA9"/>
                            <text><reference value="#med-001"></reference></text>  
                            <!-- Unité issue de EDQM Packaging (30009000 "Boite")-->
                            <quantity value="2" unit="30009000"/>                            
                            <product>
                                <!-- [1..1] FR-Produit-de-sante (CI-SIS) -->
                                <manufacturedProduct classCode="MANU">
                                    <!-- Conformité Product (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.53"/>
                                    <!-- Conformité Product Entry (IHE PCC) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                                    <!-- Conformité FR-Produit-de-sante(CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.43"/>
                                    <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                                       <!-- Medicine Entry (IHE PHARM PRE)-->
                                        <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                                        <!-- Code CIS du médicament -->
                                        <code>      
                                            <originalText><reference value="#med-001-delivre"/></originalText>
                                            <!-- Code CIP du médicament -->
                                            <translation code="3400933516390" 
                                                displayName="PARACETAMOL VIATRIS 500 mg, comprimé plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)"
                                                codeSystem="1.2.250.1.213.2.3.2" codeSystemName="CIP">
                                                <originalText><reference value="#med-001-delivre"/></originalText>
                                            </translation>
                                        </code>
                                        <!-- Nom de la marque -->
                                        <name>PARACETAMOL VIATRIS 500 mg, comprimé plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)</name>                                        
                                        <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                                        <pharm:formCode code="10219000" displayName="Comprimé" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="EDQM"/>
                                        <lotNumberText>12345</lotNumberText>
                                        <pharm:expirationTime value="20321231"/>
                                        <!-- Présentation / conditionnement -->
                                        <pharm:asContent classCode="CONT">  
                                            <!-- Conditionnement (ex : boîte, ampoule) -->
                                            <pharm:containerPackagedMedicine classCode="CONT" determinerCode="INSTANCE">
                                                <!-- National package identification code or the IDMP Packaged Medicinal Product Identifier (PCID) -->
                                                <pharm:code code="3400933516390" 
                                                    displayName="PARACETAMOL VIATRIS 500 mg, comprimé plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)"
                                                    codeSystem="1.2.250.1.213.2.3.2" codeSystemName="CIP"/>
                                                <pharm:name>PARACETAMOL VIATRIS 500 mg, comprimé plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)</pharm:name>
                                                <!-- Conditionnement primaire -->
                                                <pharm:formCode code="30009000" displayName="Boîte" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="EDQM"/>
                                                <pharm:capacityQuantity value="16" unit="{Tablet}"/> 
                                            </pharm:containerPackagedMedicine>
                                        </pharm:asContent>
                                        <!-- [0..1] Équivalent générique -->
                                        <pharm:asSpecializedKind classCode="GRIC">
                                            <pharm:generalizedMedicineClass classCode="MMAT">
                                                <pharm:code code="N02BE01" displayName="paracetamol" codeSystem="2.16.840.1.113883.6.73" codeSystemName="ATC"/>
                                                <pharm:name>paracetamol</pharm:name>
                                            </pharm:generalizedMedicineClass>
                                        </pharm:asSpecializedKind>
                                        <!-- [0..*] Substances actives -->
                                        <pharm:ingredient classCode="ACTI">
                                            <pharm:quantity>
                                                <numerator xsi:type="PQ" value="500" unit="mg"/>
                                                <denominator xsi:type="PQ" value="1"/>
                                            </pharm:quantity>                    
                                            <pharm:ingredient classCode="MMAT" determinerCode="KIND">
                                                <pharm:code code="100000090270" displayName="Paracetamol" codeSystem="2.16.840.1.113883.3.6905.2" codeSystemName="SMS"/>
                                                <pharm:name>Paracetamol</pharm:name>
                                            </pharm:ingredient>
                                        </pharm:ingredient>
                                    </manufacturedMaterial>                  
                                </manufacturedProduct>
                            </product>
                            
                            <!-- [0..1] FR-Reference-item-prescription -->
                            <entryRelationship typeCode="REFR" inversionInd="false">
                                <substanceAdministration classCode="SBADM" moodCode="INT">              
                                    <!-- Conformité Prescription Item (IHE PHARM PRE) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.11"/>          
                                    <!-- Conformité  -->
                                    <templateId root="1.2.250.1.213.1.1.3.90"/>   
                                    <!-- Référence de la ligne de prescription -->
                                    <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA0"/>
                                    <code code="PREItem" displayName="Prescription Item" 
                                        codeSystem="1.3.6.1.4.1.19376.1.9.2.2"  codeSystemName="IHE Pharmacy Item Type List">
                                    </code>
                                    <consumable>
                                        <manufacturedProduct>
                                            <manufacturedMaterial nullFlavor="NA">
                                                <name nullFlavor="NA"/>
                                            </manufacturedMaterial>
                                        </manufacturedProduct>
                                    </consumable>
                                    <author>
                                        <!-- [1..1] Horodatage de la validation par l'auteur -->
                                        <time value="20211201093000+0100"/>
                                        <!-- [1..1] Identification de l'auteur -->
                                        <assignedAuthor classCode="ASSIGNED">
                                            <!-- [1..1] Identifiant de l'auteur (Id RPPS du PS obligatoire pour les PS) -->
                                            <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
                                            <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
                                            <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
                                                codeSystem="1.2.250.1.213.1.1.4.5"/>
                                            <!-- [0..*] Adresse du PS -->
                                            <addr>
                                                <houseNumber>142</houseNumber>
                                                <streetName>Rue Belvédère</streetName>
                                                <postalCode>92100</postalCode>
                                                <city>Boulogne-Billancourt</city>
                                            </addr>
                                            <!-- [0..*] Télécom du PS -->
                                            <telecom value="tel:0158432300" use="WP"/>
                                            <!-- [0..1] Identité du PS -->
                                            <assignedPerson>
                                                <name>
                                                    <given>Jacques</given>
                                                    <family>BIDEAULT</family>
                                                    <suffix>DR</suffix>
                                                </name>
                                            </assignedPerson>
                                            <!-- [1..1] Organisation de rattachement du PS -->
                                            <representedOrganization>
                                                <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
                                                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                                                <!-- [1..1] Nom de l'organisation de rattachement du PS -->
                                                <name>Clinique du Belvédère</name>       
                                                <!-- [0..*] Télécom du PS -->
                                                <telecom value="tel:0157826011" use="WP"/>
                                                <!-- [0..*] Adresse du PS -->
                                                <addr>
                                                    <houseNumber>142</houseNumber>
                                                    <streetName>Rue Belvédère</streetName>
                                                    <postalCode>92100</postalCode>
                                                    <city>Boulogne-Billancourt</city>
                                                </addr>
                                            </representedOrganization>
                                        </assignedAuthor>
                                    </author>
                                    <!-- Référence de la prescription -->
                                    <reference typeCode="XCRPT">
                                        <externalDocument>
                                            <id root="1.2.250.1.213.1.1.1.39.12345.1"/>
                                        </externalDocument>
                                    </reference>
                                </substanceAdministration>
                            </entryRelationship>   
                            
                            <!-- [0..1] Entrée FR-Instructions-au-patient -->
                            <entryRelationship typeCode="SUBJ" inversionInd="true">
                                <act classCode="ACT" moodCode="INT">
                                    <!-- Conformité Patient instructions (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.49"/>
                                    <!-- Conformité Patient Medication Instruction (IHE DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                                    <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.33"/>
                                    <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                                        codeSystemName="IHEActCode"/>
                                    <text><reference value="#med-001-instruction-patient"/></text>
                                    <statusCode code="completed"/>
                                </act>
                            </entryRelationship>
                            
                            <!-- [0..1] Entrée FR-Notes-du-dispensateur -->
                            <entryRelationship typeCode="SUBJ" inversionInd="true">
                                <act classCode="ACT" moodCode="INT">
                                    <!-- Conformité Fulfillment instructions (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.43"/>
                                    <!-- Conformité Medication fulfillment instruction (IHE DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                                    <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.207"/>
                                    <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                                        codeSystemName="IHEActCode"/>
                                    <text><reference value="#med-001-notes-dispensateur"/></text>
                                    <statusCode code="completed"/>
                                </act>
                            </entryRelationship>   
                                    
                            <!-- [0..1] FR-Traitement : Posologie (uniquement si la posologie a été modifiée) -->
                            <entryRelationship typeCode="COMP">
                                <substanceAdministration moodCode="INT" classCode="SBADM">
                                    <!-- Medication Activity (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.24"/>
                                    <!-- Medications Entry (IHE PCC) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7"/>
                                    <!-- FR-Traitement (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.42"/>
                                    <!-- Dosage Instructions (IHE PHARM DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.6"/>
                                    <!-- Mode d'administration "Normal" -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.1"/>
                                    <id root="4B007F00-973B-11ED-A8FC-0242AC120002"/>
                                    <text><reference value="#med-001-duree"></reference></text>
                                    <statusCode code="completed"/>
                                    <!-- Durée de traitement -->
                                    <effectiveTime xsi:type="IVL_TS">
                                        <low value="20230125"/>
                                        <high value="20230127"/>
                                    </effectiveTime>
                                    <!-- Fréquence d'administration : toutes les 16h (4 fois/j) à partir du 25/01/2023 pendant 2 jours -->
                                    <effectiveTime xsi:type="SXPR_TS" operator="A">
                                        <comp xsi:type="IVL_TS" operator="A">
                                            <low value="20230125"/>
                                            <width value="2" unit="d"/>
                                        </comp>
                                        <comp xsi:type="PIVL_TS" operator="A">
                                            <period value="16" unit="h">
                                                <translation>
                                                    <originalText>
                                                        <reference value="#med-001-frequence"/>
                                                    </originalText>
                                                </translation>
                                            </period>
                                        </comp>
                                    </effectiveTime>
                                    <!-- valeur issue d'EDQM Standard terms (0.4.0.127.0.16.1.1.2.1) / classe ROA (Voie d'administration) -->
                                    <routeCode code="20053000" displayName="Voie orale" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="EDQM">
                                        <originalText><reference value="#med-001-voie"/></originalText>
                                    </routeCode>                                    
                                    
                                    <!-- [0..1] Région anatomique d'administration : uniquement si posologie structurée -->
                                    <!-- valeur issue du jdv-human-substance-administration-site-cisis (1.2.250.1.213.1.1.5.686) -->
                                    <!-- <approachSiteCode> </approachSiteCode> -->                                    
                                    
                                    <!-- Dose à administrer : 2 cp -->
                                    <doseQuantity>
                                        <low value="2" unit="{tablet}">
                                            <translation>
                                                <originalText>
                                                    <reference value="#med-001-dose-min"/>
                                                </originalText>
                                            </translation>
                                        </low>
                                        <high value="2" unit="{tablet}">
                                            <translation>
                                                <originalText>
                                                    <reference value="#med-001-dose-max"/>
                                                </originalText>
                                            </translation>
                                        </high>
                                    </doseQuantity>
                                    
                                    <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
                                    <rateQuantity>
                                        <low value="1500" unit='mg/d'>
                                            <translation>
                                                <originalText>
                                                    <reference value="#med-001-rate-min"/>
                                                </originalText>
                                            </translation>
                                        </low>
                                        <high value="3000" unit='mg/d'>
                                            <translation>
                                                <originalText>
                                                    <reference value="#med-001-rate-max"/>
                                                </originalText>
                                            </translation>
                                        </high>
                                    </rateQuantity>
                                    
                                    <!-- Médicament fixé à nullFlavor="NA" (IHE PHARM-DIS) -->
                                    <consumable>
                                        <manufacturedProduct>    
                                            <!-- Conformité Product (CCD) -->
                                            <templateId root="2.16.840.1.113883.10.20.1.53"/>
                                            <!-- Conformité Product Entry (IHE PCC) -->
                                            <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                                            <!-- Conformité FR-Produit-de-sante(CI-SIS) -->
                                            <templateId root="1.2.250.1.213.1.1.3.43"/>                                           
                                            <manufacturedMaterial nullFlavor="NA">
                                                <!-- Medicine Entry (IHE PHARM PRE)-->
                                                <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                                                <!-- Code CIS du médicament -->
                                                <code nullFlavor="NA"/>   
                                                <name nullFlavor="NA"/>
                                            </manufacturedMaterial>
                                        </manufacturedProduct>
                                    </consumable>
                                
                                </substanceAdministration>
                            </entryRelationship>
                            
                            <!-- [0..1] FR-Acte-substitution : existe dans le cas d'une substitution d'un médicament par le dispensateur -->
                            <entryRelationship typeCode="COMP" >
                                <act classCode="ACT" moodCode="EVN">
                                    <!-- Substitution act (IHE PHARM DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.9.2"/>
                                    <!-- FR-Acte-substitution (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.206"/>
                                    <code code="G" codeSystem="2.16.840.1.113883.5.1070" codeSystemName="HL7_substanceAdminSubstitution" displayName="Substitution autorisée par un produit générique">
                                        <originalText><reference value="#med-001-substitution"></reference></originalText>
                                    </code>
                                    <statusCode code="completed"/>
                                </act>
                            </entryRelationship>
                               
                        </supply>
                    </entry>
                    
                    <!-- [1..*] FR-Traitement-dispense 2 -->
                    <entry>
                        <supply classCode="SPLY" moodCode="EVN">
                            <!-- Conformité Supply Activity (CCD) -->
                            <templateId root="2.16.840.1.113883.10.20.1.34"/>
                            <!-- Conformité Supply Entry (IHE PCC) -->
                            <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.3"/>
                            <!-- Conformité DispenseItemEntry (IHE PHARM DIS) -->
                            <templateId root="1.3.6.1.4.1.19376.1.9.1.3.4"/>
                            <!-- Conformité FR-Traitement-dispense(CI-SIS) -->
                            <templateId root="1.2.250.1.213.1.1.3.204"/>
                            <id root="BBDC9C14-F1CA-4177-B2C8-A5178D5B3DB0"/>
                            <text><reference value="#med-002"></reference></text>
                            <!-- Unité issue de EDQM Packaging (30015500 "Récipient")-->
                            <quantity value="1" unit="30015500"/>                            
                            <product>
                                <!-- [1..1] FR-Produit-de-sante (CI-SIS) -->
                                <manufacturedProduct classCode="MANU">
                                    <!-- Conformité Product (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.53"/>
                                    <!-- Conformité Product Entry (IHE PCC) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                                    <!-- Conformité FR-Produit-de-sante(CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.43"/>
                                    <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                                        <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                                        <!-- Code CIS du médicament -->
                                        <code nullFlavor="NA">
                                            <originalText><reference value="#med-002-delivre"/></originalText>
                                        </code>
                                        <!-- Nom de la marque -->
                                        <name nullFlavor="NA"/>
                                        <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                                        <pharm:formCode code="50015000" displayName="pommade pour application cutanée et nasale" 
                                            codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="EDQM"/>                    
                                    </manufacturedMaterial>                 
                                </manufacturedProduct>
                            </product>
                            
                            <!-- [0..1] FR-Reference-item-prescription -->
                            <entryRelationship typeCode="REFR" inversionInd="false">
                                <substanceAdministration classCode="SBADM" moodCode="INT">              
                                    <!-- Conformité Prescription Item (IHE PHARM PRE) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.11"/>          
                                    <!-- Conformité  -->
                                    <templateId root="1.2.250.1.213.1.1.3.90"/>   
                                    <!-- Référence de la ligne de prescription -->
                                    <id root="BBDC9C14-F1CA-4177-B2C8-A5178D5B3DB1"/>
                                    <code code="PREItem" displayName="Prescription Item" 
                                        codeSystem="1.3.6.1.4.1.19376.1.9.2.2"  codeSystemName="IHE Pharmacy Item Type List">
                                    </code>
                                    <consumable>
                                        <manufacturedProduct>
                                            <manufacturedMaterial nullFlavor="NA">
                                                <name nullFlavor="NA"/>
                                            </manufacturedMaterial>
                                        </manufacturedProduct>
                                    </consumable>
                                    <author>
                                        <!-- [1..1] Horodatage de la validation par l'auteur -->
                                        <time value="20211201093000+0100"/>
                                        <!-- [1..1] Identification de l'auteur -->
                                        <assignedAuthor classCode="ASSIGNED">
                                            <!-- [1..1] Identifiant de l'auteur (Id RPPS du PS obligatoire pour les PS) -->
                                            <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
                                            <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
                                            <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
                                                codeSystem="1.2.250.1.213.1.1.4.5"/>
                                            <!-- [0..*] Adresse du PS -->
                                            <addr>
                                                <houseNumber>142</houseNumber>
                                                <streetName>Rue Belvédère</streetName>
                                                <postalCode>92100</postalCode>
                                                <city>Boulogne-Billancourt</city>
                                            </addr>
                                            <!-- [0..*] Télécom du PS -->
                                            <telecom value="tel:0158432300" use="WP"/>
                                            <!-- [0..1] Identité du PS -->
                                            <assignedPerson>
                                                <name>
                                                    <given>Jacques</given>
                                                    <family>BIDEAULT</family>
                                                    <suffix>DR</suffix>
                                                </name>
                                            </assignedPerson>
                                            <!-- [1..1] Organisation de rattachement du PS -->
                                            <representedOrganization>
                                                <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
                                                <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
                                                <!-- [1..1] Nom de l'organisation de rattachement du PS -->
                                                <name>Clinique du Belvédère</name>       
                                                <!-- [0..*] Télécom du PS -->
                                                <telecom value="tel:0157826011" use="WP"/>
                                                <!-- [0..*] Adresse du PS -->
                                                <addr>
                                                    <houseNumber>142</houseNumber>
                                                    <streetName>Rue Belvédère</streetName>
                                                    <postalCode>92100</postalCode>
                                                    <city>Boulogne-Billancourt</city>
                                                </addr>
                                            </representedOrganization>
                                        </assignedAuthor>
                                    </author>
                                    <!-- Référence de la prescription -->
                                    <reference typeCode="XCRPT">
                                        <externalDocument>
                                            <id root="1.2.250.1.213.1.1.1.39.12345.1"/>
                                        </externalDocument>
                                    </reference>
                                </substanceAdministration>
                            </entryRelationship>   
                            
                            <!-- [0..1] Entrée FR-Instructions-au-patient -->
                            <entryRelationship typeCode="SUBJ" inversionInd="true">
                                <act classCode="ACT" moodCode="INT">
                                    <!-- Conformité Patient instructions (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.49"/>
                                    <!-- Conformité Patient Medication Instruction (IHE DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                                    <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.33"/>
                                    <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                                        codeSystemName="IHEActCode"/>
                                    <text><reference value="#med-002-instruction-patient"/></text>
                                    <statusCode code="completed"/>
                                </act>
                            </entryRelationship>
                            
                            <!-- [0..1] Entrée FR-Notes-du-dispensateur -->
                            <entryRelationship typeCode="SUBJ" inversionInd="true">
                                <act classCode="ACT" moodCode="INT">
                                    <!-- Conformité Fulfillment instructions (CCD) -->
                                    <templateId root="2.16.840.1.113883.10.20.1.43"/>
                                    <!-- Conformité Medication fulfillment instruction (IHE DIS) -->
                                    <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                                    <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                                    <templateId root="1.2.250.1.213.1.1.3.207"/>
                                    <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                                        codeSystemName="IHEActCode"/>
                                    <text><reference value="#med-002-notes-dispensateur"/></text>
                                    <statusCode code="completed"/>
                                </act>
                            </entryRelationship>   
                            
                       </supply>
                    </entry>
                
                </section>
            </component>
        </structuredBody>
    </component>
</ClinicalDocument>
```

