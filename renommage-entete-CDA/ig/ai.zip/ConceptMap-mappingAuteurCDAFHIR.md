# Mapping Métier/CDA/FHIR : "Auteur" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Auteur"**

## ConceptMap: Mapping Métier/CDA/FHIR : "Auteur" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingAuteurCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-20 | *Computable Name*:Mapping Métier/CDA/FHIR : "Auteur" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "auteur" et l’élément CDA "author"
* Mapping 2 : entre l’élément CDA "author" et l’élément FHIR "Composition.author"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Auteur du document (humain ou système)](StructureDefinition-Auteur.md) to `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author`

* **Source Code**: Auteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author
  * **Commentaire**: 
* **Source Code**: Auteur.roleFonctionnel
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.functionCode
  * **Commentaire**: 
* **Source Code**: Auteur.horodatageParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.time
  * **Commentaire**: 
* **Source Code**: Auteur.PersonneStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.assignedAuthor
  * **Commentaire**: L'élément PersonneStructure est de type PersonneStructure.
* **Source Code**: Auteur.SystemeStructureAuteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: author.assignedAuthor
  * **Commentaire**: L'élément SystemeStructureAuteur est de type Systeme

-------

**Group 2**Mapping from `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author` to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: author
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author
  * **Commentaire**: 
* **Source Code**: author.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.extension:time
  * **Commentaire**: 
* **Source Code**: author.functionCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.PractitionerRole.code
  * **Commentaire**: Auteur du document est un professionnel et author.ofType(PractitionerRole)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Practitioner
  * **Commentaire**: Composition.author.resolve().ofType(Practitioner)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Patient
  * **Commentaire**: Composition.author.resolve().ofType(Patient)
* **Source Code**: author.assignedAuthor
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author.Device
  * **Commentaire**: Composition.author.resolve().ofType(Device)



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mappingAuteurCDAFHIR",
  "url" : "https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingAuteurCDAFHIR",
  "version" : "0.1.0",
  "name" : "Mapping Métier/CDA/FHIR : \"Auteur\"",
  "title" : "Mapping Métier/CDA/FHIR : \"Auteur\"",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-10-20T12:52:41+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [
    {
      "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://esante.gouv.fr"
        }
      ]
    }
  ],
  "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"auteur\\\" et l'élément CDA \\\"author\\\"\n - Mapping 2 : entre l'élément CDA \\\"author\\\" et l'élément FHIR \\\"Composition.author\\\" ",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "FRANCE"
        }
      ]
    }
  ],
  "group" : [
    {
      "source" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Auteur",
      "target" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author",
      "element" : [
        {
          "code" : "Auteur",
          "target" : [
            {
              "code" : "author",
              "equivalence" : "equivalent"
            }
          ]
        },
        {
          "code" : "Auteur.roleFonctionnel",
          "target" : [
            {
              "code" : "author.functionCode",
              "equivalence" : "equivalent"
            }
          ]
        },
        {
          "code" : "Auteur.horodatageParticipation",
          "target" : [
            {
              "code" : "author.time",
              "equivalence" : "equivalent"
            }
          ]
        },
        {
          "code" : "Auteur.PersonneStructure",
          "target" : [
            {
              "code" : "author.assignedAuthor",
              "equivalence" : "equivalent",
              "comment" : "L'élément PersonneStructure est de type PersonneStructure."
            }
          ]
        },
        {
          "code" : "Auteur.SystemeStructureAuteur",
          "target" : [
            {
              "code" : "author.assignedAuthor",
              "equivalence" : "equivalent",
              "comment" : "L'élément SystemeStructureAuteur est de type Systeme"
            }
          ]
        }
      ]
    },
    {
      "source" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-author",
      "target" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document",
      "element" : [
        {
          "code" : "author",
          "target" : [
            {
              "code" : "Composition.author",
              "equivalence" : "equivalent"
            }
          ]
        },
        {
          "code" : "author.time",
          "target" : [
            {
              "code" : "Composition.author.extension:time",
              "equivalence" : "equivalent"
            }
          ]
        },
        {
          "code" : "author.functionCode",
          "target" : [
            {
              "code" : "Composition.author.PractitionerRole.code",
              "equivalence" : "equivalent",
              "comment" : "Auteur du document est un professionnel et author.ofType(PractitionerRole)"
            }
          ]
        },
        {
          "code" : "author.assignedAuthor",
          "target" : [
            {
              "code" : "Composition.author.Practitioner",
              "equivalence" : "equivalent",
              "comment" : "Composition.author.resolve().ofType(Practitioner)"
            }
          ]
        },
        {
          "code" : "author.assignedAuthor",
          "target" : [
            {
              "code" : "Composition.author.Patient",
              "equivalence" : "equivalent",
              "comment" : "Composition.author.resolve().ofType(Patient)"
            }
          ]
        },
        {
          "code" : "author.assignedAuthor",
          "target" : [
            {
              "code" : "Composition.author.Device",
              "equivalence" : "equivalent",
              "comment" : "Composition.author.resolve().ofType(Device)"
            }
          ]
        }
      ]
    }
  ]
}

```
