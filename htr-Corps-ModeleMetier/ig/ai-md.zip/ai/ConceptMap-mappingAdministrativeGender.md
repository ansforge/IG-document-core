# Mapping ValueSet AdministrativeGender - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping ValueSet AdministrativeGender**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingAdministrativeGender.xml.md) 
*  [JSON](ConceptMap-mappingAdministrativeGender.json.md) 

## ConceptMap: Mapping ValueSet AdministrativeGender 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingAdministrativeGender | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:Mapping ValueSet AdministrativeGender |

 
Mapping entre les codes du ValueSet FHIR AdministrativeGender et ceux du ValueSet JDV_J143-AdministrativeGender-CISIS établi par ce ConceptMap. 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [AdministrativeGender](http://hl7.org/fhir/R4/codesystem-administrative-gender.html) to [JDV_J143_AdministrativeGender_CISIS](https://interop.esante.gouv.fr/terminologies/1.2.0/ValueSet-JDV-J143-AdministrativeGender-CISIS.html)

* **Source Code**: male
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: M
* **Source Code**: female
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: F
* **Source Code**: unknown
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: UN

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingValidateurCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingAdministrativeGender-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

