# Codes à barres - Mappings - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Codes à barres**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-CodesAbarres.md) 
*  [Detailed Descriptions](StructureDefinition-CodesAbarres-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-CodesAbarres.profile.xml.md) 
*  [JSON](StructureDefinition-CodesAbarres.profile.json.md) 

## Logical Model: CodesAbarres - Mappings

| |
| :--- |
| Draft as of 2025-10-06 |

Mappings for the CodesAbarres logical model.

No Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-CodesAbarres-definitions.md) | [top](#top) |  [next>](StructureDefinition-CodesAbarres-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

