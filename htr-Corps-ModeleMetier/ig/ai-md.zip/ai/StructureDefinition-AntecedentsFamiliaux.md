# Antécédents familiaux - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Antécédents familiaux**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-AntecedentsFamiliaux-definitions.md) 
*  [Mappings](StructureDefinition-AntecedentsFamiliaux-mappings.md) 
*  [XML](StructureDefinition-AntecedentsFamiliaux.profile.xml.md) 
*  [JSON](StructureDefinition-AntecedentsFamiliaux.profile.json.md) 

## Logical Model: Antécédents familiaux 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/AntecedentsFamiliaux | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:AntecedentsFamiliaux |

 
Modèle logique métier de la section Antécédents familiaux 

**Usages:**

* Use this Logical Model: [* Modèle logique métier du corps](StructureDefinition-CorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/AntecedentsFamiliaux)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Section](StructureDefinition-Section.md) 

This structure is derived from [Section](StructureDefinition-Section.md) 

**Résumé**

Mandatory: 1 element(1 nested mandatory element)
 Prohibited: 1 element

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Section](StructureDefinition-Section.md) 

 **Snapshot View** 

This structure is derived from [Section](StructureDefinition-Section.md) 

**Résumé**

Mandatory: 1 element(1 nested mandatory element)
 Prohibited: 1 element

 

Other representations of profile: [CSV](StructureDefinition-AntecedentsFamiliaux.csv), [Excel](StructureDefinition-AntecedentsFamiliaux.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-AllergiesEtHypersensibilites.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-AntecedentsFamiliaux-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

