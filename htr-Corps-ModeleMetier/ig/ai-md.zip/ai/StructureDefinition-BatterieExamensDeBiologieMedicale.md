# Batterie d'examens de biologie médicale - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Batterie d'examens de biologie médicale**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BatterieExamensDeBiologieMedicale-definitions.md) 
*  [Mappings](StructureDefinition-BatterieExamensDeBiologieMedicale-mappings.md) 
*  [XML](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.xml.md) 
*  [JSON](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.json.md) 

## Logical Model: Batterie d'examens de biologie médicale 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/BatterieExamensDeBiologieMedicale | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:BatterieExamensDeBiologieMedicale |

 
Modèle logique métier de l’entrée Batterie d’examens de biologie médicale 

**Usages:**

* Use this Logical Model: [Isolat microbiologique](StructureDefinition-IsolatMicrobiologique.md) and [Resultats d'examens de biologie medicale](StructureDefinition-ResultatsExamensBiologieMedicale.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/BatterieExamensDeBiologieMedicale)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-BatterieExamensDeBiologieMedicale.csv), [Excel](StructureDefinition-BatterieExamensDeBiologieMedicale.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-AutorisationSubstitution.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BatterieExamensDeBiologieMedicale-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

