# Batterie d'examens de biologie médicale - Definitions - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Batterie d'examens de biologie médicale**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-BatterieExamensDeBiologieMedicale.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-BatterieExamensDeBiologieMedicale-mappings.md) 
*  [XML](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.xml.md) 
*  [JSON](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.json.md) 

## Logical Model: BatterieExamensDeBiologieMedicale - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-06 |

Definitions for the BatterieExamensDeBiologieMedicale logical model.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BatterieExamensDeBiologieMedicale.md) | [top](#top) |  [next>](StructureDefinition-BatterieExamensDeBiologieMedicale-mappings.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

