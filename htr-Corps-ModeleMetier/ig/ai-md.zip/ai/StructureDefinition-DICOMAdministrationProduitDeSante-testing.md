# DICOM Administration produit de sante - Testing - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DICOM Administration produit de sante**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-DICOMAdministrationProduitDeSante.md) 
*  [Detailed Descriptions](StructureDefinition-DICOMAdministrationProduitDeSante-definitions.md) 
*  [Mappings](StructureDefinition-DICOMAdministrationProduitDeSante-mappings.md) 
*  [XML](StructureDefinition-DICOMAdministrationProduitDeSante.profile.xml.md) 
*  [JSON](StructureDefinition-DICOMAdministrationProduitDeSante.profile.json.md) 

## Logical Model: DICOMAdministrationProduitDeSante - Testing

| |
| :--- |
| Draft as of 2025-10-06 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DICOMAdministrationProduitDeSante-mappings.md) | [top](#top) |  [next>](StructureDefinition-DICOMAdministrationProduitDeSante.profile.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

