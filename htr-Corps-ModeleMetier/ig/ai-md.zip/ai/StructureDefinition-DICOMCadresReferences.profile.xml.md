# DICOM Cadres references - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DICOM Cadres references**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-DICOMCadresReferences.md) 
*  [Detailed Descriptions](StructureDefinition-DICOMCadresReferences-definitions.md) 
*  [Mappings](StructureDefinition-DICOMCadresReferences-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-DICOMCadresReferences.profile.json.md) 

## Logical Model: DICOMCadresReferences - XML Profile

| |
| :--- |
| Draft as of 2025-10-06 |

XML representation of the DICOMCadresReferences logical model.

[Raw xml](StructureDefinition-DICOMCadresReferences.xml) | [Download](StructureDefinition-DICOMCadresReferences.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DICOMCadresReferences-testing.md) | [top](#top) |  [next>](StructureDefinition-DICOMCadresReferences.profile.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

