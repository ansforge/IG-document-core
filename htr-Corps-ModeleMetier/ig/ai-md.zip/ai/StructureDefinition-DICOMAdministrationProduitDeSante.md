# DICOM Administration produit de sante - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DICOM Administration produit de sante**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DICOMAdministrationProduitDeSante-definitions.md) 
*  [Mappings](StructureDefinition-DICOMAdministrationProduitDeSante-mappings.md) 
*  [XML](StructureDefinition-DICOMAdministrationProduitDeSante.profile.xml.md) 
*  [JSON](StructureDefinition-DICOMAdministrationProduitDeSante.profile.json.md) 

## Logical Model: DICOM Administration produit de sante 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/DICOMAdministrationProduitDeSante | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:DICOMAdministrationProduitDeSante |

 
Modèle logique métier de l’entrée DICOM Administration produit de sante 

**Usages:**

* Use this Logical Model: [Acte d'imagerie](StructureDefinition-DICOMActeImagerie.md) and [Exposition aux radiations](StructureDefinition-DICOMExpositionRadiations.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/DICOMAdministrationProduitDeSante)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(4 nested mandatory elements)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(4 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-DICOMAdministrationProduitDeSante.csv), [Excel](StructureDefinition-DICOMAdministrationProduitDeSante.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DemandeExamenOuSuivi.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-DICOMAdministrationProduitDeSante-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

