# Mapping Métier/CDA/FHIR : "Structure chargée de la conservation du document" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Structure chargée de la conservation du document"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingStructureConservationCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingStructureConservationCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Structure chargée de la conservation du document" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingStructureConservationCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:Mapping Métier/CDA/FHIR : "Structure chargée de la conservation du document" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "structureConservation" et l’élément CDA "custodian"
* Mapping 2 : entre l’élément CDA "custodian" et l’élément FHIR "Composition.custodian"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Structure chargée de la conservation du document](StructureDefinition-StructureConservation.md) to [CDA - custodian](StructureDefinition-fr-core-custodian.md)

* **Source Code**: StructureConservation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian
* **Source Code**: StructureConservation.structure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian.assignedCustodian
* **Source Code**: StructureConservation.structure.identifiantStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian.assignedCustodian.representedCustodianOrganization.id
* **Source Code**: StructureConservation.structure.nomStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian.assignedCustodian.representedCustodianOrganization.name
* **Source Code**: StructureConservation.structure.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian.assignedCustodian.representedCustodianOrganization.addr
* **Source Code**: StructureConservation.structure.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: custodian.assignedCustodian.representedCustodianOrganization.telecom

-------

**Group 2**Mapping from [CDA - custodian](StructureDefinition-fr-core-custodian.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: custodian
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian
  * **Commentaire**: Composition.custodian.resolve().ofType(Organization)
* **Source Code**: custodian.assignedCustodian
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian.organization
  * **Commentaire**: 
* **Source Code**: custodian.assignedCustodian.representedCustodianOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian.organization.identifier
  * **Commentaire**: 
* **Source Code**: custodian.assignedCustodian.representedCustodianOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian.organization.name
  * **Commentaire**: 
* **Source Code**: custodian.assignedCustodian.representedCustodianOrganization.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian.organization.address
  * **Commentaire**: 
* **Source Code**: custodian.assignedCustodian.representedCustodianOrganization.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian.organization.telecom
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingResponsableCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingStructureConservationCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

