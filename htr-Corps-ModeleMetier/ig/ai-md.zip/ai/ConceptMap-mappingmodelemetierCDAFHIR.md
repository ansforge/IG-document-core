# Mapping Métier/CDA/FHIR : Entête d'un document - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : Entête d'un document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingmodelemetierCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingmodelemetierCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : Entête d'un document 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingmodelemetierCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:Mapping Métier/CDA/FHIR : Entête d'un document |

 
Ce ConceptMap présente trois groupes de mapping : 
* Mapping 1 : entre le modèle métier "EnteteDocument" et l’élément CDA "clinicalDocument"
* Mapping 2 : entre l’élément CDA "clinicalDocument" et le profil FHIR "FrBundleDocument"
* Mapping 3 : entre l’élément CDA "clinicalDocument" et le profil FHIR "FrCompositionDocument"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle logique métier de l'en-tête](StructureDefinition-EnteteDocument.md) to [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md)

* **Source Code**: EnteteDocument.identifiantUniqueDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.id
* **Source Code**: EnteteDocument.modeleDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.templateId
* **Source Code**: EnteteDocument.typeDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.code
* **Source Code**: EnteteDocument.titreDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.title
* **Source Code**: EnteteDocument.dateDeCreationDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.effectiveTime
* **Source Code**: EnteteDocument.niveauConfidentialiteDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.confidentialityCode
* **Source Code**: EnteteDocument.languePrincipaleDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.languageCode
* **Source Code**: EnteteDocument.identifiantLotDeVersionsDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.setId
* **Source Code**: EnteteDocument.versionDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.versionNumber
* **Source Code**: EnteteDocument.StatutDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.documentationOf.serviceEvent.lab:statusCode
* **Source Code**: EnteteDocument.patient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.recordTarget
* **Source Code**: EnteteDocument.auteur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.author
* **Source Code**: EnteteDocument.operateurSaisie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.dataEnterer
* **Source Code**: EnteteDocument.informateur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.informant
* **Source Code**: EnteteDocument.structureConservation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.custodian
* **Source Code**: EnteteDocument.destinataire
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.informationRecipient
* **Source Code**: EnteteDocument.responsable
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.legalAuthenticator
* **Source Code**: EnteteDocument.validateur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.authenticator
* **Source Code**: EnteteDocument.participant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.participant
* **Source Code**: EnteteDocument.prescription
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.inFulfillmentOf
* **Source Code**: EnteteDocument.evenement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.documentationOf
* **Source Code**: EnteteDocument.documentDeReference
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.relatedDocument
* **Source Code**: EnteteDocument.consentementAssocie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.authorization
* **Source Code**: EnteteDocument.priseEncharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ClinicalDocument.componentOf

-------

**Group 2**Mapping from [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md) to [Fr Bundle Document](StructureDefinition-fr-bundle-document.md)

* **Source Code**: ClinicalDocument.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Bundle.identifier

-------

**Group 3**Mapping from [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: ClinicalDocument.templateId
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.meta.profile
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.type
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.title
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.title
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.effectiveTime
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.date
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.confidentialityCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.confidentiality
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.languageCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.language
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.setId
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.identifier
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.versionNumber
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:R5-Composition-version
  * **Commentaire**: http://hl7.org/fhir/5.0/StructureDefinition/extension-Composition.version
* **Source Code**: ClinicalDocument.documentationOf.serviceEvent.lab:statusCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.status
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.recordTarget
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.subject
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.author
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.author
  * **Commentaire**: Composition.author.resolve().ofType(PractitionerRole)
* **Source Code**: ClinicalDocument.dataEnterer
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:data-enterer
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/data-enterer-extension
* **Source Code**: ClinicalDocument.informant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:informant
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/informant-extension
* **Source Code**: ClinicalDocument.custodian
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.custodian
  * **Commentaire**: Composition.custodian.resolve().ofType(Organization)
* **Source Code**: ClinicalDocument.informationRecipient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:informationRecipient
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/information-recipient-extension
* **Source Code**: ClinicalDocument.legalAuthenticator
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester
  * **Commentaire**: attester.mode = 'legal'
* **Source Code**: ClinicalDocument.authenticator
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.attester
  * **Commentaire**: attester.mode = 'professional'
* **Source Code**: ClinicalDocument.participant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:participant
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/ParticipantExtension
* **Source Code**: ClinicalDocument.inFulfillmentOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:order
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/OrderExtension
* **Source Code**: ClinicalDocument.documentationOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.event
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.relatedDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.relatesTo
  * **Commentaire**: 
* **Source Code**: ClinicalDocument.authorization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.extension:consent
  * **Commentaire**: http://hl7.org/fhir/uv/fhir-clinical-document/StructureDefinition/consent-extension
* **Source Code**: ClinicalDocument.componentOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.encounter
  * **Commentaire**: https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-encounter-document

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-performer-event.profile.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingmodelemetierCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

