# Complications - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Complications**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-DICOMComplication.md) 
*  [Detailed Descriptions](StructureDefinition-DICOMComplication-definitions.md) 
*  [Mappings](StructureDefinition-DICOMComplication-mappings.md) 
*  [XML](StructureDefinition-DICOMComplication.profile.xml.md) 
*  [JSON](#) 

## Logical Model: DICOMComplication - JSON Profile

| |
| :--- |
| Draft as of 2025-10-06 |

JSON representation of the DICOMComplication logical model.

[Raw json](StructureDefinition-DICOMComplication.json) | [Download](StructureDefinition-DICOMComplication.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DICOMComplication.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-DICOMComplication.profile.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

