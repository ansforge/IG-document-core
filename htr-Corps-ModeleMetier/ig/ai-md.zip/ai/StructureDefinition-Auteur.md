# Modèle métier - Auteur du document (humain ou système) - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Auteur du document (humain ou système)**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Auteur-definitions.md) 
*  [Mappings](StructureDefinition-Auteur-mappings.md) 
*  [XML](StructureDefinition-Auteur.profile.xml.md) 
*  [JSON](StructureDefinition-Auteur.profile.json.md) 

## Logical Model: Modèle métier - Auteur du document (humain ou système) 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Auteur | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:Auteur |

 
Auteur du document : ce peut être un professionnel, un patient/usager ou un système. 
* Pour un professionnel ou un système, la structure de rattachement doit être précisée.
 

**Voici les cas d’usage des documents et leurs auteurs** :

| | | |
| :--- | :--- | :--- |
| Création d’un document par un professionnel sur son logiciel professionnel | Professionnel | Structure |
| Création d’un document patient par un professionnel sur son logiciel professionnel pour le compte du patient | Professionnel | Structure |
| Création d’un document patient par le patient | Patient | non utilisé |
| Création d’un document par un système (dispositif, automate, …) de structure (ES, …) | Système de structure | Structure |
| Création d’un document par un Service numérique référencé (SNR) | SNR | Editeur |
| Création d’un document par le DP | CNOP/DP | CNOP |

**Usages:**

* Derived from this Logical Model: [Auteur APSR](StructureDefinition-AuteurAPSR.md)
* Use this Logical Model: [Accident transfusionnel](StructureDefinition-AccidentsTransfusionnels.md), [Acte](StructureDefinition-Acte.md), [Administration de dérivés du sang](StructureDefinition-AdministrationDeDerivesDuSang.md), [Antécédent familial observé](StructureDefinition-AntecedentFamilialObserve.md)...Show 38 more,[Batterie d'examens de biologie médicale](StructureDefinition-BatterieExamensDeBiologieMedicale.md),[Commentaire](StructureDefinition-CommentaireER.md),[Addendum](StructureDefinition-DICOMAddendum.md),[Demande d'examen ou de suivi / Objectif à atteindre](StructureDefinition-DemandeExamenOuSuivi.md),[Dispensation médicaments](StructureDefinition-DispensationMedicaments.md),[Dispositif médical](StructureDefinition-DispositifMedicalEntry.md),[En rapport avec une Affection Longue Durée (ALD)](StructureDefinition-EnRapportAvecALD.md),[En rapport avec un accident travail](StructureDefinition-EnRapportAvecAccidentTravail.md),[En rapport avec la prevention](StructureDefinition-EnRapportAvecLaPrevention.md),[Modèle logique métier de l'en-tête](StructureDefinition-EnteteDocument.md),[Evaluation](StructureDefinition-Evaluation.md),[Evènements indésirables pendant l'hospitalisation](StructureDefinition-EvenementIndesirablePendantHospitalisation.md),[Evènements indésirables suite à l'administration de dérivés du sang](StructureDefinition-EvenementsIndesirablesSuiteAdministrationDerivesSang.md),[Hors Autorisation de Mise sur le Marché (AMM)](StructureDefinition-HorsAMM.md),[Identification de micro-organismes multirésistants](StructureDefinition-IdentificationDeMicroOrganismesMultiresistants.md),[Isolat microbiologique](StructureDefinition-IsolatMicrobiologique.md),[Modalité d'entrée](StructureDefinition-ModaliteEntree.md),[Modalité de sortie](StructureDefinition-ModaliteSortie.md),[Non remboursable](StructureDefinition-NonRemboursable.md),[Prescription de dispositifs médicaux](StructureDefinition-PrescriptionDispositifsMedicaux.md),[Prescription](StructureDefinition-PrescriptionEntry.md),[Prescription de médicaments](StructureDefinition-PrescriptionMedicaments.md),[Recherche de micro organismes](StructureDefinition-RechercheDeMicroOrganismes.md),[Référence item plan traitement](StructureDefinition-ReferenceItemPlanTraitement.md),[Référence item prescription](StructureDefinition-ReferenceItemPrescription.md),[Rencontre](StructureDefinition-Rencontre.md),[Résultat d'examens de biologie / élement clinique pertinent](StructureDefinition-ResultatExamensBiologieElementCliniquePertinent.md),[Resultats](StructureDefinition-ResultatsEntry.md),[Resultats d'examens de biologie medicale](StructureDefinition-ResultatsExamensBiologieMedicale.md),[Signe vital](StructureDefinition-SigneVital.md),[Signe vital observé](StructureDefinition-SigneVitalObserve.md),[Simple observation](StructureDefinition-SimpleObservation.md),[Statut](StructureDefinition-Statut.md),[Statut du document](StructureDefinition-StatutDocumentEntry.md),[Statut fonctionnel](StructureDefinition-StatutFonctionnel.md),[Synthese medicale sejour](StructureDefinition-SyntheseMedicaleSejour.md),[Traitement Prescrit](StructureDefinition-TraitementPrescrit.md)and[Transfusion de produits sanguins](StructureDefinition-TransfusionDeProduitsSanguins.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/Auteur)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-Auteur.csv), [Excel](StructureDefinition-Auteur.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-PriseEncharge.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-Auteur-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

