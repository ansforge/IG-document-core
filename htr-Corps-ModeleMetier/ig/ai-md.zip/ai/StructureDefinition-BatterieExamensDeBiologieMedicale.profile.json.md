# Batterie d'examens de biologie médicale - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Batterie d'examens de biologie médicale**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-BatterieExamensDeBiologieMedicale.md) 
*  [Detailed Descriptions](StructureDefinition-BatterieExamensDeBiologieMedicale-definitions.md) 
*  [Mappings](StructureDefinition-BatterieExamensDeBiologieMedicale-mappings.md) 
*  [XML](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.xml.md) 
*  [JSON](#) 

## Logical Model: BatterieExamensDeBiologieMedicale - JSON Profile

| |
| :--- |
| Draft as of 2025-10-06 |

JSON representation of the BatterieExamensDeBiologieMedicale logical model.

[Raw json](StructureDefinition-BatterieExamensDeBiologieMedicale.json) | [Download](StructureDefinition-BatterieExamensDeBiologieMedicale.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-BatterieExamensDeBiologieMedicale.profile.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

