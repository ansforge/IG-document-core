# Allergies et hypersensibilités - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Allergies et hypersensibilités**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-AllergiesEtHypersensibilites-definitions.md) 
*  [Mappings](StructureDefinition-AllergiesEtHypersensibilites-mappings.md) 
*  [XML](StructureDefinition-AllergiesEtHypersensibilites.profile.xml.md) 
*  [JSON](StructureDefinition-AllergiesEtHypersensibilites.profile.json.md) 

## Logical Model: Allergies et hypersensibilités 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/AllergiesEtHypersensibilites | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:AllergiesEtHypersensibilites |

 
Modèle loqigue métier de la section Allergies et hypersensibilités 

**Usages:**

* Use this Logical Model: [* Modèle logique métier du corps](StructureDefinition-CorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/AllergiesEtHypersensibilites)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Section](StructureDefinition-Section.md) 

This structure is derived from [Section](StructureDefinition-Section.md) 

**Résumé**

Mandatory: 2 elements(1 nested mandatory element)
 Prohibited: 1 element

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Section](StructureDefinition-Section.md) 

 **Snapshot View** 

This structure is derived from [Section](StructureDefinition-Section.md) 

**Résumé**

Mandatory: 2 elements(1 nested mandatory element)
 Prohibited: 1 element

 

Other representations of profile: [CSV](StructureDefinition-AllergiesEtHypersensibilites.csv), [Excel](StructureDefinition-AllergiesEtHypersensibilites.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-DICOMAddendum.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-AllergiesEtHypersensibilites-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

