# Acte - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Acte**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Acte-definitions.md) 
*  [Mappings](StructureDefinition-Acte-mappings.md) 
*  [XML](StructureDefinition-Acte.profile.xml.md) 
*  [JSON](StructureDefinition-Acte.profile.json.md) 

## Logical Model: Acte 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Acte | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:Acte |

 
Modèle logique métier de l’entrée Acte 

**Usages:**

* Use this Logical Model: [Education du patient](StructureDefinition-EducationPatient.md), [Historique des actes](StructureDefinition-HistoriqueDesActes.md), [Plan de soins](StructureDefinition-PlanSoins.md) and [Résultats d'examens](StructureDefinition-ResultatsExamens.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/Acte)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(4 nested mandatory elements)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(4 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-Acte.csv), [Excel](StructureDefinition-Acte.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-AccidentsTransfusionnels.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-Acte-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

