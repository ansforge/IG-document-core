# Statut fonctionnel - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Statut fonctionnel**

## Logical Model: Statut fonctionnel 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/FrStatutFonctionnel | *Version*:0.1.0 |
| Draft as of 2025-10-13 | *Computable Name*:FrStatutFonctionnel |

 
Section Statut fonctionnel 

**Usages:**

* Use this Logical Model: [* Modèle logique métier du corps](StructureDefinition-CorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/FrStatutFonctionnel)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-FrStatutFonctionnel.csv), [Excel](StructureDefinition-FrStatutFonctionnel.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FrStatutFonctionnel",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
      "valueCode" : "can-be-target"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
      "valueCode" : "can-be-target"
    }
  ],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/FrStatutFonctionnel",
  "version" : "0.1.0",
  "name" : "FrStatutFonctionnel",
  "title" : "Statut fonctionnel",
  "status" : "draft",
  "date" : "2025-10-13T08:32:48+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [
    {
      "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://esante.gouv.fr"
        }
      ]
    }
  ],
  "description" : "Section Statut fonctionnel",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "FRANCE"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/FrStatutFonctionnel",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Section",
  "derivation" : "specialization",
  "differential" : {
    "element" : [
      {
        "id" : "FrStatutFonctionnel",
        "path" : "FrStatutFonctionnel",
        "short" : "Statut fonctionnel",
        "definition" : "Section Statut fonctionnel"
      },
      {
        "id" : "FrStatutFonctionnel.titreSection",
        "path" : "FrStatutFonctionnel.titreSection",
        "min" : 1
      },
      {
        "id" : "FrStatutFonctionnel.sousSection",
        "path" : "FrStatutFonctionnel.sousSection",
        "max" : "0"
      },
      {
        "id" : "FrStatutFonctionnel.entree.groupeQuestionnairesEvaluation",
        "path" : "FrStatutFonctionnel.entree.groupeQuestionnairesEvaluation",
        "short" : "Groupe de questionnaires d'évalutation",
        "definition" : "Groupe de questionnaires d'évalutation",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/FrGroupDeQuestionnairesDevaluation"
          }
        ]
      },
      {
        "id" : "FrStatutFonctionnel.auteur",
        "path" : "FrStatutFonctionnel.auteur",
        "short" : "Auteur",
        "definition" : "Auteur",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Auteur"
          }
        ]
      },
      {
        "id" : "FrStatutFonctionnel.informateur",
        "path" : "FrStatutFonctionnel.informateur",
        "short" : "Informateur",
        "definition" : "Informateur",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Informateur"
          }
        ]
      }
    ]
  }
}

```
