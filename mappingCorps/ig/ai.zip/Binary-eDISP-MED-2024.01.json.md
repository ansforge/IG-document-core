# eDISP-MED-2024.01 - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eDISP-MED-2024.01**

## : eDISP-MED-2024.01 - JSON Representation

[Raw json](Binary-eDISP-MED-2024.01.json) | [Download](Binary-eDISP-MED-2024.01.json)

