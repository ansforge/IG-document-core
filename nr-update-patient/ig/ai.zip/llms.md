# ans.document.fr.core#0.1.0: ANS IG document core

## Pages

* [Accueil](index.md)
* [Exigences spécifiques](exigencesSpecifiques.md)
* [CDA](ressourcesCDA-struc-gen.md)
* [Introduction](introduction.md)
* [FHIR](ressourcesFHIR-struc-gen.md)
* [FHIR](ressourcesFHIR-corps.md)
* [Mapping Métier/CDA/FHIR](mappingCDA-FHIR-entete.md)
* [Structure générale document](structureGenerale.md)
* [Artifacts Summary](artifacts.md)
* [CDA](ressourcesCDA-corps.md)
* [Entête document](enteteDocument.md)
* [Sécurité](securite.md)
* [Corps d'un document](corpsDocument.md)
* [Mapping CDA / FHIR](mappingCDA-FHIR-struc-gen.md)
* [FHIR](ressourcesFHIR-entete.md)
* [CDA](ressourcesCDA-entete.md)
* [Autres Ressources](autres_ressources.md)
* [Modèle logique métier](modelesLogiquesMetier-corps.md)
* [Mapping Métier/CDA/FHIR](mappingCDA-FHIR-corps.md)
* [Téléchargements et usages](downloads.md)

## Resources

### ValueSets

* [FR ValueSet Participation Type](ValueSet-fr-doc-vs-participation-type.md)
* [Fr ValueSet RolePriseCharge](ValueSet-fr-doc-vs-role-prise-charge.md)
* [Fr ValueSet Savoir-faire Profession Chirurgien-Dentiste](ValueSet-fr-doc-vs-savoir-faire-profession-chirurgien-dentiste.md)
* [Fr ValueSet Savoir-faire Profession Infirmier](ValueSet-fr-doc-vs-savoir-faire-profession-infirmier.md)
* [Fr ValueSet Savoir-faire Profession Medecin](ValueSet-fr-doc-vs-savoir-faire-profession-medecin.md)
* [Fr ValueSet Savoir-faire Profession Pharmacien](ValueSet-fr-doc-vs-savoir-faire-profession-pharmacien.md)
* [Fr ValueSet Type Savoir-faire Profession Chirurgien-Dentiste](ValueSet-fr-doc-vs-type-savoir-faire-profession-chirurgien-dentiste.md)
* [Fr ValueSet Type Savoir-faire Profession Infirmier](ValueSet-fr-doc-vs-type-savoir-faire-profession-infirmier.md)
* [Fr ValueSet Type Savoir-faire Profession Medecin](ValueSet-fr-doc-vs-type-savoir-faire-profession-medecin.md)
* [Fr ValueSet Type Savoir-faire Profession Pharmacien](ValueSet-fr-doc-vs-type-savoir-faire-profession-pharmacien.md)

### Logicals

* [Modèle métier - Auteur du document (humain ou système)](StructureDefinition-Auteur.md)
* [Modèle métier - Consentement associé au document](StructureDefinition-Consentement.md)
* [Modèle métier - Destinataire prévu du document](StructureDefinition-DestinatairePrevu.md)
* [Modèle métier - Document de référence](StructureDefinition-DocumentDeReference.md)
* [Modèle logique métier de l'en-tête](StructureDefinition-EnteteDocument.md)
* [Modèle métier - Évènement documenté](StructureDefinition-Evenement.md)
* [Modèle métier - Informateur](StructureDefinition-Informateur.md)
* [Modèle métier - Opérateur de saisie](StructureDefinition-OperateurSaisie.md)
* [Modèle métier - Autres personnes / structures impliquées](StructureDefinition-Participant.md)
* [Modèle métier - Patient / Usager](StructureDefinition-PatientUsager.md)
* [Modèle métier - Personne et/ou Structure](StructureDefinition-PersonneStructure.md)
* [Modèle métier - Personne et/ou Structure (Auteur)](StructureDefinition-PersonneStructureAuteur.md)
* [Modèle métier - Association du document à une prescription](StructureDefinition-Prescription.md)
* [Modèle métier - Association du document à une prise en charge](StructureDefinition-PriseEncharge.md)
* [Modèle métier - Responsable du document](StructureDefinition-Responsable.md)
* [Modèle métier - Structure chargée de la conservation du document](StructureDefinition-StructureConservation.md)
* [Modèle métier - Système / Structure](StructureDefinition-SystemeStructureAuteur.md)
* [Modèle métier - Validateur du document](StructureDefinition-Validateur.md)
* [CDA - name](StructureDefinition-fr-core-name.md)

### Complex-type Profiles

* [Human Name Document](StructureDefinition-fr-human-name-document.md)

### Logical Profiles

* [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md)
* [CDA - assignedCustodian](StructureDefinition-fr-core-assigned-custodian.md)
* [CDA - assignedEntity](StructureDefinition-fr-core-assigned-entity.md)
* [CDA - associatedEntity](StructureDefinition-fr-core-associated-entity.md)
* [CDA - authenticator](StructureDefinition-fr-core-authenticator.md)
* [CDA - author](StructureDefinition-fr-core-author.md)
* [CDA - authoringDevice](StructureDefinition-fr-core-authoring-device.md)
* [CDA - authorization](StructureDefinition-fr-core-authorization.md)
* [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md)
* [CDA - componentOf](StructureDefinition-fr-core-component-of.md)
* [CDA - custodian](StructureDefinition-fr-core-custodian.md)
* [CDA - dataEnterer](StructureDefinition-fr-core-data-enterer.md)
* [CDA - documentationOf](StructureDefinition-fr-core-documentation-of.md)
* [CDA - encompassingEncounter](StructureDefinition-fr-core-encompassing-encounter.md)
* [CDA - encounterParticipant](StructureDefinition-fr-core-encounter-participant.md)
* [CDA - healthCareFacility](StructureDefinition-fr-core-health-care-facility.md)
* [CDA - inFulfillmentOf](StructureDefinition-fr-core-inFulfillment-of.md)
* [CDA - informant](StructureDefinition-fr-core-informant.md)
* [CDA - informationRecipient](StructureDefinition-fr-core-information-recipient.md)
* [CDA - intendedRecipient](StructureDefinition-fr-core-intended-recipient.md)
* [CDA - legalAuthenticator](StructureDefinition-fr-core-legal-authenticator.md)
* [CDA - order](StructureDefinition-fr-core-order.md)
* [CDA - parentDocument](StructureDefinition-fr-core-parent-document.md)
* [CDA - participant](StructureDefinition-fr-core-participant.md)
* [CDA - patientRole](StructureDefinition-fr-core-patient-role.md)
* [CDA - patient](StructureDefinition-fr-core-patient.md)
* [CDA - performer](StructureDefinition-fr-core-performer.md)
* [CDA - assignedPerson](StructureDefinition-fr-core-person.md)
* [CDA - recordTarget](StructureDefinition-fr-core-record-target.md)
* [CDA - relatedDocument](StructureDefinition-fr-core-related-document.md)
* [CDA - relatedEntity](StructureDefinition-fr-core-related-entity.md)
* [CDA - representedCustodianOrganization](StructureDefinition-fr-core-represented-custodian-organization.md)
* [CDA - representedOrganization](StructureDefinition-fr-core-represented-organization.md)
* [CDA - serviceEvent](StructureDefinition-fr-core-service-event.md)

### Resource Profiles

* [Fr Bundle Document](StructureDefinition-fr-bundle-document.md)
* [Fr Composition Document](StructureDefinition-fr-composition-document.md)
* [Fr Device Document](StructureDefinition-fr-device-document.md)
* [Fr Encounter Document](StructureDefinition-fr-encounter-document.md)
* [Fr Location Document](StructureDefinition-fr-location-document.md)
* [Fr Organization Document](StructureDefinition-fr-organization-document.md)
* [Fr Patient Document](StructureDefinition-fr-patient-document.md)
* [Fr Patient INS Document](StructureDefinition-fr-patient-ins-document.md)
* [Fr Practitioner Document](StructureDefinition-fr-practitioner-document.md)
* [Fr PractitionerRole Document](StructureDefinition-fr-practitionerRole-document.md)
* [Fr RelatedPerson Document](StructureDefinition-fr-related-person-document.md)

### Extensions

* [Fr Author Time Extension](StructureDefinition-fr-author-time.md)
* [Fr Performer Event](StructureDefinition-fr-performer-event.md)

### ConceptMaps

* [Mapping ValueSet AdministrativeGender](ConceptMap-mappingAdministrativeGender.md)
* [Mapping Métier/CDA/FHIR : "Auteur"](ConceptMap-mappingAuteurCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Consentement"](ConceptMap-mappingConsentementCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Destinataire prévu"](ConceptMap-mappingDestinatairePrevuCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "DocumentDeReference"](ConceptMap-mappingDocumentDeReferenceCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Evènement documenté"](ConceptMap-mappingEvenementCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Informateur"](ConceptMap-mappingInformateurCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Opérateur de saisie"](ConceptMap-mappingOperateurSaisieCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Participant"](ConceptMap-mappingParticipantCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Patient/Usager"](ConceptMap-mappingPatientCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Personne / Structure (AssignedEntity)"](ConceptMap-mappingPersonneStructureAssignedEntityFHIR.md)
* [Mapping Métier/CDA/FHIR : "Personne / Structure (Auteur)"](ConceptMap-mappingPersonneStructureAuteurFHIR.md)
* [Mapping Métier/CDA/FHIR : "Personne / Structure (RelatedEntity)"](ConceptMap-mappingPersonneStructureRelatedEntityFHIR.md)
* [Mapping Métier/CDA/FHIR : "Prescription"](ConceptMap-mappingPrescriptionCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Prise en charge"](ConceptMap-mappingPriseEnchargeCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Responsable du document"](ConceptMap-mappingResponsableCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Structure chargée de la conservation du document"](ConceptMap-mappingStructureConservationCDAFHIR.md)
* [Mapping Métier/CDA/FHIR : "Système / Structure Auteur"](ConceptMap-mappingSystemeFHIR.md)
* [Mapping Métier/CDA/FHIR : "Validateur"](ConceptMap-mappingValidateurCDAFHIR.md)
* [Mapping Métier/CDA/FHIR  : Entête d'un document](ConceptMap-mappingmodelemetierCDAFHIR.md)

### ImplementationGuides

* [ANS IG document core](index.md)
