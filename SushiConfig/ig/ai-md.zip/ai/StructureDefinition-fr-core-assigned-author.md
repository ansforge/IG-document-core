# CDA - assignedAuthor - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - assignedAuthor**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-assigned-author-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-assigned-author-mappings.md) 
*  [XML](StructureDefinition-fr-core-assigned-author.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-assigned-author.profile.json.md) 

## Logical Model: CDA - assignedAuthor 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-author | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:FrAssignedAuthor |

 
L’élément de l’en-tête du CDA assignedAuthor contient les éléments permettant de décrire l’auteur. 

**Usages:**

* Use this Logical Model Profile: [CDA - author](StructureDefinition-fr-core-author.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-assigned-author)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [AssignedAuthor](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssignedAuthor.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [AssignedAuthor](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssignedAuthor.html) 

**Résumé**

Mandatory: 2 elements
 Prohibited: 8 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedPerson(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-person)](StructureDefinition-fr-core-person.md)
* [CDA - authoringDevice(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authoring-device)](StructureDefinition-fr-core-authoring-device.md)
* [CDA - representedOrganization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-represented-organization)](StructureDefinition-fr-core-represented-organization.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [AssignedAuthor](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssignedAuthor.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AssignedAuthor](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AssignedAuthor.html) 

**Résumé**

Mandatory: 2 elements
 Prohibited: 8 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedPerson(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-person)](StructureDefinition-fr-core-person.md)
* [CDA - authoringDevice(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authoring-device)](StructureDefinition-fr-core-authoring-device.md)
* [CDA - representedOrganization(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-represented-organization)](StructureDefinition-fr-core-represented-organization.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-assigned-author.csv), [Excel](StructureDefinition-fr-core-assigned-author.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-name.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-assigned-author-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

