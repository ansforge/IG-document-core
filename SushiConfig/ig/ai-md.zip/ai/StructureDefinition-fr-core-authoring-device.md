# CDA - authoringDevice - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - authoringDevice**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-authoring-device-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-authoring-device-mappings.md) 
*  [XML](StructureDefinition-fr-core-authoring-device.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-authoring-device.profile.json.md) 

## Logical Model: CDA - authoringDevice 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-authoring-device | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:FrAuthoringDevice |

 
L’élément de l’en-tête du CDA authoringDevice contient les informations complémentaires si l’auteur est un système. 

**Usages:**

* Use this Logical Model Profile: [CDA - assignedAuthor](StructureDefinition-fr-core-assigned-author.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-authoring-device)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [AuthoringDevice](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AuthoringDevice.html) 

#### Terminology Bindings

This structure is derived from [AuthoringDevice](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AuthoringDevice.html) 

**Résumé**

Mandatory: 2 elements
 Prohibited: 4 elements

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [AuthoringDevice](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AuthoringDevice.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [AuthoringDevice](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-AuthoringDevice.html) 

**Résumé**

Mandatory: 2 elements
 Prohibited: 4 elements

 

Other representations of profile: [CSV](StructureDefinition-fr-core-authoring-device.csv), [Excel](StructureDefinition-fr-core-authoring-device.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-author.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-authoring-device-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

