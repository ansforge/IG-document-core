# Modèle métier - Personne et/ou Structure (Auteur) - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Personne et/ou Structure (Auteur)**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-PersonneStructureAuteur.md) 
*  [Detailed Descriptions](StructureDefinition-PersonneStructureAuteur-definitions.md) 
*  [Mappings](StructureDefinition-PersonneStructureAuteur-mappings.md) 
*  [XML](StructureDefinition-PersonneStructureAuteur.profile.xml.md) 
*  [JSON](#) 

## Logical Model: PersonneStructureAuteur - JSON Profile

| |
| :--- |
| Draft as of 2025-10-01 |

JSON representation of the PersonneStructureAuteur logical model.

[Raw json](StructureDefinition-PersonneStructureAuteur.json) | [Download](StructureDefinition-PersonneStructureAuteur.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-PersonneStructureAuteur.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-PersonneStructureAuteur.profile.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

