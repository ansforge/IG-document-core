# Modèle métier - Personne et/ou Structure - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Personne et/ou Structure**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-PersonneStructure-definitions.md) 
*  [Mappings](StructureDefinition-PersonneStructure-mappings.md) 
*  [XML](StructureDefinition-PersonneStructure.profile.xml.md) 
*  [JSON](StructureDefinition-PersonneStructure.profile.json.md) 

## Logical Model: Modèle métier - Personne et/ou Structure 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/PersonneStructure | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:PersonneStructure |

 
Une personne (professionnel ou patient ou autre) et/ou une structure (pour les professionnels). 

**Usages:**

* Use this Logical Model: [Modèle métier - Destinataire prévu du document](StructureDefinition-DestinatairePrevu.md), [Modèle métier - Évènement documenté](StructureDefinition-Evenement.md), [Modèle métier - Informateur](StructureDefinition-Informateur.md), [Modèle métier - Opérateur de saisie](StructureDefinition-OperateurSaisie.md)...Show 4 more,[Modèle métier - Autres personnes / structures impliquées](StructureDefinition-Participant.md),[Modèle métier - Association du document à une prise en charge](StructureDefinition-PriseEncharge.md),[Modèle métier - Responsable du document](StructureDefinition-Responsable.md)and[Modèle métier - Validateur du document](StructureDefinition-Validateur.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/PersonneStructure)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-PersonneStructure.csv), [Excel](StructureDefinition-PersonneStructure.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-PatientUsager.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-PersonneStructure-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

