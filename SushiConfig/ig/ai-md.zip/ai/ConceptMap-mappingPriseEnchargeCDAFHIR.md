# Mapping Métier/CDA/FHIR : "Prise en charge" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Prise en charge"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingPriseEnchargeCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingPriseEnchargeCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Prise en charge" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingPriseEnchargeCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "Prise en charge" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "prise en charge" et l’élément CDA "componentOf"
* Mapping 2 : entre l’élément CDA "componentOf" et l’élément FHIR "Composition.encounter(Encounter)"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Association du document à une prise en charge](StructureDefinition-PriseEncharge.md) to [CDA - componentOf](StructureDefinition-fr-core-component-of.md)

* **Source Code**: PriseEncharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf
  * **Commentaire**: 
* **Source Code**: PriseEncharge.identifiantPriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.id
  * **Commentaire**: 
* **Source Code**: PriseEncharge.typePriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.code
  * **Commentaire**: 
* **Source Code**: PriseEncharge.dateDebutFinPriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.effectiveTime
  * **Commentaire**: 
* **Source Code**: PriseEncharge.typeSortie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.dischargeDispositionCode
  * **Commentaire**: 
* **Source Code**: PriseEncharge.responsablePriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.responsibleParty.assignedEntity
  * **Commentaire**: L'élément responsablePriseEnCharge est de type PersonneStructure.
* **Source Code**: PriseEncharge.personneImpliqueePriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.encounterParticipant
  * **Commentaire**: 
* **Source Code**: PriseEncharge.personneImpliqueePriseEnCharge.typeParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.encounterParticipant@typeCode
  * **Commentaire**: 
* **Source Code**: PriseEncharge.personneImpliqueePriseEnCharge.dateDebutFinParticipation
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.encounterParticipant.time
  * **Commentaire**: 
* **Source Code**: PriseEncharge.personneImpliqueePriseEnCharge.professionnelImplique
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.encounterParticipant.assignedEntity
  * **Commentaire**: L'élément personneImpliqueePriseEnCharge est de type PersonneStructure.
* **Source Code**: PriseEncharge.lieuPriseEnCharge
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location
  * **Commentaire**: 
* **Source Code**: PriseEncharge.lieuPriseEnCharge.structure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location.healthcareFacility
  * **Commentaire**: 
* **Source Code**: PriseEncharge.lieuPriseEnCharge.structure.secteurActivite
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location.healthcareFacility.code
  * **Commentaire**: 
* **Source Code**: PriseEncharge.lieuPriseEnCharge.structure.secteurActivite.categorieEtablissement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location.healthcareFacility.code.translation
  * **Commentaire**: 
* **Source Code**: PriseEncharge.lieuPriseEnCharge.structure.nomStructure
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location.healthcareFacility.location.name
  * **Commentaire**: 
* **Source Code**: PriseEncharge.lieuPriseEnCharge.structure.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: componentOf.encompassingEncounter.location.healthcareFacility.location.addr
  * **Commentaire**: 

-------

**Group 2**Mapping from [CDA - componentOf](StructureDefinition-fr-core-component-of.md) to [Fr Encounter Document](StructureDefinition-fr-encounter-document.md)

* **Source Code**: componentOf
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.encounter.Encounter
  * **Commentaire**: Composition.encounter.resolve().ofType(Encounter)
* **Source Code**: componentOf.encompassingEncounter.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.identifier
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.type
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.effectiveTime
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.period
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.dischargeDispositionCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.hospitalization.dischargeDisposition
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.responsibleParty.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.type="DIS".individual
  * **Commentaire**: Encounter.participant.individual.resolve().ofType(PractitionerRole)
* **Source Code**: componentOf.encompassingEncounter.encounterParticipant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.encounterParticipant@typeCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.type
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.encounterParticipant.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.period
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.encounterParticipant.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
  * **Commentaire**: Encounter.participant.individual.resolve().ofType(PractitionerRole)
* **Source Code**: componentOf.encompassingEncounter.location
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.location
  * **Commentaire**: Encounter.location.resolve().ofType(Location)
* **Source Code**: componentOf.encompassingEncounter.location.healthcareFacility
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.location.Location
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.location.healthcareFacility.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.location.Location.type
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.location.healthcareFacility.location.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.location.Location.name
  * **Commentaire**: 
* **Source Code**: componentOf.encompassingEncounter.location.healthcareFacility.location.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.location.Location.address
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingPrescriptionCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingPriseEnchargeCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

