# LDL-SES_2022.01 - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LDL-SES_2022.01**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](Binary-LDL-SES-2022.01.md) 
*  [XML](Binary-LDL-SES-2022.01.xml.md) 
*  [JSON](Binary-LDL-SES-2022.01.json.md) 

## : LDL-SES_2022.01 - TTL Representation

[Raw ttl](Binary-LDL-SES-2022.01.ttl) | [Download](Binary-LDL-SES-2022.01.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](Binary-LDL-SES-2022.01.json.md) | [top](#top) |  next> |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

