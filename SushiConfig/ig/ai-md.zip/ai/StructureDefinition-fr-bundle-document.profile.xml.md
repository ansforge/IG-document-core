# Fr Bundle Document - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fr Bundle Document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-fr-bundle-document.md) 
*  [Detailed Descriptions](StructureDefinition-fr-bundle-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-bundle-document-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-fr-bundle-document.profile.json.md) 

## Resource Profile: FrBundleDocument - XML Profile

| |
| :--- |
| Draft as of 2025-10-01 |

XML representation of the fr-bundle-document resource profile.

[Raw xml](StructureDefinition-fr-bundle-document.xml) | [Download](StructureDefinition-fr-bundle-document.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-bundle-document-testing.md) | [top](#top) |  [next>](StructureDefinition-fr-bundle-document.profile.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

