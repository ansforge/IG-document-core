# Mapping Métier/CDA/FHIR : "DocumentDeReference" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "DocumentDeReference"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingDocumentDeReferenceCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingDocumentDeReferenceCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "DocumentDeReference" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingDocumentDeReferenceCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "DocumentDeReference" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "documentDeReference" et l’élément CDA "relatedDocument"
* Mapping 2 : entre l’élément CDA "relatedDocument" et l’élément FHIR "Composition.relatesTo"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Document de référence](StructureDefinition-DocumentDeReference.md) to [CDA - relatedDocument](StructureDefinition-fr-core-related-document.md)

* **Source Code**: DocumentDeReference
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: relatedDocument
* **Source Code**: DocumentDeReference.typeReference
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: relatedDocument@typeCode
* **Source Code**: DocumentDeReference.identifiantUniqueDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: relatedDocument.parentDocument.id

-------

**Group 2**Mapping from [CDA - relatedDocument](StructureDefinition-fr-core-related-document.md) to [Fr Composition Document](StructureDefinition-fr-composition-document.md)

* **Source Code**: relatedDocument
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.relatesTo
* **Source Code**: relatedDocument@typeCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.relatesTo.code
* **Source Code**: relatedDocument.parentDocument.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Composition.relatesTo.targetIdentifier

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingDestinatairePrevuCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingDocumentDeReferenceCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

