# Modèle métier - Système / Structure - TTL Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle métier - Système / Structure**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-SystemeStructureAuteur.md) 
*  [Detailed Descriptions](StructureDefinition-SystemeStructureAuteur-definitions.md) 
*  [Mappings](StructureDefinition-SystemeStructureAuteur-mappings.md) 
*  [XML](StructureDefinition-SystemeStructureAuteur.profile.xml.md) 
*  [JSON](StructureDefinition-SystemeStructureAuteur.profile.json.md) 

## Logical Model: SystemeStructureAuteur - TTL Profile

| |
| :--- |
| Draft as of 2025-10-01 |

TTL representation of the SystemeStructureAuteur logical model.

[Raw ttl](StructureDefinition-SystemeStructureAuteur.ttl) | [Download](StructureDefinition-SystemeStructureAuteur.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-SystemeStructureAuteur.profile.json.md) | [top](#top) |  [next>](StructureDefinition-Validateur.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

