# CDA - custodian - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - custodian**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-fr-core-custodian-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-custodian-mappings.md) 
*  [XML](StructureDefinition-fr-core-custodian.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-custodian.profile.json.md) 

## Logical Model: CDA - custodian 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-custodian | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:FrCustodian |

 
L’élément de l’en-tête du CDA custodian permet de représenter la structure chargée de la conservation du document. 

**Usages:**

* Use this Logical Model Profile: [CDA - clinicalDocument](StructureDefinition-fr-core-clinical-document.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-core-custodian)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Custodian](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Custodian.html) 

#### Terminology Bindings

This structure is derived from [Custodian](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Custodian.html) 

**Résumé**

Prohibited: 4 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedCustodian(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-custodian)](StructureDefinition-fr-core-assigned-custodian.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Custodian](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Custodian.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Custodian](http://hl7.org/cda/stds/core/2.0.0-sd/StructureDefinition-Custodian.html) 

**Résumé**

Prohibited: 4 elements

**Structures**

This structure refers to these other structures:

* [CDA - assignedCustodian(https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-core-assigned-custodian)](StructureDefinition-fr-core-assigned-custodian.md)

 

Other representations of profile: [CSV](StructureDefinition-fr-core-custodian.csv), [Excel](StructureDefinition-fr-core-custodian.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-component-of.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-fr-core-custodian-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

