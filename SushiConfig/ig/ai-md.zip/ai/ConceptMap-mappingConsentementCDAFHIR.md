# Mapping Métier/CDA/FHIR : "Consentement" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Consentement"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingConsentementCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingConsentementCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Consentement" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingConsentementCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "Consentement" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "ConsentementAssocie" et l’élément CDA "authorization"
* Mapping 2 : entre l’élément CDA "authorization" et l’extension FHIR "ConsentExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Consentement associé au document](StructureDefinition-Consentement.md) to [CDA - authorization](StructureDefinition-fr-core-authorization.md)

* **Source Code**: Consentement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: authorization
* **Source Code**: Consentement.identifiantConsentement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: authorization.consent.id
* **Source Code**: Consentement.typeConsentement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: authorization.consent.code
* **Source Code**: Consentement.statutConsentement
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: authorization.consent.statusCode="completed"

-------

**Group 2**Mapping from [CDA - authorization](StructureDefinition-fr-core-authorization.md) to [Consent Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-consent-extension.html)

* **Source Code**: authorization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ConsentExtension.ValueReference.Consent
  * **Commentaire**: ValueReference.resolve().ofType(Consent)
* **Source Code**: authorization.consent.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ConsentExtension.ValueReference.Consent.identifier
  * **Commentaire**: 
* **Source Code**: authorization.consent.code
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ConsentExtension.ValueReference.Consent.category
  * **Commentaire**: 
* **Source Code**: authorization.consent.statusCode="completed"
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:ConsentExtension.ValueReference.Consent.status:active
  * **Commentaire**: 

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingAuteurCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingConsentementCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

