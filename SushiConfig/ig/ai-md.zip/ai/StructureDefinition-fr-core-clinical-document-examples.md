# CDA - clinicalDocument - Examples - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDA - clinicalDocument**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-fr-core-clinical-document.md) 
*  [Detailed Descriptions](StructureDefinition-fr-core-clinical-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-core-clinical-document-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-fr-core-clinical-document.profile.xml.md) 
*  [JSON](StructureDefinition-fr-core-clinical-document.profile.json.md) 

## Logical Model: FrClinicalDocument - Examples

| |
| :--- |
| Draft as of 2025-10-01 |

Examples for the fr-core-clinical-document Profile.

| |
| :--- |
| [BIO-CR-BIO_2024.01_Microbiologie_V1](Binary-BIO-CR-BIO-2024.01-Microbiologie-V1.md) |
| [BIO-CR-BIO_2024.01_Glycemie_mole](Binary-BIO-CR-BIO-2024.01-glycemie-mole.md) |
| [IPS-FR](Binary-IPS-FR-2024.01.md) |
| [LDL-SES_2022.01](Binary-LDL-SES-2022.01.md) |
| [eDISP-MED-2024.01](Binary-eDISP-MED-2024.01.md) |
| [eP-MED-DM_2024.01_PosoNonStruct](Binary-eP-MED-DM-2024.01-PosoNonStruct.md) |
| [eP-MED-DM_2024.01_PosoStruct](Binary-eP-MED-DM-2024.01-PosoStruct.md) |

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-core-clinical-document-testing.md) | [top](#top) |  [next>](StructureDefinition-fr-core-clinical-document.profile.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

