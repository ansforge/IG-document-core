# Mapping Métier/CDA/FHIR : "Informateur" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Informateur"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingInformateurCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingInformateurCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Informateur" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingInformateurCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "Informateur" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "informateur" et l’élément CDA "informant"
* Mapping 2 : entre l’élément CDA "informant" et l’extension FHIR "InformantExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Informateur](StructureDefinition-Informateur.md) to [CDA - informant](StructureDefinition-fr-core-informant.md)

* **Source Code**: Informateur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: informant
  * **Commentaire**: 
* **Source Code**: Informateur.informateur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: informant.assignedEntity
  * **Commentaire**: L'élément informateur est de type PersonneStructure.
* **Source Code**: Informateur.informateur
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: informant.relatedEntity
  * **Commentaire**: L'élément informateur est de type PersonneStructure.

-------

**Group 2**Mapping from [CDA - informant](StructureDefinition-fr-core-informant.md) to [Informant Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-informant-extension.html)

* **Source Code**: informant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:InformantExtension
  * **Commentaire**: 
* **Source Code**: informant.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:InformantExtension.extension:party.ValueReference
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(PractitionerRole or Patient)
* **Source Code**: informant.relatedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: extension:InformantExtension.extension:party.ValueReference
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(RelatedPerson)

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingEvenementCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingInformateurCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

