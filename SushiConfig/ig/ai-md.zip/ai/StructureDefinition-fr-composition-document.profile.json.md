# Fr Composition Document - JSON Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fr Composition Document**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Content](StructureDefinition-fr-composition-document.md) 
*  [Detailed Descriptions](StructureDefinition-fr-composition-document-definitions.md) 
*  [Mappings](StructureDefinition-fr-composition-document-mappings.md) 
*  [XML](StructureDefinition-fr-composition-document.profile.xml.md) 
*  [JSON](#) 

## Resource Profile: FrCompositionDocument - JSON Profile

| |
| :--- |
| Draft as of 2025-10-01 |

JSON representation of the fr-composition-document resource profile.

[Raw json](StructureDefinition-fr-composition-document.json) | [Download](StructureDefinition-fr-composition-document.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-fr-composition-document.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-fr-composition-document.profile.ttl.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

