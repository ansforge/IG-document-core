# Mapping Métier/CDA/FHIR : "Opérateur de saisie" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Opérateur de saisie"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingOperateurSaisieCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingOperateurSaisieCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Opérateur de saisie" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingOperateurSaisieCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "Opérateur de saisie" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "operateurSaisie" et l’élément CDA "dataEnterer"
* Mapping 2 : entre l’élément CDA "dataEnterer" et l’extension FHIR "DataEntererExtension"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from [Modèle métier - Opérateur de saisie](StructureDefinition-OperateurSaisie.md) to [CDA - dataEnterer](StructureDefinition-fr-core-data-enterer.md)

* **Source Code**: OperateurSaisie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: dataEnterer
  * **Commentaire**: 
* **Source Code**: OperateurSaisie.dateSaisie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: dataEnterer.time
  * **Commentaire**: 
* **Source Code**: OperateurSaisie.operateurSaisie
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: dataEnterer.assignedEntity
  * **Commentaire**: L'élément operateurSaisie est de type PersonneStructure.

-------

**Group 2**Mapping from [CDA - dataEnterer](StructureDefinition-fr-core-data-enterer.md) to [Data Enterer Extension](http://hl7.org/fhir/uv/fhir-clinical-document/2024Sep/StructureDefinition-data-enterer-extension.html)

* **Source Code**: dataEnterer
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DataEntererExtension
  * **Commentaire**: 
* **Source Code**: dataEnterer.time
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DataEntererExtension.extension:time
  * **Commentaire**: 
* **Source Code**: dataEnterer.assignedEntity
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DataEntererExtension.extension:party.ValueReference
  * **Commentaire**: extension:party.ValueReference.resolve().ofType(PractitionerRole)

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingInformateurCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingOperateurSaisieCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

