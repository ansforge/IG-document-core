# Mapping Métier/CDA/FHIR : "Patient/Usager" - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mapping Métier/CDA/FHIR : "Patient/Usager"**

ANS IG document core - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/document/core/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-mappingPatientCDAFHIR.xml.md) 
*  [JSON](ConceptMap-mappingPatientCDAFHIR.json.md) 

## ConceptMap: Mapping Métier/CDA/FHIR : "Patient/Usager" 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ConceptMap/mappingPatientCDAFHIR | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:Mapping Métier/CDA/FHIR : "Patient/Usager" |

 
Ce ConceptMap présente deux groupes de mapping : 
* Mapping 1 : entre le modèle métier "patient" et l’élément CDA "recordTarget"
* Mapping 2 : entre l’élément CDA "recordTarget" et le profil FHIR "FrPatientDocument"
 

Mapping from (non spécifié) to (non spécifié)

**Group 1**Mapping from `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/Patient` to [CDA - recordTarget](StructureDefinition-fr-core-record-target.md)

* **Source Code**: Patient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget
* **Source Code**: Patient.identifiantPatient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.id
* **Source Code**: Patient.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.addr
* **Source Code**: Patient.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.telecom
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.nom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.family
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.nom.nomNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PrecordTarget.patientRole.patient.name.family@qualifier='BR'
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.nom.nomUtilise
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.family@qualifier='CL'
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.prenom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.given
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.prenom.listePrenoms
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.given
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.prenom.premierPrenom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.given@qualifier='BR'
* **Source Code**: Patient.personnePhysique.nomsPrenomsPatient.prenom.prenomUtilise
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.name.given@qualifier='CL'
* **Source Code**: Patient.personnePhysique.sexe
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.administrativeGenderCode
* **Source Code**: Patient.personnePhysique.dateNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.birthTime
* **Source Code**: Patient.personnePhysique.indicateurDeces
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.sdtc:deceasedInd
* **Source Code**: Patient.personnePhysique.dateDeces
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.sdtc:deceasedTime
* **Source Code**: Patient.personnePhysique.grossesseMultiple
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.sdtc:multipleBirthInd
* **Source Code**: Patient.personnePhysique.numeroOrdreNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.sdtc:multipleBirthOrderNumber
* **Source Code**: Patient.personnePhysique.representantPatient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian
* **Source Code**: Patient.personnePhysique.representantPatient.adresse
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.addr
* **Source Code**: Patient.personnePhysique.representantPatient.coordonneesTelecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.telecom
* **Source Code**: Patient.personnePhysique.representantPatient.personneRepresentantPatient.nomsPrenomsRepresentantPatient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianPerson.name
* **Source Code**: Patient.personnePhysique.representantPatient.personneRepresentantPatient.nomsPrenomsRepresentantPatient.nom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianPerson.family
* **Source Code**: Patient.personnePhysique.representantPatient.personneRepresentantPatient.nomsPrenomsRepresentantPatient.prenom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianPerson.given
* **Source Code**: Patient.personnePhysique.representantPatient.structureRepresentantPatient
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianOrganization
* **Source Code**: Patient.personnePhysique.representantPatient.structureRepresentantPatient.identifiant
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianOrganization.id
* **Source Code**: Patient.personnePhysique.representantPatient.structureRepresentantPatient.nom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.guardian.guardianOrganization.name
* **Source Code**: Patient.personnePhysique.lieuNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.birthPlace
* **Source Code**: Patient.personnePhysique.lieuNaissance.nomLieuNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.birthPlace.place.name
* **Source Code**: Patient.personnePhysique.lieuNaissance.adresseLieuNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.birthPlace.place.addr
* **Source Code**: Patient.personnePhysique.lieuNaissance.adresseLieuNaissance.codeOfficielGeographiqueLieuNaissance
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: recordTarget.patientRole.patient.birthPlace.place.addr.county

-------

**Group 2**Mapping from [CDA - recordTarget](StructureDefinition-fr-core-record-target.md) to `https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-patient-fhir-document`

* **Source Code**: recordTarget.patientRole
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient
* **Source Code**: recordTarget.patientRole.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.identifier
* **Source Code**: recordTarget.patientRole.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address
* **Source Code**: recordTarget.patientRole.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.telecom
* **Source Code**: recordTarget.patientRole.patient.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name
* **Source Code**: recordTarget.patientRole.patient.name.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name.family
* **Source Code**: recordTarget.patientRole.patient.name.family@qualifier='BR'
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name:officialname.family
* **Source Code**: recordTarget.patientRole.patient.name.family@qualifier='CL'
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name:usualname.family
* **Source Code**: recordTarget.patientRole.patient.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name.given
* **Source Code**: recordTarget.patientRole.patient.name.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name:officialname.birth-list-given-name
* **Source Code**: recordTarget.patientRole.patient.name.given@qualifier='BR'
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name:officialname.given
* **Source Code**: recordTarget.patientRole.patient.name.given@qualifier='CL'
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name:usualname.given
* **Source Code**: recordTarget.patientRole.patient.administrativeGenderCode
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.gender
* **Source Code**: recordTarget.patientRole.patient.birthTime
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.birthDate
* **Source Code**: recordTarget.patientRole.patient.sdtc:deceasedInd
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.deceasedBoolean
* **Source Code**: recordTarget.patientRole.patient.sdtc:deceasedTime
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.deceasedDateTime
* **Source Code**: recordTarget.patientRole.patient.sdtc:multipleBirthInd
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.multipleBirthBoolean
* **Source Code**: recordTarget.patientRole.patient.sdtc:multipleBirthOrderNumber
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.multipleBirthInteger
* **Source Code**: recordTarget.patientRole.patient.guardian
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.relationship:Role='GUARD'
* **Source Code**: recordTarget.patientRole.patient.guardian.addr
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.address
* **Source Code**: recordTarget.patientRole.patient.guardian.telecom
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.telecom
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianPerson.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.name
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianPerson.family
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.name.family
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianPerson.given
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.name.given
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianOrganization
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.organization
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianOrganization.id
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.organization.identifier
* **Source Code**: recordTarget.patientRole.patient.guardian.guardianOrganization.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.contact.organization.name
* **Source Code**: recordTarget.patientRole.patient.birthPlace
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.extension:birthPlace
* **Source Code**: recordTarget.patientRole.patient.birthPlace.place
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.extension:birthPlace.value[FRCoreAddressProfile]
* **Source Code**: recordTarget.patientRole.patient.birthPlace.place.name
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.extension:birthPlace.value[FRCoreAddressProfile].text
* **Source Code**: recordTarget.patientRole.patient.birthPlace.place.country
  * **relation**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.extension:birthPlace.value[FRCoreAddressProfile].extension:inseeCode

| | | |
| :--- | :--- | :--- |
|  [<prev](ConceptMap-mappingParticipantCDAFHIR.ttl.md) | [top](#top) |  [next>](ConceptMap-mappingPatientCDAFHIR-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.document.fr.core#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/document/core/history.html) | [New Issue](https://github.com/ansforge/FIG_ans-ig-sample/issues/new)  

